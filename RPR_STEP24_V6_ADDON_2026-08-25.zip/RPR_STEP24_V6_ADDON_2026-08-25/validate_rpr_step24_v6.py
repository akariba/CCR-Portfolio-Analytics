#!/usr/bin/env python3
from pathlib import Path
import py_compile
import sys

ROOT = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path.cwd().resolve()
backend = ROOT / "backend"
ui = ROOT / "UI Design"

required = [
    backend / "step24_sector_factors_service.py",
    backend / "step24_sector_factors_routes.py",
    backend / "step24_sector_factors_v6_service.py",
    backend / "step24_sector_factors_v6_routes.py",
    backend / "prompts" / "step24_sector_inherent_v6_0.txt",
    ui / "rpr_step24_append.js",
    backend / "server.py",
]
missing = [p for p in required if not p.exists()]
if missing:
    raise SystemExit("FAIL missing:\n" + "\n".join(map(str, missing)))

py_compile.compile(str(backend / "step24_sector_factors_v6_service.py"), doraise=True)
py_compile.compile(str(backend / "step24_sector_factors_v6_routes.py"), doraise=True)

server = (backend / "server.py").read_text(encoding="utf-8-sig")
front = (ui / "rpr_step24_append.js").read_text(encoding="utf-8-sig")

assert "from step24_sector_factors_v6_routes import router as step24_v6_router" in server
assert "app.include_router(step24_v6_router)" in server
assert "/generate-v6" in front
assert "/revise-v6" in front
assert "/finalize-v6" in front

print("VALIDATION PASS — Step 2.4 V6 additive contract is installed.")
print("V5.2 routes remain available for rollback/parallel comparison.")
