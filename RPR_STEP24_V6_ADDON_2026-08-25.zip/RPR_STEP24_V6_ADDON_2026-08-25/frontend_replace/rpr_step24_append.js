/* RPR Step 2.4 append. Does not rewrite Step 1 / Step 2.1 / Step 2.2 / Step 2.3. */
(function(){
  'use strict';
  if(window.__RPR_STEP24_APPEND_LOADED__) return;
  window.__RPR_STEP24_APPEND_LOADED__ = true;

  const S24 = { frameworks:new Map(), confirmed:new Map(), initialized:false };
  window.RPR_STEP24_APPEND_STATE = S24;
  const q=id=>document.getElementById(id);
  const safe=v=>typeof esc==='function'?esc(v):String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
  const log=(level,msg)=>typeof addLog==='function'?addLog(level,msg):console.log('[STEP24]',msg);

  function apiPost24(path, body, timeout=260000){
    if(typeof apiPost==='function') return apiPost(path,body,timeout);
    const base=(typeof API!=='undefined'?API:'http://127.0.0.1:8000');
    const ctrl=new AbortController(); const t=setTimeout(()=>ctrl.abort(),timeout);
    return fetch(base+path,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body),signal:ctrl.signal})
      .then(async r=>{clearTimeout(t);const d=await r.json();if(!r.ok)throw new Error(d.detail||('HTTP '+r.status));return d});
  }

  function confirmedPortfolio(){
    // Current SAFE Step 2.2 append exposes the confirmed portfolio through a public getter.
    // Read that contract first; the lexical fallback only supports older single-file builds.
    try{
      const publicState=window.RPR_SAFE_APPEND_STATE;
      if(publicState && publicState.portfolio) return publicState.portfolio;
    }catch(_){ }
    try{
      return typeof STEP22_CONFIRMED_PORTFOLIO!=='undefined'?STEP22_CONFIRMED_PORTFOLIO:null;
    }catch(_){ return null }
  }

  function portfolioSectors(){
    const p=confirmedPortfolio();
    const companies=Array.isArray(p?.companies)?p.companies:[];
    const explicitIds=new Set((p?.selected_sector_ids||[]).map(x=>String(x||'').trim()).filter(Boolean));
    const byId=new Map();
    companies.forEach(c=>{
      const id=String(c?.sector_id||'').trim();
      const l3=String(c?.l3||c?.sector_label||'').trim();
      if(!id||!l3)return;
      if(explicitIds.size && !explicitIds.has(id))return;
      if(!byId.has(id))byId.set(id,{
        id,
        l1:String(c?.l1||'').trim(),
        l2:String(c?.l2||'').trim(),
        l3,
        name:l3,
        sector_label:l3
      });
    });
    const sectors=[...byId.values()].sort((a,b)=>[a.l1,a.l2,a.l3].join('|').localeCompare([b.l1,b.l2,b.l3].join('|')));
    S24.sectors=sectors;
    return sectors;
  }

  function syncSectorSelectFromPortfolio(){
    const sel=q('sector-select'); if(!sel)return [];
    const sectors=portfolioSectors(); if(!sectors.length)return [];
    const prior=String(sel.value||'');
    sel.innerHTML=sectors.map(s=>`<option value="${safe(s.id)}" data-l1="${safe(s.l1)}" data-l2="${safe(s.l2)}" data-l3="${safe(s.l3)}">${safe(s.l3)}</option>`).join('');
    if(sectors.some(s=>s.id===prior))sel.value=prior;
    return sectors;
  }

  function selectedSector(){
    const sel=q('sector-select'); if(!sel||!sel.value)return null;
    let obj=S24.sectors.find(s=>s.id===String(sel.value))||null;
    try{ if(!obj && typeof getSectorById==='function') obj=getSectorById(sel.value) }catch(_){ }
    const opt=sel.options?.[sel.selectedIndex];
    const label=String(obj?.l3||obj?.name||opt?.dataset?.l3||opt?.text||'').trim();
    if(!label)return null;
    return {
      id:String(obj?.id||sel.value||''),
      l1:String(obj?.l1||opt?.dataset?.l1||''),
      l2:String(obj?.l2||opt?.dataset?.l2||''),
      l3:label,
      name:label,
      sector_label:label
    };
  }
  function key(sec){return String(sec?.id||[sec?.l1,sec?.l2,sec?.l3].join('|')).trim()}
  function sectorIsConfirmed(){
    const p=confirmedPortfolio();
    if(p) return true;
    // Backward compatible with current Step 2.2 bone: if its confirmation object is lexical-only, the sector dropdown is rebuilt on confirmation.
    const sel=q('sector-select'); return !!(sel && sel.options && sel.options.length && sel.value);
  }

  function ensureGenerateButton(){
    const pane=q('t1-step-3'); if(!pane)return;
    const row=pane.querySelector('.action-row'); if(!row||q('generate-sector-factors-btn'))return;
    const btn=document.createElement('button'); btn.id='generate-sector-factors-btn'; btn.className='btn btn-p btn-sm';
    btn.textContent='⌁ Generate Sector Factors'; btn.onclick=generateStep24;
    const firstPrimary=row.querySelector('.btn-p'); row.insertBefore(btn,firstPrimary||row.firstChild);
    const save=row.querySelector('.btn-g'); if(save){save.onclick=saveStep24;save.title='Preserve analyst-edited factor narratives in this session';}
    const confirm=[...row.querySelectorAll('.btn-p')].find(b=>b!==btn && /Confirm/i.test(b.textContent||''));
    if(confirm){confirm.onclick=confirmStep24;}
  }

  function enterStep24(){
    ensureGenerateButton();
    syncSectorSelectFromPortfolio();
    const sec=selectedSector();
    const count=q('s3-factor-count');
    if(!sectorIsConfirmed()){
      if(count)count.textContent='0 factors';
      if(q('s3-summary-body'))q('s3-summary-body').innerHTML='<tr><td colspan="5" style="color:var(--text_disabled)">Confirm Step 2.2 portfolio selection before Step 2.4.</td></tr>';
      if(q('s3-rf-cards'))q('s3-rf-cards').innerHTML='';
      return;
    }
    if(sec && S24.frameworks.has(key(sec))) renderStep24(S24.frameworks.get(key(sec)));
    else if(q('s3-summary-body')) q('s3-summary-body').innerHTML='<tr><td colspan="5" style="color:var(--text_disabled)">Generate the V6 sector-inherent framework for the selected confirmed L3 sector.</td></tr>';
  }

  function trace(data,scope){
    if(typeof logModelsTriggered==='function')logModelsTriggered(data,scope);
    else (data?.models_triggered||[]).forEach(m=>log('info',`${scope} — ${m.model||''} / ${m.role||''}`));
  }

  async function generateStep24(){
    syncSectorSelectFromPortfolio();
    const sec=selectedSector();
    if(!sectorIsConfirmed()){log('warn','Confirm Step 2.2 before generating Step 2.4.');return}
    if(!sec){log('warn','Select a confirmed L3 sector for Step 2.4.');return}
    const btn=q('generate-sector-factors-btn'); if(btn)btn.disabled=true;
    if(typeof showLoad==='function')showLoad('Generating sector-inherent risk factors…','Opus V6.0 sector-inherent generation → deterministic validation / weighting');
    try{
      const d=await apiPost24('/api/v1/rpr/step24/sector-factors/generate-v6',{sector:sec,confirmed_portfolio:confirmedPortfolio()||{}},280000);
      S24.frameworks.set(key(sec),d); renderStep24(d); trace(d,'Step 2.4 generation');
      log('ok',`Step 2.4 generated ${d.factors?.length||0} sector-inherent factors for ${sec.l3}; weights ${d.weights_sum_pct||0}%.`);
      if(typeof markWFStep==='function')markWFStep(4,'current');
    }catch(e){
      const msg=String(e?.message||e);log('warn','Step 2.4 generation failed — '+msg);
      if(q('s3-summary-body'))q('s3-summary-body').innerHTML=`<tr><td colspan="5"><div class="step24-data-warning">${safe(msg)}</div></td></tr>`;
    }finally{if(btn)btn.disabled=false;if(typeof hideLoad==='function')hideLoad()}
  }

  function metricRows(rows,bands){
    return (rows||[]).map(m=>`<tr><td>${safe(m.metric||'')}<div class="step24-inline-note">${safe(m.formula||'')}</div></td>${bands.map(b=>`<td>${safe(m.bands?.[b]||'')}</td>`).join('')}</tr>`).join('');
  }
  function scoreRows(rows){
    return (rows||[]).map(r=>`<tr><td>${safe(r.score)}</td><td>${safe(r.vulnerability_profile||'')}</td><td>${safe(r.buffer_profile||'')}</td></tr>`).join('');
  }
  function factorCard(f,first){
    const vuln=metricRows(f.vulnerability_metrics,['VERY_HIGH','HIGH','MODERATE','LOW']);
    const buf=metricRows(f.buffer_metrics,['STRONG','MODERATE','WEAK','NEGLIGIBLE']);
    const crit=(f.critical_threshold?.conditions||[]).map(safe).join(' AND ');
    return `<div class="rf-card" data-step24-factor="${safe(f.factor_id||'')}">
      <div class="rf-card-hdr ${first?'open':''}" onclick="toggleRF(this)"><div style="display:flex;align-items:center;gap:9px"><span class="rf-idx">${safe(f.factor_id||'RF')}</span><div><div class="rf-name">${safe(f.name||'Risk Factor')}</div><div class="rf-weight">${safe(f.importance||'')} · ${safe(f.weight_pct??'')}% · Net ${safe(f.net_reference_score??'')}/5</div></div></div><span>⌄</span></div>
      <div class="rf-card-body ${first?'open':''}">
        <div class="rf-subsection"><div class="rf-subsection-label">Factor Narrative</div><textarea class="narrative-ta step24-narrative">${safe(f.narrative||f.rationale||'')}</textarea><div class="step24-reference-score">Reference raw ${safe(f.reference_raw_score)} − buffer credit ${safe(f.buffer_credit_points)} = net ${safe(f.net_reference_score)}. Sector reference only; issuer observations are assessed downstream.</div></div>
        <div class="rf-subsection"><div class="rf-subsection-label">Importance</div><div class="key-principle-note">${safe(f.importance_justification||'')}</div></div>
        <div class="rf-subsection"><div class="rf-subsection-label">Vulnerability Metrics (Set 1)</div><table class="metric-tbl"><thead><tr><th>Metric / Formula</th><th class="th-vh">Very High</th><th class="th-h">High</th><th>Moderate</th><th class="th-l">Low</th></tr></thead><tbody>${vuln}</tbody></table><div class="critical-note"><b>Critical threshold (AND):</b> ${crit}</div></div>
        <div class="rf-subsection"><div class="rf-subsection-label">Buffer Metrics (Set 2)</div><table class="metric-tbl"><thead><tr><th>Metric / Formula</th><th class="th-l">Strong</th><th>Moderate</th><th class="th-h">Weak</th><th class="th-vh">Negligible</th></tr></thead><tbody>${buf}</tbody></table><div class="key-principle-note"><b>Key Principle:</b> ${safe(f.key_principle||'')}</div></div>
        <div class="rf-subsection"><div class="rf-subsection-label">Scoring Logic (1–5)</div><table class="metric-tbl step24-score-table"><thead><tr><th>Score</th><th>Vulnerability Profile</th><th>Buffer Profile</th></tr></thead><tbody>${scoreRows(f.scoring)}</tbody></table><div class="step24-inline-note">Net Score = Raw Vulnerability Score − Buffer Credit Points (Strong 2 / Moderate 1 / Weak or Negligible 0), floor 1. Score 5 requires simultaneous breach of all critical conditions.</div></div>
        <div class="rf-subsection"><div class="rf-subsection-label">Credit Implication</div><div class="key-principle-note">${safe(f.credit_implication||'')}</div></div>
      </div></div>`;
  }

  function renderStep24(d){
    const fs=d?.factors||[]; if(q('s3-factor-count'))q('s3-factor-count').textContent=fs.length+' factors';
    if(q('s3-summary-body'))q('s3-summary-body').innerHTML=fs.length?fs.map((f,i)=>`<tr><td>${safe(f.factor_id||('RF'+(i+1)))}</td><td>${safe(f.name||'')}</td><td>${safe(f.importance||'')}</td><td>${safe(f.importance_score??'')}</td><td>${safe(f.weight_pct??'')}%</td></tr>`).join(''):'<tr><td colspan="5">No factors returned.</td></tr>';
    const host=q('s3-rf-cards'); if(host){host.innerHTML=(d?.sector_preamble?`<div class="step24-preamble">${safe(d.sector_preamble)}</div>`:'')+fs.map((f,i)=>factorCard(f,i===0)).join('')+(fs.length?`<div class="step24-preamble"><b>Composite reference score:</b> ${safe(d.composite_reference_score??'—')} / 5.0 · ${safe(d.methodology_note||'')}</div>`:'');}
  }

  function saveStep24(){
    const sec=selectedSector(); const d=sec?S24.frameworks.get(key(sec)):null; if(!d){log('warn','Generate Step 2.4 before saving.');return}
    const cards=[...document.querySelectorAll('#t1-step-3 [data-step24-factor]')];
    cards.forEach(card=>{const id=card.getAttribute('data-step24-factor');const f=(d.factors||[]).find(x=>String(x.factor_id)===id);const ta=card.querySelector('.step24-narrative');if(f&&ta){f.narrative=ta.value;f.rationale=ta.value;}});
    S24.frameworks.set(key(sec),d);log('ok','Step 2.4 analyst narrative edits saved in the current session.');
  }

  async function confirmStep24(){
    const sec=selectedSector(); if(!sec){log('warn','Select a Step 2.4 sector first.');return}
    saveStep24(); const d=S24.frameworks.get(key(sec)); if(!d){log('warn','Generate Step 2.4 before confirmation.');return}
    if(typeof showLoad==='function')showLoad('Confirming sector-inherent risk factors…','Deterministic governance validation');
    try{
      const out=await apiPost24('/api/v1/rpr/step24/sector-factors/finalize-v6',{sector:sec,framework:d},60000);
      S24.frameworks.set(key(sec),out);S24.confirmed.set(key(sec),out);renderStep24(out);log('ok',`Step 2.4 confirmed for ${sec.l3}.`);
      if(typeof completeStep==='function')completeStep(3,'Sector-inherent risk factors confirmed');
    }catch(e){log('warn','Step 2.4 confirmation failed — '+String(e?.message||e));}
    finally{if(typeof hideLoad==='function')hideLoad()}
  }

  async function reviseStep24(instruction){
    const sec=selectedSector(); const base=sec?S24.frameworks.get(key(sec)):null;
    if(!sec||!base){log('warn','Generate Step 2.4 before applying feedback.');return}
    if(typeof showLoad==='function')showLoad('Applying Step 2.4 feedback…','Sonnet 5 targeted revision → deterministic validation / re-weighting');
    try{
      const out=await apiPost24('/api/v1/rpr/step24/sector-factors/revise-v6',{sector:sec,base_framework:base,confirmed_feedback:String(instruction||'')},220000);
      S24.frameworks.set(key(sec),out);renderStep24(out);trace(out,'Step 2.4 revision');log('ok','Step 2.4 feedback revision applied.');
      if(typeof appendScopedFeedback==='function')appendScopedFeedback('step2-4','assistant','Revision applied. Governed factor names were preserved and deterministic weights were recalculated.');
    }catch(e){if(typeof appendScopedFeedback==='function')appendScopedFeedback('step2-4','assistant','Revision failed: '+String(e?.message||e));log('warn','Step 2.4 revision failed — '+String(e?.message||e));}
    finally{if(typeof hideLoad==='function')hideLoad()}
  }

  // Add Step 2.4 support without changing existing Step 2.1 / 2.3 feedback application behavior.
  try{
    if(typeof applyScopedFeedback==='function'){
      const oldApply=applyScopedFeedback;
      window.applyScopedFeedback=async function(stepKey,instruction){if(stepKey==='step2-4')return reviseStep24(instruction);return oldApply(stepKey,instruction);};
    }
  }catch(_){ }

  // Preserve existing step switching; add only an entry hook for Step 2.4.
  try{
    if(typeof switchStep==='function'){
      const oldSwitch=switchStep;
      window.switchStep=function(idx){const out=oldSwitch.apply(this,arguments);if(Number(idx)===3)setTimeout(enterStep24,0);return out;};
    }
  }catch(_){ }

  // Existing selector already belongs to the V31 bone. Listen additively; do not replace its onchange.
  document.addEventListener('DOMContentLoaded',()=>{
    ensureGenerateButton();
    syncSectorSelectFromPortfolio();
    const sel=q('sector-select'); if(sel)sel.addEventListener('change',()=>setTimeout(enterStep24,0));
  });

  window.refreshStep24FromPortfolio=enterStep24;
  window.generateStep24=generateStep24;
  window.confirmStep24=confirmStep24;
  window.saveStep24=saveStep24;
  window.reviseStep24=reviseStep24;
})();
