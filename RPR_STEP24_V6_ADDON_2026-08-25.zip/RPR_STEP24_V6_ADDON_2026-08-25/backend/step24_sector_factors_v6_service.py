"""Additive Step 2.4 V6 sector-inherent factor service.

Bone rule:
- This module DOES NOT replace or modify the existing V5.2 Step 2.4 service.
- It reuses only the approved model gateway, JSON parsing, metric/scoring validators,
  deterministic importance/weight/buffer arithmetic, and trace conventions.
- It DOES NOT call governed_sector() and DOES NOT require sector_inherent_factors.csv.
- Factor identity is generated from the supplied L1/L2/L3 sector under the approved V6.0 prompt.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List, Mapping

from step24_sector_factors_service import (
    BUFFER_REDUCTION,
    IMPORTANCE_SCORE,
    VULN_BANDS,
    BUFFER_BANDS,
    VULN_DIR,
    BUFFER_DIR,
    Step24DataError,
    Step24ModelError,
    _gateway_call,
    _metric,
    _parse_json,
    _read,
    _scoring,
    _text,
    _REASONING_MODEL,
    _REASONING_TIMEOUT,
    _REVISION_MODEL,
    _REVISION_TIMEOUT,
    _REPAIR_MODEL,
)

BASE_DIR = Path(__file__).resolve().parent
PROMPT_PATH_V6 = BASE_DIR / "prompts" / "step24_sector_inherent_v6_0.txt"

_MIN_FACTORS = 4
_MAX_FACTORS = 5


def _sector_ref(sector: Mapping[str, Any] | str) -> Dict[str, str]:
    if isinstance(sector, str):
        l1 = ""
        l2 = ""
        l3 = _text(sector)
        sid = ""
        label = l3
    else:
        l1 = _text(sector.get("l1"))
        l2 = _text(sector.get("l2"))
        l3 = _text(sector.get("l3") or sector.get("name") or sector.get("sector_label"))
        sid = _text(sector.get("id"))
        label = _text(sector.get("sector_label") or sector.get("name") or l3)
    if not l3:
        raise Step24DataError("Step 2.4 V6 requires a confirmed L3 sector")
    return {"id": sid, "l1": l1, "l2": l2, "l3": l3, "name": l3, "sector_label": label, "version": "V6.0"}


def _factor_identity(f: Mapping[str, Any], idx: int) -> Dict[str, str]:
    name = _text(f.get("name"))
    details = _text(f.get("details") or f.get("structural_rationale") or f.get("rationale"))
    structural = _text(f.get("structural_rationale") or details)
    source_basis = _text(f.get("source_basis"))
    persistence = _text(f.get("persistence_test")).upper()
    if not name:
        raise Step24ModelError(f"Step 2.4 V6 factor {idx} is missing name")
    if not details:
        raise Step24ModelError(f"Step 2.4 V6 factor '{name}' is missing details/structural rationale")
    if not structural:
        raise Step24ModelError(f"Step 2.4 V6 factor '{name}' is missing structural_rationale")
    if not source_basis:
        raise Step24ModelError(f"Step 2.4 V6 factor '{name}' is missing source_basis")
    if persistence != "PASS":
        raise Step24ModelError(f"Step 2.4 V6 factor '{name}' did not pass the Structural Persistence Test")
    return {
        "name": name,
        "details": details,
        "structural_rationale": structural,
        "source_basis": source_basis,
        "persistence_test": "PASS",
    }


def _validate_v6(obj: Mapping[str, Any], sector: Mapping[str, Any] | str) -> Dict[str, Any]:
    sec = _sector_ref(sector)
    raw_factors = obj.get("factors")
    if not isinstance(raw_factors, list):
        raise Step24ModelError("Step 2.4 V6 output must contain factors[]")
    if not (_MIN_FACTORS <= len(raw_factors) <= _MAX_FACTORS):
        raise Step24ModelError(
            f"Step 2.4 V6 requires {_MIN_FACTORS}-{_MAX_FACTORS} sector-inherent factors; model returned {len(raw_factors)}"
        )

    seen_names = set()
    factors: List[Dict[str, Any]] = []
    for idx, raw in enumerate(raw_factors, 1):
        if not isinstance(raw, dict):
            raise Step24ModelError(f"Step 2.4 V6 factor {idx} must be an object")
        ident = _factor_identity(raw, idx)
        norm_name = " ".join(ident["name"].casefold().split())
        if norm_name in seen_names:
            raise Step24ModelError(f"Step 2.4 V6 returned duplicate factor '{ident['name']}'")
        seen_names.add(norm_name)

        importance = _text(raw.get("importance")).upper()
        if importance not in IMPORTANCE_SCORE:
            raise Step24ModelError(f"Factor '{ident['name']}' importance must be HIGH or MEDIUM")

        vuln = [_metric(m, VULN_BANDS, VULN_DIR, "Vulnerability") for m in (raw.get("vulnerability_metrics") or [])]
        buf = [_metric(m, BUFFER_BANDS, BUFFER_DIR, "Buffer") for m in (raw.get("buffer_metrics") or [])]
        if len(vuln) < 3 or len(buf) < 3:
            raise Step24ModelError(f"Factor '{ident['name']}' requires at least 3 vulnerability and 3 buffer metrics")
        if len(vuln) != len(buf):
            raise Step24ModelError(f"Factor '{ident['name']}' Set 1 and Set 2 metric counts must match")

        critical_obj = raw.get("critical_threshold") or {}
        operator = _text(critical_obj.get("operator") or "AND").upper()
        critical = [_text(x) for x in (critical_obj.get("conditions") or []) if _text(x)]
        if operator != "AND":
            raise Step24ModelError(f"Factor '{ident['name']}' critical threshold operator must be AND")
        if len(critical) < 3:
            raise Step24ModelError(
                f"Factor '{ident['name']}' critical threshold requires at least 3 simultaneous AND conditions"
            )

        try:
            raw_score = int(raw.get("reference_raw_score"))
        except Exception as exc:
            raise Step24ModelError(f"Factor '{ident['name']}' reference_raw_score must be an integer") from exc
        # Sector-reference methodology only; no issuer observations exist at Step 2.4.
        raw_score = max(1, min(4, raw_score))

        strength = _text(raw.get("reference_buffer_strength")).upper()
        if strength not in BUFFER_REDUCTION:
            raise Step24ModelError(f"Factor '{ident['name']}' has invalid reference_buffer_strength")
        reduction = BUFFER_REDUCTION[strength]
        net = max(1, min(5, raw_score - reduction))

        factors.append({
            "factor_id": f"RF{idx}",
            "factor_order": idx,
            **ident,
            "rationale": _text(raw.get("rationale")) or ident["structural_rationale"],
            "narrative": _text(raw.get("rationale")) or ident["structural_rationale"],
            "importance": importance,
            "importance_score": IMPORTANCE_SCORE[importance],
            "importance_justification": _text(raw.get("importance_justification")),
            "vulnerability_metrics": vuln,
            "critical_threshold": {"operator": "AND", "conditions": critical},
            "buffer_metrics": buf,
            "key_principle": _text(raw.get("key_principle")),
            "scoring": _scoring(raw.get("scoring") or []),
            "reference_raw_score": raw_score,
            "reference_buffer_strength": strength,
            "buffer_credit_points": reduction,
            "buffer_adjustment": -reduction,
            "net_reference_score": net,
            "credit_implication": _text(raw.get("credit_implication")),
        })

    total_imp = sum(f["importance_score"] for f in factors)
    if total_imp <= 0:
        raise Step24ModelError("Step 2.4 V6 importance total must be positive")

    running = 0.0
    for i, f in enumerate(factors):
        if i == len(factors) - 1:
            weight = round(100.0 - running, 2)
        else:
            weight = round(f["importance_score"] / total_imp * 100.0, 2)
            running += weight
        f["weight_pct"] = weight

    weight_sum = round(sum(f["weight_pct"] for f in factors), 2)
    composite = round(sum((f["weight_pct"] / 100.0) * f["net_reference_score"] for f in factors), 3)
    overview = _text(obj.get("sector_overview") or obj.get("sector_preamble"))

    return {
        "state": "GENERATED",
        "framework_version": "V6.0",
        "factor_source": "MODEL_GENERATED_SECTOR_INHERENT",
        "sector": sec,
        "sector_overview": overview,
        "sector_preamble": _text(obj.get("sector_preamble")) or overview,
        "factors": factors,
        "weights_sum_pct": weight_sum,
        "composite_reference_score": composite,
        "scoring_formula": "net=max(1, raw-buffer_credit_points); composite=sum(weight*net)",
        "methodology_note": (
            "V6.0 independently identifies 4-5 structural sector-inherent factors from L1/L2/L3, "
            "then applies deterministic importance, weighting and buffer-credit arithmetic. "
            "Issuer scoring remains downstream."
        ),
    }


def _generation_input(sector: Mapping[str, Any] | str, as_of_date: str = "") -> str:
    sec = _sector_ref(sector)
    return json.dumps(
        {
            "sector": {"l1": sec["l1"], "l2": sec["l2"], "l3": sec["l3"]},
            "reference_as_of_date": _text(as_of_date) or "CURRENT_DATE",
            "instruction": (
                "Independently identify 4-5 sector-inherent factors. Do not require or infer any pre-approved CSV factor list."
            ),
        },
        ensure_ascii=False,
        indent=2,
    )


def _repair_v6(raw: str, error_message: str, sector: Mapping[str, Any] | str) -> Dict[str, Any]:
    if not _REPAIR_MODEL:
        raise Step24ModelError(error_message)
    system = (
        "Repair ONLY the JSON structure and contract compliance of an RPR Step 2.4 V6 response. "
        "Preserve the substantive sector-inherent factor analysis. Return JSON only. "
        "The output must contain 4-5 distinct structural factors and must not introduce event-driven factors."
    )
    user = (
        "SECTOR:\n" + _generation_input(sector) +
        "\n\nVALIDATION ERROR:\n" + error_message +
        "\n\nRAW OUTPUT:\n" + raw
    )
    repaired_raw = _gateway_call(_REPAIR_MODEL, system, user, _REVISION_TIMEOUT, "step24_v6_structural_repair")
    return _parse_json(repaired_raw)


def generate_v6(
    sector: Mapping[str, Any] | str,
    confirmed_portfolio: Mapping[str, Any] | None = None,
    as_of_date: str = "",
) -> Dict[str, Any]:
    # confirmed_portfolio is accepted for provenance only and is deliberately not fed to the model.
    _ = confirmed_portfolio
    system = _read(PROMPT_PATH_V6)
    user = "STEP 2.4 V6 INPUT:\n" + _generation_input(sector, as_of_date)
    raw = _gateway_call(_REASONING_MODEL, system, user, _REASONING_TIMEOUT, "step24_v6_sector_inherent_reasoning")
    try:
        parsed = _parse_json(raw)
        out = _validate_v6(parsed, sector)
    except (Step24ModelError, ValueError) as first_error:
        repaired = _repair_v6(raw, str(first_error), sector)
        out = _validate_v6(repaired, sector)
        out["repaired"] = True
    out["model_path"] = f"R2D2 {_REASONING_MODEL} Step2.4 V6 independent factor generation -> deterministic validation/weighting"
    out["models_triggered"] = [
        {"provider": "r2d2", "model": _REASONING_MODEL, "role": "step24_v6_sector_inherent_reasoning"}
    ]
    return out


def revise_v6(
    sector: Mapping[str, Any] | str,
    base_framework: Mapping[str, Any],
    confirmed_feedback: str,
) -> Dict[str, Any]:
    instruction = _text(confirmed_feedback)
    if not instruction:
        raise Step24DataError("Confirmed Step 2.4 feedback is required")
    if not _REVISION_MODEL:
        raise Step24ModelError("No approved Sonnet 5 model configured for Step 2.4 V6 revision")

    system = (
        _read(PROMPT_PATH_V6)
        + "\n\nTARGETED REVISION MODE\n"
        + "Apply only the confirmed analyst instruction to the existing V6 framework. "
          "Keep the response within the same V6 JSON contract, 4-5 factors, structural-persistence rule, "
          "metric/scoring rules and deterministic-weighting contract. Return JSON only."
    )
    user = json.dumps(
        {
            "sector": _sector_ref(sector),
            "base_framework": base_framework,
            "confirmed_analyst_feedback": instruction,
        },
        ensure_ascii=False,
        indent=2,
    )
    raw = _gateway_call(_REVISION_MODEL, system, user, _REVISION_TIMEOUT, "step24_v6_targeted_revision")
    try:
        parsed = _parse_json(raw)
        out = _validate_v6(parsed, sector)
    except (Step24ModelError, ValueError) as first_error:
        repaired = _repair_v6(raw, str(first_error), sector)
        out = _validate_v6(repaired, sector)
        out["repaired"] = True

    out["state"] = "REVISED"
    out["model_path"] = f"R2D2 {_REVISION_MODEL} Step2.4 V6 targeted revision -> deterministic validation/weighting"
    out["models_triggered"] = [
        {"provider": "r2d2", "model": _REVISION_MODEL, "role": "step24_v6_targeted_revision"}
    ]
    return out


def finalize_v6(sector: Mapping[str, Any] | str, framework: Mapping[str, Any]) -> Dict[str, Any]:
    # Rebuild a model-like object and run one deterministic V6 validation pass.
    factors = []
    for f in framework.get("factors") or []:
        factors.append({
            "factor_order": f.get("factor_order"),
            "name": f.get("name"),
            "details": f.get("details"),
            "structural_rationale": f.get("structural_rationale") or f.get("details") or f.get("rationale"),
            "source_basis": f.get("source_basis") or "Analyst-confirmed V6 framework",
            "persistence_test": f.get("persistence_test") or "PASS",
            "rationale": f.get("rationale") or f.get("narrative"),
            "importance": f.get("importance"),
            "importance_justification": f.get("importance_justification"),
            "vulnerability_metrics": f.get("vulnerability_metrics"),
            "critical_threshold": f.get("critical_threshold"),
            "buffer_metrics": f.get("buffer_metrics"),
            "key_principle": f.get("key_principle"),
            "scoring": f.get("scoring"),
            "reference_raw_score": f.get("reference_raw_score"),
            "reference_buffer_strength": f.get("reference_buffer_strength"),
            "credit_implication": f.get("credit_implication"),
        })

    out = _validate_v6(
        {
            "sector_overview": framework.get("sector_overview"),
            "sector_preamble": framework.get("sector_preamble"),
            "factors": factors,
        },
        sector,
    )
    out["state"] = "CONFIRMED"
    out["model_path"] = "deterministic Step 2.4 V6 finalization"
    out["models_triggered"] = []
    return out
