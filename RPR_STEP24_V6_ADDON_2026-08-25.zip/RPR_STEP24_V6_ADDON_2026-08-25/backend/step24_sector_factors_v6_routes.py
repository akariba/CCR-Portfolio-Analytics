"""Additive FastAPI routes for RPR Step 2.4 V6.

The existing V5.2 router remains untouched.
"""
from __future__ import annotations

from typing import Any, Dict
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from step24_sector_factors_service import Step24DataError, Step24ModelError
from step24_sector_factors_v6_service import finalize_v6, generate_v6, revise_v6

router = APIRouter(
    prefix="/api/v1/rpr/step24/sector-factors",
    tags=["RPR Step 2.4 Sector-Inherent Risk Factors V6"],
)


class SectorRef(BaseModel):
    id: str = ""
    l1: str = ""
    l2: str = ""
    l3: str = ""
    name: str = ""
    sector_label: str = ""


class GenerateV6Request(BaseModel):
    sector: SectorRef
    confirmed_portfolio: Dict[str, Any] = Field(default_factory=dict)
    as_of_date: str = ""


class ReviseV6Request(BaseModel):
    sector: SectorRef
    base_framework: Dict[str, Any]
    confirmed_feedback: str


class FinalizeV6Request(BaseModel):
    sector: SectorRef
    framework: Dict[str, Any]


def _handle(func, *args):
    try:
        return func(*args)
    except Step24DataError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except Step24ModelError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@router.post("/generate-v6")
def step24_generate_v6(req: GenerateV6Request) -> Dict[str, Any]:
    return _handle(
        generate_v6,
        req.sector.model_dump(),
        req.confirmed_portfolio,
        req.as_of_date,
    )


@router.post("/revise-v6")
def step24_revise_v6(req: ReviseV6Request) -> Dict[str, Any]:
    return _handle(
        revise_v6,
        req.sector.model_dump(),
        req.base_framework,
        req.confirmed_feedback,
    )


@router.post("/finalize-v6")
def step24_finalize_v6(req: FinalizeV6Request) -> Dict[str, Any]:
    return _handle(finalize_v6, req.sector.model_dump(), req.framework)
