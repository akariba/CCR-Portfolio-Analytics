#!/usr/bin/env python3
r"""Fail-fast additive installer for RPR Step 2.4 V6.

Usage:
    python apply_rpr_step24_v6.py "C:\...\Rapid Portfolio Review_AI"

If no path is supplied, the script searches the current directory and its parents.
It backs up every existing file it modifies. Existing V5.2 Step2.4 service/routes/data are untouched.
"""
from __future__ import annotations

import shutil
import sys
from datetime import datetime
from pathlib import Path


HERE = Path(__file__).resolve().parent
STAMP = datetime.now().strftime("%Y%m%d_%H%M%S")


def fail(msg: str) -> None:
    raise SystemExit("ABORTED — " + msg)


def find_root() -> Path:
    if len(sys.argv) > 1:
        p = Path(sys.argv[1]).expanduser().resolve()
        if (p / "backend").is_dir() and (p / "UI Design").is_dir():
            return p
        fail(f"Provided project root does not contain backend + UI Design: {p}")
    candidates = [Path.cwd().resolve(), *Path.cwd().resolve().parents, HERE.parent.resolve(), *HERE.parent.resolve().parents]
    seen = set()
    for p in candidates:
        if p in seen:
            continue
        seen.add(p)
        if (p / "backend").is_dir() and (p / "UI Design").is_dir():
            return p
    fail("Could not locate project root. Pass it explicitly as the first argument.")


def backup(path: Path) -> Path:
    dst = path.with_name(path.name + f".bone-backup-{STAMP}")
    shutil.copy2(path, dst)
    return dst


root = find_root()
backend = root / "backend"
ui = root / "UI Design"
server = backend / "server.py"
frontend = ui / "rpr_step24_append.js"

required = [
    server,
    frontend,
    backend / "step24_sector_factors_service.py",
    backend / "step24_sector_factors_routes.py",
]
missing = [str(p) for p in required if not p.exists()]
if missing:
    fail("Required current-bone files are missing:\n" + "\n".join(missing))

# Preflight exact old Step2.4 router anchors before touching anything.
server_text = server.read_text(encoding="utf-8-sig")
import_anchor = "from step24_sector_factors_routes import router as step24_router"
include_anchor = "app.include_router(step24_router)"
if import_anchor not in server_text:
    fail("Current server.py does not contain the expected Step2.4 import anchor. No files changed.")
if include_anchor not in server_text:
    fail("Current server.py does not contain the expected Step2.4 include_router anchor. No files changed.")

front_text = frontend.read_text(encoding="utf-8-sig")
expected_old = [
    "/api/v1/rpr/step24/sector-factors/generate",
    "/api/v1/rpr/step24/sector-factors/revise",
    "/api/v1/rpr/step24/sector-factors/finalize",
]
if not all(x in front_text or (x + "-v6") in front_text for x in expected_old):
    fail("Current rpr_step24_append.js does not expose the expected Step2.4 endpoint contract. No files changed.")

# Back up only existing files that will be modified.
server_backup = backup(server)
frontend_backup = backup(frontend)

# Copy new additive backend files + prompt.
for rel in [
    Path("backend/step24_sector_factors_v6_service.py"),
    Path("backend/step24_sector_factors_v6_routes.py"),
    Path("backend/prompts/step24_sector_inherent_v6_0.txt"),
]:
    src = HERE / rel
    dst = root / rel
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)

# Add V6 router import/include adjacent to the existing V5.2 router.
server_text = server.read_text(encoding="utf-8-sig")
v6_import = "from step24_sector_factors_v6_routes import router as step24_v6_router"
v6_include = "app.include_router(step24_v6_router)"
if v6_import not in server_text:
    server_text = server_text.replace(import_anchor, import_anchor + "\n" + v6_import, 1)
if v6_include not in server_text:
    server_text = server_text.replace(include_anchor, include_anchor + "\n" + v6_include, 1)
server.write_text(server_text, encoding="utf-8")

# Replace only the Step2.4 append file with the V6 endpoint-wired version.
shutil.copy2(HERE / "frontend_replace" / "rpr_step24_append.js", frontend)

print("PASS — RPR Step 2.4 V6 additive branch installed.")
print("V5.2 SERVICE/ROUTES/DATA: UNTOUCHED")
print("NEW ROUTES: generate-v6 / revise-v6 / finalize-v6")
print("BACKUPS:")
print(" ", server_backup)
print(" ", frontend_backup)
print("NEXT: restart backend using your already-working approved venv and open the same HTML.")
