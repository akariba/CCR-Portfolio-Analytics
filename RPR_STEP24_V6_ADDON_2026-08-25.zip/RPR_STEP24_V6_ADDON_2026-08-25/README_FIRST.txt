RPR STEP 2.4 V6.0 ADDITIVE PACKAGE — 2026-08-25
===================================================

PURPOSE
Implement the approved V6.0 Step 2.4 architecture without rewriting the working V5.2 bone.

WHAT CHANGES
1. NEW backend/step24_sector_factors_v6_service.py
   - takes confirmed Sector L1/L2/L3
   - DOES NOT call governed_sector()
   - DOES NOT require sector_inherent_factors.csv
   - Opus independently returns 4-5 sector-inherent factors under V6.0
   - deterministic Python still owns HIGH=2 / MEDIUM=1, weights=100%, buffer credits and net/composite arithmetic

2. NEW backend/step24_sector_factors_v6_routes.py
   - POST /api/v1/rpr/step24/sector-factors/generate-v6
   - POST /api/v1/rpr/step24/sector-factors/revise-v6
   - POST /api/v1/rpr/step24/sector-factors/finalize-v6

3. NEW backend/prompts/step24_sector_inherent_v6_0.txt
   - based on the V6.0 prompt supplied in the screenshots
   - adds only the machine-readable JSON contract needed by the existing app

4. REPLACE ONLY UI Design/rpr_step24_append.js
   - based on the current fixed Step2.4 append file from this conversation
   - switches generate/revise/finalize to the V6 endpoints
   - no CSS/layout/v31 structure change

5. ADD two lines to backend/server.py
   from step24_sector_factors_v6_routes import router as step24_v6_router
   app.include_router(step24_v6_router)

WHAT DOES NOT CHANGE
- Step 1
- Step 2.1
- Step 2.2
- Step 2.3
- v31 HTML/CSS/layout
- existing Step2.4 V5.2 service/routes
- existing sector_inherent_factors.csv
- model gateway
- approved model identifiers
- existing V5.2 rollback path

INSTALL — SAFEST
A. Extract this folder anywhere.
B. Run:
   python apply_rpr_step24_v6.py "C:\Users\ak547743\Downloads\OneDrive_2026-07-16\Rapid Portfolio Review_AI"

The installer fails before modifying files if the current Step2.4 bone anchors do not match.
It backs up server.py and rpr_step24_append.js before changing them.

VALIDATE
   python validate_rpr_step24_v6.py "C:\Users\ak547743\Downloads\OneDrive_2026-07-16\Rapid Portfolio Review_AI"

START
Use the SAME approved venv / backend start command that is already working on your machine.
Do not change execution policy and do not install a new environment for this package.

EXPECTED STEP2.4 FLOW
Step2.2 confirmed L1/L2/L3
  -> /generate-v6
  -> Opus V6.0 generates 4-5 structural factors
  -> deterministic validation / scoring / weighting
  -> existing Step2.4 renderer
  -> analyst Save / Feedback
  -> /revise-v6 if used
  -> /finalize-v6
  -> confirmed Step2.4 output

IMPORTANT QUALITY BOUNDARY
This package does not add a new web-search dependency. It implements the approved minimal V6 branch using the existing R2D2 Opus gateway.
The V6 prompt requires concise source-basis categories and structural-persistence validation, but the package does not claim a separate live retrieval step.
A Gemini enterprise-research pre-pass can be added later as a separate approved enhancement without changing this V6 contract.
