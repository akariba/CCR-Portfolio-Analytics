from __future__ import annotations
import sys
from pathlib import Path

HERE = Path(__file__).resolve()
PKG = HERE.parents[1]
BACKEND = PKG / "backend"
sys.path.insert(0, str(BACKEND))

# The package service imports the existing V5.2 module from the target project in real use.
# These tests are intended to be copied into the real project/tests folder after installation.
from step24_sector_factors_v6_service import _validate_v6, Step24ModelError


def metric_v(name):
    return {
        "metric": name, "source": "Sector disclosure", "formula": "A/B",
        "direction": "HIGHER_WORSE",
        "bands": {"VERY_HIGH": ">50%", "HIGH": "30-50%", "MODERATE": "15-30%", "LOW": "<15%"},
    }


def metric_b(name):
    return {
        "metric": name, "source": "Sector disclosure", "formula": "A/B",
        "direction": "HIGHER_STRONGER",
        "bands": {"STRONG": ">80%", "MODERATE": "60-80%", "WEAK": "40-60%", "NEGLIGIBLE": "<40%"},
    }


def factor(i, importance="HIGH"):
    return {
        "factor_order": i,
        "name": f"Structural Factor {i}",
        "details": f"Persistent credit mechanism {i}",
        "structural_rationale": f"Applies across cycles for mechanism {i}.",
        "source_basis": "Rating-agency sector outlook",
        "persistence_test": "PASS",
        "rationale": "Structural FCF transmission.",
        "importance": importance,
        "importance_justification": "Sector-wide credit transmission.",
        "vulnerability_metrics": [metric_v("V1"), metric_v("V2"), metric_v("V3")],
        "critical_threshold": {"operator": "AND", "conditions": ["A", "B", "C"]},
        "buffer_metrics": [metric_b("B1"), metric_b("B2"), metric_b("B3")],
        "key_principle": "Buffers reduce residual exposure.",
        "scoring": [
            {"score": 5, "vulnerability_profile": "critical", "buffer_profile": "negligible"},
            {"score": 4, "vulnerability_profile": "high", "buffer_profile": "weak"},
            {"score": 3, "vulnerability_profile": "moderate", "buffer_profile": "moderate"},
            {"score": 2, "vulnerability_profile": "low", "buffer_profile": "strong"},
            {"score": 1, "vulnerability_profile": "minimal", "buffer_profile": "strong"},
        ],
        "reference_raw_score": 3,
        "reference_buffer_strength": "WEAK",
        "credit_implication": "Persistent credit impact.",
    }


def test_v6_accepts_four_model_generated_factors_and_weights_to_100():
    obj = {"sector_overview": "Sector overview.", "factors": [factor(1), factor(2), factor(3, "MEDIUM"), factor(4, "MEDIUM")]}
    out = _validate_v6(obj, {"l1": "TMT", "l2": "Technology", "l3": "Software"})
    assert len(out["factors"]) == 4
    assert out["weights_sum_pct"] == 100.0
    assert out["factor_source"] == "MODEL_GENERATED_SECTOR_INHERENT"


def test_v6_rejects_predefined_count_contract_outside_4_5():
    obj = {"factors": [factor(1), factor(2), factor(3)]}
    try:
        _validate_v6(obj, {"l3": "Software"})
    except Step24ModelError:
        return
    raise AssertionError("Expected Step24ModelError")


def test_v6_rejects_failed_structural_persistence():
    f = factor(1)
    f["persistence_test"] = "FAIL"
    obj = {"factors": [f, factor(2), factor(3), factor(4)]}
    try:
        _validate_v6(obj, {"l3": "Software"})
    except Step24ModelError:
        return
    raise AssertionError("Expected Step24ModelError")
