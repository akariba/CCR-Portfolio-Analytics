"""FastAPI routes for deterministic RPR Step 2.2 Portfolio Selection.

This router is additive and can be included by server.py without changing the existing
Step 2.1 / Step 2.3 router.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, ConfigDict, Field

from step22_portfolio_service import Step22DataError, Step22PortfolioService


router = APIRouter(
    prefix="/api/v1/rpr/step2/portfolio",
    tags=["RPR Step 2.2 Portfolio Selection"],
)

_service: Optional[Step22PortfolioService] = None


def get_step22_service() -> Step22PortfolioService:
    global _service
    if _service is None:
        _service = Step22PortfolioService()
    return _service


class PortfolioSearchRequest(BaseModel):
    model_config = ConfigDict(extra="ignore")

    geography: str = ""
    country: str = ""
    mle: str = ""
    l1: str = ""
    l2: str = ""
    # Additive multi-select contract. Scalar fields above remain for backward compatibility.
    geographies: List[str] = Field(default_factory=list)
    countries: List[str] = Field(default_factory=list)
    mles: List[str] = Field(default_factory=list)
    l1_categories: List[str] = Field(default_factory=list)
    l2_categories: List[str] = Field(default_factory=list)
    # Stylus/current frontend contract calls this `l3`, but the values are stable
    # backend sector IDs from catalog.sectors[].id.
    l3: List[str] = Field(default_factory=list)
    selected_sector_ids: List[str] = Field(default_factory=list)


class PortfolioFinalizeRequest(BaseModel):
    model_config = ConfigDict(extra="ignore")

    filters: Dict[str, Any] = Field(default_factory=dict)
    selected_sector_ids: List[str] = Field(default_factory=list)
    companies: List[Dict[str, Any]] = Field(default_factory=list)


@router.get("/catalog")
def portfolio_catalog() -> Dict[str, Any]:
    try:
        return get_step22_service().catalog()
    except Step22DataError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc


@router.post("/search")
def portfolio_search(req: PortfolioSearchRequest) -> Dict[str, Any]:
    try:
        sector_ids = req.selected_sector_ids or req.l3
        return get_step22_service().search(
            geography=req.geography,
            country=req.country,
            mle=req.mle,
            l1=req.l1,
            l2=req.l2,
            geographies=req.geographies,
            countries=req.countries,
            mles=req.mles,
            l1_categories=req.l1_categories,
            l2_categories=req.l2_categories,
            sector_ids=sector_ids,
        )
    except Step22DataError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc


@router.post("/finalize")
def portfolio_finalize(req: PortfolioFinalizeRequest) -> Dict[str, Any]:
    try:
        return get_step22_service().finalize(
            filters=req.filters,
            selected_sector_ids=req.selected_sector_ids,
            companies=req.companies,
        )
    except Step22DataError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
