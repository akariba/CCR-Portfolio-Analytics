"""Deterministic Step 2.2 portfolio-selection service.

Additive module: does not replace or modify the existing Step 2.1 / Step 2.3 service.

Design rules:
- No LLM/model calls.
- No public-web calls.
- CSV-backed demo catalog, reloadable when files change.
- Frontend receives hierarchy/filter data from this backend; it must not hard-code the
  company universe or sector taxonomy.
- L2 selected with no explicit L3 sector selection means all valid L3 sectors under L2.
"""

from __future__ import annotations

import csv
import hashlib
import json
import os
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple


class Step22DataError(RuntimeError):
    pass


def _text(value: Any) -> str:
    return str(value or "").strip()


def _slug_hash(parts: Sequence[str]) -> str:
    material = "|".join(_text(p).lower() for p in parts)
    digest = hashlib.sha256(material.encode("utf-8")).hexdigest()[:12]
    return f"sec-{digest}"


class Step22PortfolioService:
    """CSV-backed portfolio catalog with automatic file-change reload."""

    COMPANY_FILE = "rpr_company_master.csv"
    SECTOR_FILE = "rpr_sector_hierarchy.csv"
    COUNTRY_FILE = "rpr_country_geography.csv"
    MLE_FILE = "rpr_mle_reference.csv"

    def __init__(self, data_dir: Optional[Path | str] = None) -> None:
        default_dir = Path(__file__).resolve().parent / "data" / "step22"
        configured = os.environ.get("RPR_STEP22_DATA_DIR", "").strip()
        self.data_dir = Path(data_dir or configured or default_dir).resolve()
        self._lock = threading.RLock()
        self._fingerprint: Tuple[Tuple[str, int, int], ...] = ()
        self._companies: List[Dict[str, Any]] = []
        self._countries: List[Dict[str, str]] = []
        self._mles: List[Dict[str, str]] = []
        self._sector_rows: List[Dict[str, str]] = []
        self._sector_by_id: Dict[str, Dict[str, str]] = {}
        self._l3_sector_rows: List[Dict[str, str]] = []
        self._ensure_loaded(force=True)

    def _paths(self) -> List[Path]:
        return [
            self.data_dir / self.COMPANY_FILE,
            self.data_dir / self.SECTOR_FILE,
            self.data_dir / self.COUNTRY_FILE,
            self.data_dir / self.MLE_FILE,
        ]

    def _current_fingerprint(self) -> Tuple[Tuple[str, int, int], ...]:
        parts = []
        for path in self._paths():
            if not path.exists():
                raise Step22DataError(f"Required Step 2.2 data file is missing: {path}")
            stat = path.stat()
            parts.append((path.name, int(stat.st_mtime_ns), int(stat.st_size)))
        return tuple(parts)

    @staticmethod
    def _read_csv(path: Path) -> List[Dict[str, str]]:
        with path.open("r", encoding="utf-8-sig", newline="") as handle:
            return [{k: _text(v) for k, v in row.items()} for row in csv.DictReader(handle)]

    def _ensure_loaded(self, force: bool = False) -> None:
        with self._lock:
            fingerprint = self._current_fingerprint()
            if not force and fingerprint == self._fingerprint:
                return

            companies = self._read_csv(self.data_dir / self.COMPANY_FILE)
            sectors = self._read_csv(self.data_dir / self.SECTOR_FILE)
            countries = self._read_csv(self.data_dir / self.COUNTRY_FILE)
            mles = self._read_csv(self.data_dir / self.MLE_FILE)

            if not companies:
                raise Step22DataError("Step 2.2 company master is empty.")
            if not sectors:
                raise Step22DataError("Step 2.2 sector hierarchy is empty.")

            required_company = {
                "cagid",
                "cagid_name",
                "enr_reln_naics_industry_sector_l1_name",
                "enr_reln_naics_industry_sector_l2_name",
                "enr_reln_naics_industry_sector_l3_name",
                "enr_reln_naics_industry_sector_l4_name",
                "rel_cntry_risk_code",
                "mle_code",
                "mle_name",
                "geography",
            }
            missing_company = required_company - set(companies[0])
            if missing_company:
                raise Step22DataError(
                    "Step 2.2 company master is missing columns: "
                    + ", ".join(sorted(missing_company))
                )

            # Current v31 Step 2.2 cards are L3 cards. L4 remains available in the
            # company payload for later expansion, but is not exposed as a separate
            # visual level by default.
            l3_seen = set()
            l3_sectors: List[Dict[str, str]] = []
            sector_by_id: Dict[str, Dict[str, str]] = {}
            for row in sectors:
                if _text(row.get("active_flag") or "Y").upper() not in {"Y", "YES", "TRUE", "1"}:
                    continue
                l1 = row.get("enr_reln_naics_industry_sector_l1_name", "")
                l2 = row.get("enr_reln_naics_industry_sector_l2_name", "")
                l3 = row.get("enr_reln_naics_industry_sector_l3_name", "")
                if not l2 or not l3:
                    continue
                key = (l1, l2, l3)
                if key in l3_seen:
                    continue
                l3_seen.add(key)
                sector_id = _slug_hash(key)
                item = {"id": sector_id, "l1": l1, "l2": l2, "l3": l3}
                l3_sectors.append(item)
                sector_by_id[sector_id] = item

            self._companies = companies
            self._sector_rows = sectors
            self._countries = countries
            self._mles = mles
            self._l3_sector_rows = sorted(
                l3_sectors, key=lambda x: (x["l1"].lower(), x["l2"].lower(), x["l3"].lower())
            )
            self._sector_by_id = sector_by_id
            self._fingerprint = fingerprint

    def _sector_id_for_company(self, row: Dict[str, str]) -> str:
        key = (
            row.get("enr_reln_naics_industry_sector_l1_name", ""),
            row.get("enr_reln_naics_industry_sector_l2_name", ""),
            row.get("enr_reln_naics_industry_sector_l3_name", ""),
        )
        return _slug_hash(key)

    def _company_to_api(self, row: Dict[str, str]) -> Dict[str, Any]:
        return {
            "cagid": row.get("cagid", ""),
            "company_name": row.get("cagid_name", ""),
            "sector_id": self._sector_id_for_company(row),
            "sector_label": row.get("enr_reln_naics_industry_sector_l3_name", ""),
            "l1": row.get("enr_reln_naics_industry_sector_l1_name", ""),
            "l2": row.get("enr_reln_naics_industry_sector_l2_name", ""),
            "l3": row.get("enr_reln_naics_industry_sector_l3_name", ""),
            "l4": row.get("enr_reln_naics_industry_sector_l4_name", ""),
            "country": row.get("rel_cntry_risk_code", ""),
            "mle": row.get("mle_name", ""),
            "mle_code": row.get("mle_code", ""),
            "geography": row.get("geography", ""),
            "risk_rating": row.get("rel_risk_rating_code", ""),
            "credit_classification": row.get("rel_credit_classification_name", ""),
            "portfolio_status": row.get("portfolio_status", ""),
            "demo_exposure_usd_m": row.get("demo_exposure_usd_m", ""),
        }

    def catalog(self) -> Dict[str, Any]:
        self._ensure_loaded()
        geographies = sorted(
            {_text(r.get("geography")) for r in self._countries if _text(r.get("geography"))},
            key=str.lower,
        )
        countries = [
            {
                "code": r.get("rel_cntry_risk_code", ""),
                "name": r.get("country_name", ""),
                "geography": r.get("geography", ""),
            }
            for r in self._countries
            if _text(r.get("active_flag") or "Y").upper() in {"Y", "YES", "TRUE", "1"}
        ]
        countries.sort(key=lambda x: (x["geography"].lower(), x["name"].lower()))
        mles = [
            {
                "code": r.get("mle_code", ""),
                "name": r.get("mle_name", ""),
                "geography": r.get("geography", ""),
            }
            for r in self._mles
            if _text(r.get("active_flag") or "Y").upper() in {"Y", "YES", "TRUE", "1"}
        ]
        mles.sort(key=lambda x: x["name"].lower())
        l2_categories = sorted({s["l2"] for s in self._l3_sector_rows}, key=str.lower)
        return {
            "geographies": geographies,
            "countries": countries,
            "mles": mles,
            "l2_categories": l2_categories,
            "sectors": list(self._l3_sector_rows),
            "metadata": {
                "source": "csv",
                "company_count": len(self._companies),
                "sector_count": len(self._l3_sector_rows),
                "reload_mode": "file_change_auto_reload",
            },
        }

    @staticmethod
    def _normalise_many(single: Any = "", multiple: Optional[Sequence[Any]] = None) -> List[str]:
        values = [_text(x) for x in (multiple or []) if _text(x)]
        if not values and _text(single):
            values = [_text(single)]
        # preserve order, remove duplicates case-insensitively
        seen = set()
        out: List[str] = []
        for value in values:
            key = value.lower()
            if key not in seen:
                seen.add(key)
                out.append(value)
        return out

    @staticmethod
    def _matches_any(row_value: Any, values: Sequence[str]) -> bool:
        if not values:
            return True
        actual = _text(row_value).lower()
        return actual in {v.lower() for v in values}

    def _filter_rows(
        self,
        *,
        geography: str = "",
        country: str = "",
        mle: str = "",
        l1: str = "",
        l2: str = "",
        geographies: Optional[Sequence[str]] = None,
        countries: Optional[Sequence[str]] = None,
        mles: Optional[Sequence[str]] = None,
        l1_categories: Optional[Sequence[str]] = None,
        l2_categories: Optional[Sequence[str]] = None,
        sector_ids: Optional[Sequence[str]] = None,
    ) -> List[Dict[str, str]]:
        geo_values = self._normalise_many(geography, geographies)
        country_values = self._normalise_many(country, countries)
        mle_values = self._normalise_many(mle, mles)
        l1_values = self._normalise_many(l1, l1_categories)
        l2_values = self._normalise_many(l2, l2_categories)

        selected = {_text(x) for x in (sector_ids or []) if _text(x)}
        selected_sector_keys = set()
        for sector_id in selected:
            sector = self._sector_by_id.get(sector_id)
            if sector:
                selected_sector_keys.add(
                    (
                        sector.get("l1", "").lower(),
                        sector.get("l2", "").lower(),
                        sector.get("l3", "").lower(),
                    )
                )

        out: List[Dict[str, str]] = []
        for row in self._companies:
            if not self._matches_any(row.get("geography"), geo_values):
                continue
            if not self._matches_any(row.get("rel_cntry_risk_code"), country_values):
                continue

            # Frontend may select one or many MLE codes. Accept codes or names.
            if mle_values:
                code = _text(row.get("mle_code")).lower()
                name = _text(row.get("mle_name")).lower()
                allowed = {v.lower() for v in mle_values}
                if code not in allowed and name not in allowed:
                    continue

            if not self._matches_any(
                row.get("enr_reln_naics_industry_sector_l1_name"), l1_values
            ):
                continue
            if not self._matches_any(
                row.get("enr_reln_naics_industry_sector_l2_name"), l2_values
            ):
                continue

            if selected:
                key = (
                    _text(row.get("enr_reln_naics_industry_sector_l1_name")).lower(),
                    _text(row.get("enr_reln_naics_industry_sector_l2_name")).lower(),
                    _text(row.get("enr_reln_naics_industry_sector_l3_name")).lower(),
                )
                if key not in selected_sector_keys:
                    continue
            out.append(row)
        return out

    def _valid_sectors(
        self,
        *,
        geography: str = "",
        country: str = "",
        mle: str = "",
        l1: str = "",
        l2: str = "",
        geographies: Optional[Sequence[str]] = None,
        countries: Optional[Sequence[str]] = None,
        mles: Optional[Sequence[str]] = None,
        l1_categories: Optional[Sequence[str]] = None,
        l2_categories: Optional[Sequence[str]] = None,
    ) -> List[Dict[str, str]]:
        # The L3 card grid is the cascading view: selecting one or many L2 values
        # returns only L3 sectors underneath those selected L2 values (and other filters).
        rows = self._filter_rows(
            geography=geography,
            country=country,
            mle=mle,
            l1=l1,
            l2=l2,
            geographies=geographies,
            countries=countries,
            mles=mles,
            l1_categories=l1_categories,
            l2_categories=l2_categories,
            sector_ids=[],
        )
        keys = {
            (
                _text(r.get("enr_reln_naics_industry_sector_l1_name")).lower(),
                _text(r.get("enr_reln_naics_industry_sector_l2_name")).lower(),
                _text(r.get("enr_reln_naics_industry_sector_l3_name")).lower(),
            )
            for r in rows
        }
        return [
            s
            for s in self._l3_sector_rows
            if (s["l1"].lower(), s["l2"].lower(), s["l3"].lower()) in keys
        ]

    def _valid_countries(
        self,
        *,
        geography: str = "",
        mle: str = "",
        l1: str = "",
        l2: str = "",
        geographies: Optional[Sequence[str]] = None,
        mles: Optional[Sequence[str]] = None,
        l1_categories: Optional[Sequence[str]] = None,
        l2_categories: Optional[Sequence[str]] = None,
    ) -> List[Dict[str, str]]:
        rows = self._filter_rows(
            geography=geography,
            country="",
            mle=mle,
            l1=l1,
            l2=l2,
            geographies=geographies,
            countries=[],
            mles=mles,
            l1_categories=l1_categories,
            l2_categories=l2_categories,
            sector_ids=[],
        )
        codes = {_text(r.get("rel_cntry_risk_code")).upper() for r in rows}
        out = [
            {
                "code": r.get("rel_cntry_risk_code", ""),
                "name": r.get("country_name", ""),
                "geography": r.get("geography", ""),
            }
            for r in self._countries
            if _text(r.get("rel_cntry_risk_code")).upper() in codes
        ]
        out.sort(key=lambda x: (x["geography"].lower(), x["name"].lower()))
        return out

    def _valid_mles(
        self,
        *,
        geography: str = "",
        country: str = "",
        l1: str = "",
        l2: str = "",
        geographies: Optional[Sequence[str]] = None,
        countries: Optional[Sequence[str]] = None,
        l1_categories: Optional[Sequence[str]] = None,
        l2_categories: Optional[Sequence[str]] = None,
    ) -> List[Dict[str, str]]:
        rows = self._filter_rows(
            geography=geography,
            country=country,
            mle="",
            l1=l1,
            l2=l2,
            geographies=geographies,
            countries=countries,
            mles=[],
            l1_categories=l1_categories,
            l2_categories=l2_categories,
            sector_ids=[],
        )
        codes = {_text(r.get("mle_code")) for r in rows}
        out = [
            {
                "code": r.get("mle_code", ""),
                "name": r.get("mle_name", ""),
                "geography": r.get("geography", ""),
            }
            for r in self._mles
            if _text(r.get("mle_code")) in codes
        ]
        out.sort(key=lambda x: x["name"].lower())
        return out

    def search(
        self,
        *,
        geography: str = "",
        country: str = "",
        mle: str = "",
        l1: str = "",
        l2: str = "",
        geographies: Optional[Sequence[str]] = None,
        countries: Optional[Sequence[str]] = None,
        mles: Optional[Sequence[str]] = None,
        l1_categories: Optional[Sequence[str]] = None,
        l2_categories: Optional[Sequence[str]] = None,
        sector_ids: Optional[Sequence[str]] = None,
    ) -> Dict[str, Any]:
        self._ensure_loaded()

        # Bible/business rule for Step 2.2:
        # one or many L2 values + no explicit L3 selection means ALL valid L3 sectors
        # underneath the selected L2 scope.
        rows = self._filter_rows(
            geography=geography,
            country=country,
            mle=mle,
            l1=l1,
            l2=l2,
            geographies=geographies,
            countries=countries,
            mles=mles,
            l1_categories=l1_categories,
            l2_categories=l2_categories,
            sector_ids=sector_ids or [],
        )
        companies = [self._company_to_api(r) for r in rows]
        companies.sort(key=lambda x: (x["company_name"].lower(), x["cagid"]))

        return {
            "companies": companies,
            "total_count": len(companies),
            "valid_filters": {
                "countries": self._valid_countries(
                    geography=geography,
                    mle=mle,
                    l1=l1,
                    l2=l2,
                    geographies=geographies,
                    mles=mles,
                    l1_categories=l1_categories,
                    l2_categories=l2_categories,
                ),
                "mles": self._valid_mles(
                    geography=geography,
                    country=country,
                    l1=l1,
                    l2=l2,
                    geographies=geographies,
                    countries=countries,
                    l1_categories=l1_categories,
                    l2_categories=l2_categories,
                ),
                "sectors": self._valid_sectors(
                    geography=geography,
                    country=country,
                    mle=mle,
                    l1=l1,
                    l2=l2,
                    geographies=geographies,
                    countries=countries,
                    mles=mles,
                    l1_categories=l1_categories,
                    l2_categories=l2_categories,
                ),
            },
        }

    def finalize(
        self,
        *,
        filters: Dict[str, Any],
        selected_sector_ids: Optional[Sequence[str]] = None,
        companies: Optional[Sequence[Dict[str, Any]]] = None,
    ) -> Dict[str, Any]:
        self._ensure_loaded()
        filters = dict(filters or {})

        geographies = self._normalise_many(filters.get("geography"), filters.get("geographies"))
        countries = self._normalise_many(filters.get("country"), filters.get("countries"))
        mles = self._normalise_many(filters.get("mle"), filters.get("mles"))
        l1_categories = self._normalise_many(filters.get("l1"), filters.get("l1_categories"))
        l2_categories = self._normalise_many(filters.get("l2"), filters.get("l2_categories"))

        result = self.search(
            geographies=geographies,
            countries=countries,
            mles=mles,
            l1_categories=l1_categories,
            l2_categories=l2_categories,
            sector_ids=selected_sector_ids or [],
        )
        universe = result["companies"]

        requested_cagids = {
            _text(item.get("cagid"))
            for item in (companies or [])
            if isinstance(item, dict) and _text(item.get("cagid"))
        }
        if requested_cagids:
            confirmed = [c for c in universe if c["cagid"] in requested_cagids]
        else:
            confirmed = universe

        material = {
            "filters": {
                "geographies": geographies,
                "countries": countries,
                "mles": mles,
                "l1_categories": l1_categories,
                "l2_categories": l2_categories,
            },
            "selected_sector_ids": sorted(
                {_text(x) for x in (selected_sector_ids or []) if _text(x)}
            ),
            "cagids": sorted(c["cagid"] for c in confirmed),
        }
        digest = hashlib.sha256(
            json.dumps(material, sort_keys=True, ensure_ascii=False).encode("utf-8")
        ).hexdigest()[:16]

        return {
            "status": "ok",
            "portfolio_id": f"step22-{digest}",
            "confirmed_at": datetime.now(timezone.utc).isoformat(),
            "filters": material["filters"],
            "selected_sector_ids": material["selected_sector_ids"],
            "company_count": len(confirmed),
            "companies": confirmed,
            "source": "step22_csv_catalog",
        }
