# server.py — additive integration only

Do not replace server.py. Add only:

```python
from step22_portfolio_routes import router as step22_portfolio_router
```

and with the existing router registrations:

```python
app.include_router(step22_portfolio_router)
```

No other server.py changes are required for Step 2.2.
