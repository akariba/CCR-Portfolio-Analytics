STRICT BONE RULE. Use the current working private-machine RPR HTML as the ultimate source of truth. This package is an additive revision built from the previous complete appended HTML. Do not redesign, reformat, remove, or rewrite working functionality.

Review `reference_previous_append/rpr-v8-consolidated-test-STEP22-APPENDED-PREVIOUS.html` versus `frontend/rpr-v8-consolidated-test-STEP22-MULTISELECT-APPENDED.html` and `docs/HTML_STEP22_MULTISELECT_ONLY.diff`.

Expected new Step 2.2 behavior ONLY:
1. Geography, Country, MLE and L2 controls are clickable multi-select dropdowns with the FULL catalog list visible/scrollable.
2. User can select multiple values in each filter.
3. `All` means no restriction; `Select all` checks the complete list.
4. Selecting one L2 must make the sector-card view show ONLY L3 sectors belonging to that L2.
5. Selecting multiple L2 values shows the union of L3 sectors under those selected L2 values only.
6. Geography/Country/MLE further filter the company universe and valid L3 cards, but do NOT delete values from the filter dropdown catalog.
7. No explicit L3 selection means all valid visible L3 sectors under the selected L2 scope.
8. Matching Companies and finalize remain backend-driven.
9. No LLM is introduced into Step 2.2.

Preservation rules:
- Keep all pre-existing CSS rules unchanged. The revision appends only the small Step-2.2 multi-select CSS block required for the dropdown behavior and uses the existing v31 variables/classes.
- Do not change Trigger 1, Trigger 2, Step 2.1, Step 2.3 model logic, Step 2.4, Step 2.5, Step 3, feedback layout, navigation, colors, typography, or overall v31 structure.
- Do not replace the project with a standalone Step 2.2 page.
- Do not introduce mock runtime behavior or public-web fallbacks.

First show the exact files/sections you intend to touch. Then apply only this delta and run syntax/tests.
