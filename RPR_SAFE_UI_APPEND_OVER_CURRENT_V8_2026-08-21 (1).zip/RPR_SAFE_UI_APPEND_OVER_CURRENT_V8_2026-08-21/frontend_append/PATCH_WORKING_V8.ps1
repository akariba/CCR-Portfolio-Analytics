param(
  [Parameter(Mandatory=$true)][string]$SourceHtml,
  [string]$OutputHtml = ""
)
$ErrorActionPreference = "Stop"
if (!(Test-Path $SourceHtml)) { throw "Source HTML not found: $SourceHtml" }
$src = [System.IO.File]::ReadAllText((Resolve-Path $SourceHtml))
foreach ($marker in @('id="t1-step-1"','id="t1-step-2"','</head>','</body>')) {
  if (-not $src.Contains($marker)) { throw "Required v31 marker missing: $marker. Source was NOT modified." }
}
if ($src.Contains('rpr_step22_step23_append.js')) { throw "Source already contains the safe append. Source was NOT modified." }
if ([string]::IsNullOrWhiteSpace($OutputHtml)) {
  $dir = Split-Path -Parent (Resolve-Path $SourceHtml)
  $base = [System.IO.Path]::GetFileNameWithoutExtension($SourceHtml)
  $OutputHtml = Join-Path $dir ($base + '-SAFE-STEP22-STEP23.html')
}
$cssTag = '  <link rel="stylesheet" href="rpr_step22_step23_append.css" data-rpr-safe-append="css">' + [Environment]::NewLine
$jsTag  = '  <script src="rpr_step22_step23_append.js" data-rpr-safe-append="js"></script>' + [Environment]::NewLine
$out = $src.Replace('</head>', $cssTag + '</head>').Replace('</body>', $jsTag + '</body>')
[System.IO.File]::WriteAllText($OutputHtml, $out, [System.Text.UTF8Encoding]::new($false))
Write-Host "SAFE APPEND CREATED:" $OutputHtml
Write-Host "SOURCE LEFT UNCHANGED:" (Resolve-Path $SourceHtml)
Write-Host "Now keep rpr_step22_step23_append.js and .css in the SAME folder as the new HTML."
