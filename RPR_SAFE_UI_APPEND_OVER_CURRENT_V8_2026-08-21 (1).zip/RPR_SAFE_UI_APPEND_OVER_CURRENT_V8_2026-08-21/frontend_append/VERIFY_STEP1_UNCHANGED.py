from pathlib import Path
import sys
if len(sys.argv) != 3:
    print("Usage: python VERIFY_STEP1_UNCHANGED.py <working-v8.html> <safe-appended.html>")
    raise SystemExit(2)
src=Path(sys.argv[1]).read_text(encoding='utf-8-sig')
out=Path(sys.argv[2]).read_text(encoding='utf-8-sig')
for tag in [
    '  <link rel="stylesheet" href="rpr_step22_step23_append.css" data-rpr-safe-append="css">\n',
    '  <script src="rpr_step22_step23_append.js" data-rpr-safe-append="js"></script>\n',
]:
    out=out.replace(tag,'')
# tolerate CRLF injection variants
out=out.replace('  <link rel="stylesheet" href="rpr_step22_step23_append.css" data-rpr-safe-append="css">\r\n','')
out=out.replace('  <script src="rpr_step22_step23_append.js" data-rpr-safe-append="js"></script>\r\n','')
if out==src:
    print('PASS: original working HTML is unchanged except the two append asset tags.')
else:
    print('FAIL: unexpected source changes detected. Do not use the generated HTML.')
    raise SystemExit(1)
