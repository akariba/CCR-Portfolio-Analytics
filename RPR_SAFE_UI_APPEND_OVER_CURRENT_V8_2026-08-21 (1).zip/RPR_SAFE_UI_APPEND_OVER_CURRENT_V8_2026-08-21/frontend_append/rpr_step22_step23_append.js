/*
RPR SAFE APPEND OVER CURRENT WORKING V8
- Does not replace or initialize Step 1.
- Does not call any Step 2.2/2.3 API until the analyst navigates to that step.
- Replaces DOM only inside #t1-step-1 (Step 2.2) and #t1-step-2 (Step 2.3).
*/
(function(){
'use strict';
const STEP22_TEMPLATE = "\n STEP 2.2 APPEND: same v31 visual language; data is now backend-driven. \n<div class=\"ps22-tab-nav\"><button class=\"ps22-tab active\" id=\"ps22-tab-0\" onclick=\"switchStep22Pane(0)\">Select Portfolio</button><button class=\"ps22-tab\" id=\"ps22-tab-1\" onclick=\"switchStep22Pane(1)\">Upload Portfolio</button></div>\n<div id=\"ps22-pane-0\" style=\"display:flex;flex-direction:column;gap:12px;margin-top:12px\">\n<div class=\"card ps22-filter-card\">\n<div class=\"card-hdr\"><div class=\"card-title\">Portfolio Filters</div><div class=\"info-row\" id=\"ps22-status\">Loading portfolio catalog\u2026</div></div>\n<div class=\"card-body\">\n<div class=\"two-col\">\n<div><label class=\"section-label\" for=\"ps22-geo\">Select Geography</label><div class=\"horizon-text-inp ps22-multi\" data-step22-filter=\"geography\" id=\"ps22-geo\"></div></div>\n<div><label class=\"section-label\" for=\"ps22-country\">Select Country</label><div class=\"horizon-text-inp ps22-multi\" data-step22-filter=\"country\" id=\"ps22-country\"></div></div>\n<div><label class=\"section-label\" for=\"ps22-mle\">Select MLE</label><div class=\"horizon-text-inp ps22-multi\" data-step22-filter=\"mle\" id=\"ps22-mle\"></div></div>\n<div><label class=\"section-label\" for=\"ps22-sector-filter\">Select L2 Category</label><div class=\"horizon-text-inp ps22-multi\" data-step22-filter=\"l2\" id=\"ps22-sector-filter\"></div></div>\n</div>\n</div>\n</div>\n<div class=\"ps-intro-left\"><div><div class=\"ps-intro-label\">Available Sectors</div><div class=\"ps-intro-hint\" style=\"font-size:11px;color:rgba(255,255,255,.55);margin-top:4px\">Backend-driven L2 \u2192 L3 portfolio universe. If no L3 is checked, all valid L3 sectors under the selected L2 are included.</div></div><div class=\"ps-intro-count\" id=\"ps-count-badge\">0 selected</div></div>\n<div class=\"ps-selection-summary\"><span class=\"ps-summary-label\">Selected:</span><div class=\"ps-summary-chips\" id=\"ps-summary-chips\"></div></div>\n<div class=\"card\">\n<div class=\"card-hdr\"><div class=\"card-title\">Available Sectors</div><div><button class=\"btn btn-g btn-sm\" onclick=\"selectAllSectors()\">Select All</button><button class=\"btn btn-g btn-sm\" onclick=\"clearAllSectors()\">Clear All</button></div></div>\n<div class=\"card-body\"><div id=\"ps-sector-groups\"><div class=\"ps-sector-grid\" id=\"ps-sector-grid\"><div class=\"pla-placeholder\"><div class=\"pla-placeholder-title\">Loading sector hierarchy\u2026</div></div></div></div></div>\n</div>\n<div class=\"card\" id=\"ps22-company-card\">\n<div class=\"card-hdr\"><div class=\"card-title\">Matching Companies</div><div class=\"info-row\" id=\"ps22-company-count\">0 companies</div></div>\n<div class=\"card-body\" id=\"ps22-company-container\"><div class=\"pla-placeholder\"><div class=\"pla-placeholder-title\">Company universe will appear here</div><div class=\"pla-placeholder-sub\">The backend resolves CAGID, company, sector, country and MLE from the current Step 2.2 filters.</div></div></div>\n</div>\n<div style=\"display:flex;justify-content:space-between;align-items:center\"><span style=\"font-size:10px;color:var(--text_weak)\">Portfolio selection is deterministic; no LLM call.</span><button class=\"btn btn-p btn-sm\" disabled=\"\" id=\"ps-confirm-btn\" onclick=\"confirmPortfolioSelection()\">Confirm Portfolio Selection \u2192</button></div>\n</div>\n STEP 2.2 APPEND \u2014 real portfolio upload; existing v31 tab/design preserved. \n<div id=\"ps22-pane-1\" style=\"display:none;flex-direction:column;gap:12px;margin-top:12px\">\n<div class=\"card\">\n<div class=\"card-hdr\"><div class=\"card-title\">Upload Portfolio</div><div class=\"info-row\" id=\"ps22-upload-status\">CSV/XLSX \u00b7 CAGID required</div></div>\n<div class=\"card-body\">\n<input accept=\".csv,.xlsx\" id=\"ps22-upload-input\" onchange=\"handleStep22PortfolioUpload(this.files);this.value=''\" style=\"display:none\" type=\"file\"/>\n<div class=\"file-upload-area\" id=\"ps22-upload-area\" onclick=\"$('ps22-upload-input').click()\" ondragleave=\"handleStep22UploadDragLeave(event)\" ondragover=\"handleStep22UploadDragOver(event)\" ondrop=\"handleStep22UploadDrop(event)\">\n<div class=\"file-upload-icon\">\u21e7</div>\n<div class=\"file-upload-label\"><strong>Click to upload</strong> or drag and drop a portfolio file</div>\n<div class=\"file-upload-types\">CSV or XLSX \u00b7 minimum column: CAGID \u00b7 canonical company attributes are resolved from the Step 2.2 company master</div>\n</div>\n<div class=\"info-row\" style=\"margin-top:8px\">Upload does not override company name, country, MLE or sector taxonomy. Those fields remain backend-authoritative.</div>\n</div>\n</div>\n<div class=\"card\" id=\"ps22-upload-result-card\" style=\"display:none\">\n<div class=\"card-hdr\"><div class=\"card-title\">Upload Validation &amp; Preview</div><div class=\"info-row\" id=\"ps22-upload-counts\"></div></div>\n<div class=\"card-body\">\n<div id=\"ps22-upload-issues\" style=\"display:none;margin-bottom:10px\"></div>\n<div id=\"ps22-upload-preview\"></div>\n</div>\n</div>\n<div style=\"display:flex;justify-content:space-between;align-items:center\"><span style=\"font-size:10px;color:var(--text_weak)\">Portfolio upload is deterministic; no LLM call.</span><button class=\"btn btn-p btn-sm\" disabled=\"\" id=\"ps22-upload-confirm-btn\" onclick=\"confirmUploadedPortfolio()\">Confirm Uploaded Portfolio \u2192</button></div>\n</div>\n<div class=\"panel-feedback\" role=\"complementary\" style=\"margin-top:12px\">\n<div class=\"pf-hdr\"><div class=\"pf-title\">\u2726 <span>Feedback to Portfolio Selection Assistant</span></div><button class=\"btn btn-g btn-sm\" onclick=\"clearScopedFeedback('step2-2')\">Clear</button></div>\n<div class=\"chat-msgs\" id=\"step2-2-chat-msgs\"></div>\n<div class=\"chat-input-row\"><textarea class=\"chat-input\" id=\"step2-2-chat-input\" placeholder=\"Enter feedback for Portfolio Selection Assistant...\" rows=\"2\"></textarea><button class=\"chat-send\" onclick=\"sendScopedFeedback('step2-2')\">Send</button></div>\n</div>\n";
const STEP23_TEMPLATE = "\n<div class=\"card summary-card\">\n<div class=\"card-hdr\"><div class=\"card-title\">Event-Driven Risk Factors</div><div class=\"info-row\"><span id=\"ed-factor-count\">0</span> factors</div></div>\n<div class=\"card-body\">\n<div class=\"formula-banner\">Factor weights are calculated deterministically from the approved importance mapping (High = 2, Medium = 1) and normalized to 100%. The model proposes factors, metrics, buffers and critical AND thresholds; exact arithmetic is backend-controlled.</div>\n<table class=\"metric-tbl\"><thead><tr><th>RF</th><th>Factor</th><th>Importance</th><th>Imp. Score</th><th>Weight</th></tr></thead><tbody id=\"ed-summary-body\"><tr><td colspan=\"5\" style=\"color:var(--text_disabled)\">Confirm Step 2.1 and a portfolio selection, then generate factors.</td></tr></tbody></table>\n</div>\n</div>\n<div id=\"ed-rf-cards\"></div>\n<div class=\"action-row\"><button class=\"btn btn-g btn-sm\" onclick=\"addBlankEventFactor()\">\uff0b Add Factor</button><button class=\"btn btn-p btn-sm\" id=\"generate-event-factors-btn\" onclick=\"generateEventFactors()\">\u2301 Generate Event Factors</button><button class=\"btn btn-g btn-sm\" id=\"save-event-factors-btn\" onclick=\"saveEventFactorChanges()\">Save All Changes</button><button class=\"btn btn-p btn-sm\" id=\"confirm-event-factors-btn\" onclick=\"confirmEventFactors()\">Confirm All Risk Factors \u2192</button></div>\n<div class=\"panel-feedback\" role=\"complementary\" style=\"margin-top:12px\">\n<div class=\"pf-hdr\"><div class=\"pf-title\">\u2726 <span>Feedback to Event-Driven Risk Factor Agent</span></div><button class=\"btn btn-g btn-sm\" onclick=\"clearStep23AppendFeedback()\">Clear</button></div>\n<div class=\"chat-msgs\" id=\"step2-3-chat-msgs\"></div>\n<div class=\"chat-input-row\"><textarea class=\"chat-input\" id=\"step2-3-chat-input\" placeholder=\"Enter feedback for Event-Driven Risk Factor Agent...\" rows=\"2\"></textarea><button class=\"chat-send\" onclick=\"sendStep23AppendFeedback()\">Send</button></div>\n</div>\n";
let STEP22_INSTALLED=false, STEP23_INSTALLED=false, STEP22_INITIALIZED=false;
let ALL_SECTORS=[];
const STEP22_SECTOR_LOOKUP=new Map();
let STEP22_CATALOG=null;
let STEP22_COMPANIES=[];
let STEP22_CONFIRMED_PORTFOLIO=null;
let STEP22_CATALOG_OK=false;
let STEP22_SEARCH_OK=false;
let STEP22_SEARCH_SEQ=0;
let STEP22_UPLOAD_RESULT=null;
let STEP22_SELECTION_MODE='FILTERS';
let STEP23_CONFIRMED_FRAMEWORK=null;
const STEP23_ANALYST_MODIFIED_FIELDS=new Set();
const STEP22_FILTER_STATE={geography:new Set(),country:new Set(),mle:new Set(),l2:new Set()};
const STEP22_FILTER_OPTIONS={geography:[],country:[],mle:[],l2:[]};

function step22Text(v){return String(v==null?'':v).trim()}
function getSectorById(id){return STEP22_SECTOR_LOOKUP.get(String(id))||ALL_SECTORS.find(s=>s.id===id)||null}
function step22MapSector(s){
  const id=step22Text(s?.id);const l1=step22Text(s?.l1),l2=step22Text(s?.l2),l3=step22Text(s?.l3),l4=step22Text(s?.l4);
  return {id,name:l3||l4||'Unassigned',path:[l1,l2,l3].filter(Boolean).join(' / '),l1,l2,l3,l4};
}
function step22RememberSectors(rows){
  (rows||[]).map(step22MapSector).filter(s=>s.id&&s.name).forEach(s=>STEP22_SECTOR_LOOKUP.set(s.id,s));
}
async function step22Get(path,timeout=30000){
  const ctl=new AbortController(),timer=setTimeout(()=>ctl.abort(),timeout);
  try{
    const r=await fetch(API+path,{method:'GET',headers:{'Accept':'application/json'},signal:ctl.signal});
    const raw=await r.text();let d={};try{d=raw?JSON.parse(raw):{}}catch(_){throw new Error('Step 2.2 backend returned non-JSON response')}
    if(!r.ok)throw new Error(d?.detail||d?.error||`HTTP ${r.status}`);return d;
  }finally{clearTimeout(timer)}
}
function step22FilterSet(key){return STEP22_FILTER_STATE[key]||new Set()}
function step22OptionRows(key){return STEP22_FILTER_OPTIONS[key]||[]}
function step22SelectedValues(key){return [...step22FilterSet(key)]}
function step22FilterSummary(key){
  const selected=step22SelectedValues(key),options=step22OptionRows(key);
  if(!selected.length)return `All (${options.length})`;
  const labels=selected.map(v=>options.find(o=>o.value===v)?.label||v);
  if(labels.length<=2)return labels.join(', ');
  return `${labels[0]}, ${labels[1]} +${labels.length-2}`;
}
function step22CloseAllMenus(exceptId=''){
  document.querySelectorAll('.ps22-multi.open').forEach(el=>{if(el.id!==exceptId)el.classList.remove('open')});
}
function step22ToggleMenu(id,event){
  if(event)event.stopPropagation();const host=$(id);if(!host)return;
  const willOpen=!host.classList.contains('open');step22CloseAllMenus(willOpen?id:'');host.classList.toggle('open',willOpen);
}
function step22SetOptions(key,rows,valueFn,labelFn){
  const seen=new Set();STEP22_FILTER_OPTIONS[key]=(rows||[]).map(row=>({value:step22Text(valueFn(row)),label:step22Text(labelFn(row))})).filter(o=>o.value&&!seen.has(o.value)&&(seen.add(o.value),true));
  const allowed=new Set(STEP22_FILTER_OPTIONS[key].map(o=>o.value));STEP22_FILTER_STATE[key]=new Set(step22SelectedValues(key).filter(v=>allowed.has(v)));
  step22RenderMulti(key);
}
function step22RenderMulti(key){
  const id=key==='geography'?'ps22-geo':key==='country'?'ps22-country':key==='mle'?'ps22-mle':'ps22-sector-filter';
  const host=$(id);if(!host)return;const options=step22OptionRows(key),selected=step22FilterSet(key);
  host.innerHTML=`<button type="button" class="ps22-multi-trigger" aria-expanded="${host.classList.contains('open')?'true':'false'}" onclick="step22ToggleMenu('${id}',event)"><span class="ps22-multi-value">${esc(step22FilterSummary(key))}</span><span class="ps22-multi-caret">⌄</span></button><div class="ps22-multi-menu" onclick="event.stopPropagation()"><div class="ps22-multi-actions"><button type="button" class="btn btn-g btn-sm" onclick="step22ClearFilter('${key}')">All</button><button type="button" class="btn btn-g btn-sm" onclick="step22SelectAllFilter('${key}')">Select all</button></div>${options.length?options.map(o=>`<label class="ps22-multi-option"><input type="checkbox" ${selected.has(o.value)?'checked':''} onchange="step22ToggleFilter('${key}','${step22Js(o.value)}',this.checked)"><span>${esc(o.label)}</span></label>`).join(''):'<div class="ps22-multi-empty">No values available</div>'}</div>`;
}
function step22Js(value){return String(value||'').replace(/\\/g,'\\\\').replace(/'/g,"\\'")}
function step22ToggleFilter(key,value,checked){
  const set=step22FilterSet(key);checked?set.add(value):set.delete(value);STEP22_FILTER_STATE[key]=set;step22RenderMulti(key);
  if(key==='l2')STEP2_SELECTED_SECTORS.clear();
  buildPortfolioSelectionUI();runStep22Search();
}
function step22ClearFilter(key){STEP22_FILTER_STATE[key]=new Set();if(key==='l2')STEP2_SELECTED_SECTORS.clear();step22RenderMulti(key);buildPortfolioSelectionUI();runStep22Search()}
function step22SelectAllFilter(key){STEP22_FILTER_STATE[key]=new Set(step22OptionRows(key).map(o=>o.value));if(key==='l2')STEP2_SELECTED_SECTORS.clear();step22RenderMulti(key);buildPortfolioSelectionUI();runStep22Search()}
function step22Filters(){return {geographies:step22SelectedValues('geography'),countries:step22SelectedValues('country'),mles:step22SelectedValues('mle'),l2_categories:step22SelectedValues('l2')}}
function step22SetStatus(msg,ok=false){const e=$('ps22-status');if(e){e.textContent=msg;e.style.color=ok?'#2A6B3C':''}}
function buildPortfolioSelectionUI(){
  const c=$('ps-sector-grid');if(!c)return;
  if(!STEP22_CATALOG_OK){c.innerHTML='<div class="pla-placeholder" style="grid-column:1/-1"><div class="pla-placeholder-title">Portfolio catalog unavailable</div></div>';refreshSelectionUI();return}
  if(!ALL_SECTORS.length){c.innerHTML='<div class="pla-placeholder" style="grid-column:1/-1"><div class="pla-placeholder-title">No L3 sectors match the current filters</div><div class="pla-placeholder-sub">Change Geography, Country, MLE or L2 selection.</div></div>';refreshSelectionUI();return}
  const groups={};ALL_SECTORS.forEach(s=>{const k=s.l2||'Other';(groups[k]||(groups[k]=[])).push(s)});
  c.innerHTML=Object.entries(groups).map(([group,sectors])=>`<div style="grid-column:1/-1"><div class="section-label" style="margin:2px 0 8px">${esc(group)} · ${sectors.length} L3 sectors</div><div class="ps-sector-grid">${sectors.map(s=>`<div class="ps-sector-card ${STEP2_SELECTED_SECTORS.has(s.id)?'selected':''}" onclick="toggleSector('${esc(s.id)}')"><div class="ps-check">${STEP2_SELECTED_SECTORS.has(s.id)?'✓':''}</div><div><div class="ps-sector-name">${esc(s.name)}</div><div class="ps-sector-path">${esc(s.path)}</div></div></div>`).join('')}</div></div>`).join('');
  refreshSelectionUI();
}
function toggleSector(id){STEP2_SELECTED_SECTORS.has(id)?STEP2_SELECTED_SECTORS.delete(id):STEP2_SELECTED_SECTORS.add(id);buildPortfolioSelectionUI();runStep22Search()}
function selectAllSectors(){ALL_SECTORS.forEach(s=>STEP2_SELECTED_SECTORS.add(s.id));buildPortfolioSelectionUI();runStep22Search()}
function clearAllSectors(){STEP2_SELECTED_SECTORS.clear();buildPortfolioSelectionUI();runStep22Search()}
function refreshSelectionUI(){
  const arr=[...STEP2_SELECTED_SECTORS].map(getSectorById).filter(Boolean);if($('ps-count-badge'))$('ps-count-badge').textContent=arr.length+' selected';
  const l2=step22SelectedValues('l2');
  if($('ps-summary-chips'))$('ps-summary-chips').innerHTML=arr.length?arr.map(s=>`<span class="ps-summary-chip">${esc(s.name)}</span>`).join(''):(l2.length?l2.map(x=>`<span class="ps-summary-chip">${esc(x)} · all valid L3</span>`).join(''):'<span style="font-size:10px;color:var(--text_disabled)">No explicit L3 restriction — all currently visible L3 sectors are included.</span>');
  if($('ps-confirm-btn'))$('ps-confirm-btn').disabled=!(STEP22_CATALOG_OK&&STEP22_SEARCH_OK&&STEP22_COMPANIES.length);
}
function onPs22FilterChange(){runStep22Search()}
function onPs22SectorFilterChange(){STEP2_SELECTED_SECTORS.clear();buildPortfolioSelectionUI();runStep22Search()}
async function initStep22Portfolio(){
  if(!$('t1-step-1')||!$('ps22-geo'))return;
  STEP22_CATALOG_OK=false;STEP22_SEARCH_OK=false;step22SetStatus('Loading portfolio catalog…');refreshSelectionUI();
  try{
    const d=await step22Get('/api/v1/rpr/step2/portfolio/catalog',30000);STEP22_CATALOG=d;
    step22SetOptions('geography',d.geographies||[],x=>x,x=>x);
    step22SetOptions('country',d.countries||[],x=>x.code,x=>x.name||x.code);
    step22SetOptions('mle',d.mles||[],x=>x.code,x=>x.name||x.code);
    step22SetOptions('l2',d.l2_categories||[],x=>x,x=>x);
    step22RememberSectors(d.sectors||[]);ALL_SECTORS=(d.sectors||[]).map(step22MapSector).filter(s=>s.id&&s.name);STEP22_CATALOG_OK=true;
    const counts=`${(d.geographies||[]).length} geographies · ${(d.countries||[]).length} countries · ${(d.mles||[]).length} MLEs · ${(d.l2_categories||[]).length} L2 · ${(d.sectors||[]).length} L3`;
    step22SetStatus('Portfolio catalog loaded — '+counts,true);buildPortfolioSelectionUI();await runStep22Search();
  }catch(e){STEP22_CATALOG_OK=false;STEP22_SEARCH_OK=false;ALL_SECTORS=[];STEP22_COMPANIES=[];step22SetStatus('Portfolio catalog failed');buildPortfolioSelectionUI();renderStep22CompaniesError(e)}
}
async function runStep22Search(){
  if(!STEP22_CATALOG_OK)return;const seq=++STEP22_SEARCH_SEQ;STEP22_SEARCH_OK=false;refreshSelectionUI();step22SetStatus('Refreshing portfolio…');
  const f=step22Filters();
  try{
    const d=await apiPost('/api/v1/rpr/step2/portfolio/search',{geographies:f.geographies,countries:f.countries,mles:f.mles,l2_categories:f.l2_categories,l3:[...STEP2_SELECTED_SECTORS]},60000);if(seq!==STEP22_SEARCH_SEQ)return;
    const valid=d.valid_filters||{};step22RememberSectors(valid.sectors||[]);ALL_SECTORS=(valid.sectors||[]).map(step22MapSector).filter(s=>s.id&&s.name);
    const validIds=new Set(ALL_SECTORS.map(s=>s.id));STEP2_SELECTED_SECTORS=new Set([...STEP2_SELECTED_SECTORS].filter(id=>validIds.has(id)));
    /* The filter dropdowns intentionally keep the FULL catalog lists. Only the L3 card view cascades. */
    STEP22_COMPANIES=Array.isArray(d.companies)?d.companies:[];STEP22_SEARCH_OK=true;buildPortfolioSelectionUI();renderStep22Companies();step22SetStatus(`Portfolio refreshed — ${STEP22_COMPANIES.length} companies · ${ALL_SECTORS.length} visible L3`,true);refreshSelectionUI();
  }catch(e){if(seq!==STEP22_SEARCH_SEQ)return;renderStep22CompaniesError(e)}
}
function renderStep22Companies(){
  const host=$('ps22-company-container'),count=$('ps22-company-count');if(!host)return;if(count)count.textContent=`${STEP22_COMPANIES.length} companies`;
  if(!STEP22_COMPANIES.length){host.innerHTML='<div class="pla-placeholder"><div class="pla-placeholder-title">No matching companies</div><div class="pla-placeholder-sub">Adjust Geography, Country, MLE or sector filters.</div></div>';return}
  host.innerHTML=`<table class="metric-tbl"><thead><tr><th>CAGID</th><th>Company Name</th><th>Sector</th><th>Country</th><th>MLE</th></tr></thead><tbody>${STEP22_COMPANIES.slice(0,250).map(c=>`<tr><td>${esc(c.cagid||'')}</td><td>${esc(c.company_name||'')}</td><td>${esc(c.sector_label||c.l3||'')}</td><td>${esc(c.country||'')}</td><td>${esc(c.mle||c.mle_code||'')}</td></tr>`).join('')}</tbody></table>${STEP22_COMPANIES.length>250?`<div class="info-row" style="margin-top:8px">Showing first 250 of ${STEP22_COMPANIES.length} companies.</div>`:''}`;
}
function renderStep22CompaniesError(e){STEP22_SEARCH_OK=false;STEP22_COMPANIES=[];if($('ps22-company-count'))$('ps22-company-count').textContent='Unavailable';if($('ps22-company-container'))$('ps22-company-container').innerHTML=`<div class="pla-placeholder"><div class="pla-placeholder-title">Portfolio search unavailable</div><div class="pla-placeholder-sub">${esc(String(e?.message||e||'Unknown error'))}</div></div>`;step22SetStatus('Portfolio search failed');refreshSelectionUI()}
async function confirmPortfolioSelection(){
  if(!(STEP22_CATALOG_OK&&STEP22_SEARCH_OK&&STEP22_COMPANIES.length)){addLog('warn','A valid Step 2.2 company universe is required before confirmation.');return}
  const btn=$('ps-confirm-btn'),old=btn?.textContent||'Confirm Portfolio Selection →';if(btn){btn.disabled=true;btn.textContent='Confirming…'}
  try{
    const d=await apiPost('/api/v1/rpr/step2/portfolio/finalize',{filters:step22Filters(),selected_sector_ids:[...STEP2_SELECTED_SECTORS],companies:STEP22_COMPANIES.map(c=>({cagid:c.cagid})),selection_mode:'FILTERS',source_metadata:{source:'step22_filter_selection'}},60000);
    STEP22_SELECTION_MODE='FILTERS';STEP22_CONFIRMED_PORTFOLIO=d;rebuildSectorDropdowns();completeStep(1,`Portfolio selection confirmed — ${d.company_count||STEP22_COMPANIES.length} companies.`);addLog('ok',`Step 2.2 portfolio_id=${d.portfolio_id||'confirmed'}`);
    if(btn)btn.textContent='Confirmed';
  }catch(e){addLog('warn','Portfolio confirmation failed — '+String(e.message||e));if(btn){btn.disabled=false;btn.textContent=old}}
}
function switchStep22Pane(idx){
  const select=idx===0;
  const p0=$('ps22-pane-0'),p1=$('ps22-pane-1');
  if(p0)p0.style.display=select?'flex':'none';if(p1)p1.style.display=select?'none':'flex';
  $('ps22-tab-0')?.classList.toggle('active',select);$('ps22-tab-1')?.classList.toggle('active',!select);
  STEP22_SELECTION_MODE=select?'FILTERS':'UPLOAD';
  addLog('info',select?'Step 2.2 — Select Portfolio':'Step 2.2 — Upload Portfolio');
}
function handleStep22UploadDragOver(e){e.preventDefault();$('ps22-upload-area')?.classList.add('drag-over')}
function handleStep22UploadDragLeave(e){e.preventDefault();$('ps22-upload-area')?.classList.remove('drag-over')}
async function handleStep22UploadDrop(e){e.preventDefault();$('ps22-upload-area')?.classList.remove('drag-over');await handleStep22PortfolioUpload(e.dataTransfer?.files||[])}
async function handleStep22PortfolioUpload(files){
  const file=files&&files[0];if(!file)return;
  const status=$('ps22-upload-status'),btn=$('ps22-upload-confirm-btn');if(btn)btn.disabled=true;
  STEP22_UPLOAD_RESULT=null;if(status)status.textContent='Validating '+file.name+'…';
  showLoad('Validating uploaded portfolio…','CAGID resolution against Step 2.2 company master');
  try{
    const fd=new FormData();fd.append('file',file);
    const ctl=new AbortController(),timer=setTimeout(()=>ctl.abort(),90000);
    let r,d;try{r=await fetch(API+'/api/v1/rpr/step2/portfolio/upload',{method:'POST',body:fd,signal:ctl.signal});d=await r.json()}finally{clearTimeout(timer)}
    if(!r.ok)throw new Error(d?.detail||`HTTP ${r.status}`);
    STEP22_UPLOAD_RESULT=d;STEP22_SELECTION_MODE='UPLOAD';renderStep22UploadResult();
    if(status)status.textContent=`${d.status||'READY'} · ${d.matched_count||0} matched`;
    addLog(d.confirmation_allowed?'ok':'warn',`Step 2.2 upload validated — ${d.matched_count||0} matched · ${d.unmatched_count||0} unmatched · ${d.duplicate_count||0} duplicates`);
  }catch(e){
    STEP22_UPLOAD_RESULT=null;if(status)status.textContent='Upload validation failed';
    const card=$('ps22-upload-result-card');if(card)card.style.display='block';
    const preview=$('ps22-upload-preview');if(preview)preview.innerHTML=`<div class="pla-placeholder"><div class="pla-placeholder-title">Portfolio upload unavailable</div><div class="pla-placeholder-sub">${esc(String(e.message||e))}</div></div>`;
    addLog('warn','Step 2.2 upload failed — '+String(e.message||e));
  }finally{hideLoad()}
}
function renderStep22UploadResult(){
  const d=STEP22_UPLOAD_RESULT;if(!d)return;const card=$('ps22-upload-result-card');if(card)card.style.display='block';
  const counts=$('ps22-upload-counts');if(counts)counts.textContent=`${d.matched_count||0} matched · ${d.unmatched_count||0} unmatched · ${d.duplicate_count||0} duplicates`;
  const issues=d.issues||{},issueBits=[];
  if((issues.unmatched_cagids||[]).length)issueBits.push(`<b>Unmatched CAGIDs:</b> ${esc((issues.unmatched_cagids||[]).slice(0,20).join(', '))}${issues.unmatched_cagids.length>20?' …':''}`);
  if((issues.duplicate_cagids||[]).length)issueBits.push(`<b>Duplicates ignored:</b> ${esc((issues.duplicate_cagids||[]).slice(0,20).join(', '))}${issues.duplicate_cagids.length>20?' …':''}`);
  if((issues.malformed_rows||[]).length)issueBits.push(`<b>Rows without CAGID:</b> ${esc((issues.malformed_rows||[]).join(', '))}`);
  const issueHost=$('ps22-upload-issues');if(issueHost){issueHost.style.display=issueBits.length?'block':'none';issueHost.innerHTML=issueBits.length?`<div class="critical-note">${issueBits.join('<br>')}</div>`:''}
  const companies=Array.isArray(d.companies)?d.companies:[];const preview=$('ps22-upload-preview');
  if(preview)preview.innerHTML=companies.length?`<table class="metric-tbl"><thead><tr><th>CAGID</th><th>Company Name</th><th>Sector</th><th>Country</th><th>MLE</th></tr></thead><tbody>${companies.slice(0,250).map(c=>`<tr><td>${esc(c.cagid||'')}</td><td>${esc(c.company_name||'')}</td><td>${esc(c.sector_label||c.l3||'')}</td><td>${esc(c.country||'')}</td><td>${esc(c.mle||c.mle_code||'')}</td></tr>`).join('')}</tbody></table>${companies.length>250?`<div class="info-row" style="margin-top:8px">Showing first 250 of ${companies.length} matched companies.</div>`:''}`:'<div class="pla-placeholder"><div class="pla-placeholder-title">No CAGIDs matched the company master</div></div>';
  const btn=$('ps22-upload-confirm-btn');if(btn)btn.disabled=!d.confirmation_allowed;
}
async function confirmUploadedPortfolio(){
  const u=STEP22_UPLOAD_RESULT;if(!u?.confirmation_allowed){addLog('warn','Upload a portfolio with at least one matched CAGID before confirmation.');return}
  const btn=$('ps22-upload-confirm-btn'),old=btn?.textContent||'Confirm Uploaded Portfolio →';if(btn){btn.disabled=true;btn.textContent='Confirming…'}
  try{
    const d=await apiPost('/api/v1/rpr/step2/portfolio/finalize',{filters:{},selected_sector_ids:u.selected_sector_ids||[],companies:(u.companies||[]).map(c=>({cagid:c.cagid})),selection_mode:'UPLOAD',source_metadata:{file_name:u.file_name,input_row_count:u.input_row_count,matched_count:u.matched_count,unmatched_count:u.unmatched_count,duplicate_count:u.duplicate_count}},60000);
    STEP22_SELECTION_MODE='UPLOAD';STEP22_CONFIRMED_PORTFOLIO=d;STEP2_SELECTED_SECTORS=new Set(u.selected_sector_ids||[]);step22RememberSectors(STEP22_CATALOG?.sectors||[]);rebuildSectorDropdowns();
    completeStep(1,`Uploaded portfolio confirmed — ${d.company_count||u.matched_count||0} companies.`);addLog('ok',`Step 2.2 upload portfolio_id=${d.portfolio_id||'confirmed'}`);if(btn)btn.textContent='Confirmed';
  }catch(e){addLog('warn','Uploaded portfolio confirmation failed — '+String(e.message||e));if(btn){btn.disabled=false;btn.textContent=old}}
}
function rebuildSectorDropdowns(){
  const explicit=[...STEP2_SELECTED_SECTORS];const ids=explicit.length?explicit:ALL_SECTORS.map(s=>s.id);
  for(const target of ['sector-select','pla-sector-select']){const sel=$(target);if(!sel)continue;sel.innerHTML=ids.map(id=>`<option value="${esc(id)}">${esc(getSectorById(id)?.name||id)}</option>`).join('')}
  const s=$('sector-select');if(s&&typeof onSectorChange==='function')onSectorChange(s);const p=$('pla-sector-select');if(p&&typeof onPlaSectorChange==='function')onPlaSectorChange(p);
}
function getSelectedSector(){
  const first=[...STEP2_SELECTED_SECTORS][0];if(first)return getSectorById(first)?.name||'';const l2=step22SelectedValues('l2');return l2[0]||ALL_SECTORS[0]?.l2||'';
}

function getStep23SectorAnchor(){
  const ids=[...STEP2_SELECTED_SECTORS];
  const labels=ids.map(id=>getSectorById(id)?.name||id).filter(Boolean);
  if(labels.length)return labels.join(' | ');
  const l2=step22SelectedValues('l2');return l2.length?l2.join(' | '):getSelectedSector();
}
function step23PortfolioContext(){
  return {selected_sectors:[...STEP2_SELECTED_SECTORS],confirmed_portfolio:STEP22_CONFIRMED_PORTFOLIO||null,selection_mode:STEP22_CONFIRMED_PORTFOLIO?.selection_mode||STEP22_SELECTION_MODE};
}
async function generateEventFactors(){
  if(!STEP2_CONFIRMED_SCENARIO){addLog('warn','Confirm Step 2.1 first.');return}
  if(!STEP22_CONFIRMED_PORTFOLIO){addLog('warn','Confirm Step 2.2 portfolio first.');return}
  const sector=getStep23SectorAnchor();if(!sector){addLog('warn','Confirmed Step 2.2 sector context is required.');return}
  const btn=$('generate-event-factors-btn');if(btn)btn.disabled=true;showLoad('Generating event-driven risk factors…','Opus credit-risk reasoning → deterministic governance validation');
  try{
    const d=await apiPost('/api/v1/rpr/step23/event-factors/generate',{confirmed_step1:getConfirmedStep1Payload(),confirmed_scenario:STEP2_CONFIRMED_SCENARIO,sector,portfolio_context:step23PortfolioContext()},300000);
    STEP2_EVENT_FACTORS=d;STEP23_CONFIRMED_FRAMEWORK=null;STEP23_ANALYST_MODIFIED_FIELDS.clear();renderEventFactors();logModelsTriggered(d,'Step 2.3 generation');markWFStep(3,'current');addLog('ok',`Generated ${d.factors?.length||0} event-driven factors; deterministic weights ${d.weights_sum_pct||0}%.`);
  }catch(e){addLog('warn','Event-factor generation failed — '+String(e.message||e))}finally{if(btn)btn.disabled=false;hideLoad()}
}
function step23Field(path){STEP23_ANALYST_MODIFIED_FIELDS.add(path);STEP23_CONFIRMED_FRAMEWORK=null}
function step23Input(value,cls,path,textarea=false){
  const tag=textarea?'textarea':'input';const attrs=textarea?'rows="2"':`type="text" value="${esc(value||'')}"`;
  return `<${tag} class="${cls}" ${attrs} oninput="step23Field('${path}')">${textarea?esc(value||''):''}</${tag}>`;
}
function renderEventFactors(){
  const fs=STEP2_EVENT_FACTORS?.factors||[];$('ed-factor-count').textContent=fs.length;
  $('ed-summary-body').innerHTML=fs.length?fs.map((f,i)=>`<tr><td>${esc(f.factor_id||('RF'+(i+1)))}</td><td>${esc(f.name||'')}</td><td>${esc(f.importance||'')}</td><td>${esc(f.importance_score??'')}</td><td>${esc(f.weight_pct??'')}%</td></tr>`).join(''):'<tr><td colspan="5" style="color:var(--text_disabled)">Generate the event-driven framework after confirming Step 2.1 and Step 2.2.</td></tr>';
  $('ed-rf-cards').innerHTML=fs.map((f,i)=>buildRFCard(f,i===0,i)).join('');
}
function buildRFCard(f,isFirst,index){
  const fid=f.factor_id||('RF'+(index+1));
  const vuln=(f.vulnerability_metrics||[]).map((m,mi)=>`<tr data-step23-vuln="${mi}"><td>${step23Input(m.metric,'horizon-text-inp step23-metric',`${fid}.vulnerability_metrics.${mi}.metric`)}</td><td>${step23Input(m.formula||'','horizon-text-inp step23-formula',`${fid}.vulnerability_metrics.${mi}.formula`)}</td><td>${step23Input(m.bands?.VERY_HIGH||'','horizon-text-inp step23-vh',`${fid}.vulnerability_metrics.${mi}.VERY_HIGH`)}</td><td>${step23Input(m.bands?.HIGH||'','horizon-text-inp step23-h',`${fid}.vulnerability_metrics.${mi}.HIGH`)}</td><td>${step23Input(m.bands?.MODERATE||'','horizon-text-inp step23-mod',`${fid}.vulnerability_metrics.${mi}.MODERATE`)}</td><td>${step23Input(m.bands?.LOW||'','horizon-text-inp step23-low',`${fid}.vulnerability_metrics.${mi}.LOW`)}</td><td><button class="del-btn" onclick="event.stopPropagation();removeEventFactorMetric(${index},'vulnerability_metrics',${mi})">×</button></td></tr>`).join('');
  const buf=(f.buffer_metrics||[]).map((m,mi)=>`<tr data-step23-buffer="${mi}"><td>${step23Input(m.metric,'horizon-text-inp step23-metric',`${fid}.buffer_metrics.${mi}.metric`)}</td><td>${step23Input(m.formula||'','horizon-text-inp step23-formula',`${fid}.buffer_metrics.${mi}.formula`)}</td><td>${step23Input(m.bands?.STRONG||'','horizon-text-inp step23-strong',`${fid}.buffer_metrics.${mi}.STRONG`)}</td><td>${step23Input(m.bands?.MODERATE||'','horizon-text-inp step23-mod',`${fid}.buffer_metrics.${mi}.MODERATE`)}</td><td>${step23Input(m.bands?.WEAK||'','horizon-text-inp step23-weak',`${fid}.buffer_metrics.${mi}.WEAK`)}</td><td>${step23Input(m.bands?.NEGLIGIBLE||'','horizon-text-inp step23-neg',`${fid}.buffer_metrics.${mi}.NEGLIGIBLE`)}</td><td><button class="del-btn" onclick="event.stopPropagation();removeEventFactorMetric(${index},'buffer_metrics',${mi})">×</button></td></tr>`).join('');
  const scoring=(f.scoring_logic||[]).map((r,ri)=>`<tr data-step23-score="${r.score}"><td style="font-weight:700">${esc(r.score)}</td><td>${step23Input(r.vulnerability_profile,'narrative-ta step23-score-v',`${fid}.scoring_logic.${ri}.vulnerability_profile`,true)}</td><td>${step23Input(r.buffer_profile,'narrative-ta step23-score-b',`${fid}.scoring_logic.${ri}.buffer_profile`,true)}</td></tr>`).join('');
  return `<div class="rf-card" id="step23-factor-${index}" data-factor-index="${index}"><div class="rf-card-hdr ${isFirst?'open':''}" onclick="toggleRF(this)"><div style="display:flex;align-items:center;gap:9px"><span class="rf-idx">${esc(fid)}</span><div><div class="rf-name">${esc(f.name||'Risk Factor')}</div><div class="rf-weight">${esc(f.importance||'')} · ${esc(f.weight_pct??'')}%</div></div></div><span>⌄</span></div><div class="rf-card-body ${isFirst?'open':''}">
  <div class="rf-subsection"><div class="rf-subsection-label">Factor Narrative</div><label class="section-label">Factor Name</label>${step23Input(f.name,'horizon-text-inp step23-name',`${fid}.name`)}<div style="height:8px"></div><textarea class="narrative-ta step23-narrative" oninput="step23Field('${fid}.narrative')">${esc(f.narrative||'')}</textarea><div style="height:8px"></div><div class="rf-subsection-label">Factor Importance</div><div class="importance-toggle"><button type="button" class="imp-opt ${f.importance==='HIGH'?'active-high':''}" onclick="setEventFactorImportance(${index},'HIGH',event)">High</button><button type="button" class="imp-opt ${f.importance==='MEDIUM'?'active-med':''}" onclick="setEventFactorImportance(${index},'MEDIUM',event)">Medium</button></div></div>
  <div class="rf-subsection"><div class="rf-subsection-label">Vulnerability Metrics (Set 1)</div><table class="metric-tbl"><thead><tr><th>Metric</th><th>Formula</th><th class="th-vh">Very High</th><th class="th-h">High</th><th>Moderate</th><th class="th-l">Low</th><th></th></tr></thead><tbody>${vuln}</tbody></table><div class="critical-note"><b>Critical threshold:</b> <input type="text" class="horizon-text-inp step23-critical" value="${esc((f.critical_threshold?.conditions||[]).join(' AND '))}" oninput="step23Field('${fid}.critical_threshold')"></div><button class="btn btn-g btn-sm" onclick="addEventFactorMetric(${index},'vulnerability_metrics')">＋ Add metric</button></div>
  <div class="rf-subsection"><div class="rf-subsection-label">Buffer Metrics (Set 2)</div><table class="metric-tbl"><thead><tr><th>Metric</th><th>Formula</th><th class="th-l">Strong</th><th>Moderate</th><th class="th-h">Weak</th><th class="th-vh">Negligible</th><th></th></tr></thead><tbody>${buf}</tbody></table><div class="key-principle-note"><b>Key Principle:</b><textarea class="narrative-ta step23-principle" rows="2" oninput="step23Field('${fid}.key_principle')">${esc(f.key_principle||f.scoring_rationale||'')}</textarea></div><button class="btn btn-g btn-sm" onclick="addEventFactorMetric(${index},'buffer_metrics')">＋ Add buffer metric</button></div>
  <div class="rf-subsection"><div class="rf-subsection-label">Scoring Logic (1–5)</div><table class="metric-tbl"><thead><tr><th>Score</th><th>Vulnerability Profile</th><th>Buffer Profile</th></tr></thead><tbody>${scoring}</tbody></table></div>
  ${fsafeDeleteButton(index)}
  </div></div>`;
}
function fsafeDeleteButton(index){return (STEP2_EVENT_FACTORS?.factors?.length||0)>4?`<div class="rf-subsection"><button class="btn btn-danger btn-sm" onclick="deleteEventFactor(${index})">Remove Factor</button></div>`:''}
function toggleRF(hdr){hdr.classList.toggle('open');hdr.nextElementSibling?.classList.toggle('open')}
function setEventFactorImportance(index,value,e){if(e)e.stopPropagation();collectEventFactorsFromDom(false);const f=STEP2_EVENT_FACTORS?.factors?.[index];if(!f)return;f.importance=value;step23Field(`${f.factor_id}.importance`);renderEventFactors()}
function addEventFactorMetric(index,key){collectEventFactorsFromDom(false);const f=STEP2_EVENT_FACTORS?.factors?.[index];if(!f)return;const isV=key==='vulnerability_metrics';const m={metric:'ANALYST_INPUT_REQUIRED',formula:'',unit:null,bands:isV?{VERY_HIGH:'ANALYST_INPUT_REQUIRED',HIGH:'ANALYST_INPUT_REQUIRED',MODERATE:'ANALYST_INPUT_REQUIRED',LOW:'ANALYST_INPUT_REQUIRED'}:{STRONG:'ANALYST_INPUT_REQUIRED',MODERATE:'ANALYST_INPUT_REQUIRED',WEAK:'ANALYST_INPUT_REQUIRED',NEGLIGIBLE:'ANALYST_INPUT_REQUIRED'},calibration_status:'REQUIRES_METHODOLOGY_REVIEW'};(f[key]||(f[key]=[])).push(m);step23Field(`${f.factor_id}.${key}`);renderEventFactors()}
function removeEventFactorMetric(index,key,metricIndex){collectEventFactorsFromDom(false);const f=STEP2_EVENT_FACTORS?.factors?.[index];if(!f)return;if((f[key]||[]).length<=2){addLog('warn','Each factor requires at least two '+(key==='vulnerability_metrics'?'vulnerability':'buffer')+' metrics.');return}f[key].splice(metricIndex,1);step23Field(`${f.factor_id}.${key}`);renderEventFactors()}
function deleteEventFactor(index){collectEventFactorsFromDom(false);const fs=STEP2_EVENT_FACTORS?.factors||[];if(fs.length<=4){addLog('warn','Step 2.3 requires at least four factors.');return}fs.splice(index,1);fs.forEach((f,i)=>f.factor_id='RF'+(i+1));STEP23_ANALYST_MODIFIED_FIELDS.add('factor_set');renderEventFactors()}
function addBlankEventFactor(){
  if(!STEP2_EVENT_FACTORS){addLog('warn','Generate the AI framework first, then add an analyst-defined factor.');return}collectEventFactorsFromDom(false);const fs=STEP2_EVENT_FACTORS.factors||[];if(fs.length>=6){addLog('warn','Step 2.3 allows a maximum of six factors.');return}
  const scoreRows=[5,4,3,2,1].map(x=>({score:x,vulnerability_profile:'ANALYST_INPUT_REQUIRED',buffer_profile:'ANALYST_INPUT_REQUIRED'}));
  fs.push({factor_id:'RF'+(fs.length+1),name:'ANALYST_INPUT_REQUIRED',importance:'MEDIUM',importance_score:1,weight_pct:0,one_line_rationale:'',narrative:'ANALYST_INPUT_REQUIRED',vulnerability_metrics:[0,1].map(()=>({metric:'ANALYST_INPUT_REQUIRED',formula:'',unit:null,bands:{VERY_HIGH:'ANALYST_INPUT_REQUIRED',HIGH:'ANALYST_INPUT_REQUIRED',MODERATE:'ANALYST_INPUT_REQUIRED',LOW:'ANALYST_INPUT_REQUIRED'},calibration_status:'REQUIRES_METHODOLOGY_REVIEW'})),critical_threshold:{logic:'AND',conditions:['ANALYST_INPUT_REQUIRED','ANALYST_INPUT_REQUIRED']},buffer_metrics:[0,1].map(()=>({metric:'ANALYST_INPUT_REQUIRED',formula:'',unit:null,bands:{STRONG:'ANALYST_INPUT_REQUIRED',MODERATE:'ANALYST_INPUT_REQUIRED',WEAK:'ANALYST_INPUT_REQUIRED',NEGLIGIBLE:'ANALYST_INPUT_REQUIRED'},calibration_status:'REQUIRES_METHODOLOGY_REVIEW'})),key_principle:'ANALYST_INPUT_REQUIRED',scoring_logic:scoreRows});STEP23_ANALYST_MODIFIED_FIELDS.add('factor_set');renderEventFactors();addLog('info','Analyst-defined factor added. Complete all placeholder fields before saving.')
}
function collectEventFactorsFromDom(mark=true){
  if(!STEP2_EVENT_FACTORS?.factors)return STEP2_EVENT_FACTORS;const clone=JSON.parse(JSON.stringify(STEP2_EVENT_FACTORS));
  clone.factors.forEach((f,i)=>{const card=$(`step23-factor-${i}`);if(!card)return;const fid=f.factor_id||('RF'+(i+1));f.name=card.querySelector('.step23-name')?.value?.trim()||'';f.narrative=card.querySelector('.step23-narrative')?.value?.trim()||'';
    const vrows=[...card.querySelectorAll('tr[data-step23-vuln]')];f.vulnerability_metrics=vrows.map((r,mi)=>({...(f.vulnerability_metrics?.[mi]||{}),metric:r.querySelector('.step23-metric')?.value?.trim()||'',formula:r.querySelector('.step23-formula')?.value?.trim()||null,bands:{VERY_HIGH:r.querySelector('.step23-vh')?.value?.trim()||'',HIGH:r.querySelector('.step23-h')?.value?.trim()||'',MODERATE:r.querySelector('.step23-mod')?.value?.trim()||'',LOW:r.querySelector('.step23-low')?.value?.trim()||''}}));
    const brows=[...card.querySelectorAll('tr[data-step23-buffer]')];f.buffer_metrics=brows.map((r,mi)=>({...(f.buffer_metrics?.[mi]||{}),metric:r.querySelector('.step23-metric')?.value?.trim()||'',formula:r.querySelector('.step23-formula')?.value?.trim()||null,bands:{STRONG:r.querySelector('.step23-strong')?.value?.trim()||'',MODERATE:r.querySelector('.step23-mod')?.value?.trim()||'',WEAK:r.querySelector('.step23-weak')?.value?.trim()||'',NEGLIGIBLE:r.querySelector('.step23-neg')?.value?.trim()||''}}));
    const critical=card.querySelector('.step23-critical')?.value||'';f.critical_threshold={logic:'AND',conditions:critical.split(/\s+AND\s+/i).map(x=>x.trim()).filter(Boolean)};f.key_principle=card.querySelector('.step23-principle')?.value?.trim()||'';
    const scoreRows=[...card.querySelectorAll('tr[data-step23-score]')];f.scoring_logic=scoreRows.map(r=>({score:Number(r.dataset.step23Score),vulnerability_profile:r.querySelector('.step23-score-v')?.value?.trim()||'',buffer_profile:r.querySelector('.step23-score-b')?.value?.trim()||''}));
    if(mark)STEP23_ANALYST_MODIFIED_FIELDS.add(fid);
  });STEP2_EVENT_FACTORS=clone;STEP23_CONFIRMED_FRAMEWORK=null;return clone;
}
function step23HasPlaceholders(framework){return JSON.stringify(framework||{}).includes('ANALYST_INPUT_REQUIRED')}
async function saveEventFactorChanges(){
  if(!STEP2_EVENT_FACTORS){addLog('warn','Generate Step 2.3 factors first.');return}const framework=collectEventFactorsFromDom();if(step23HasPlaceholders(framework)){addLog('warn','Complete all ANALYST_INPUT_REQUIRED fields before saving.');return}
  const btn=$('save-event-factors-btn');if(btn)btn.disabled=true;try{const d=await apiPost('/api/v1/rpr/step23/event-factors/validate',{framework},60000);STEP2_EVENT_FACTORS=d;renderEventFactors();addLog('ok',`Step 2.3 changes saved and validated; weights ${d.weights_sum_pct||0}%.`)}catch(e){addLog('warn','Step 2.3 validation failed — '+String(e.message||e))}finally{if(btn)btn.disabled=false}
}
async function confirmEventFactors(){
  if(!STEP2_EVENT_FACTORS){addLog('warn','Generate Step 2.3 factors first.');return}const framework=collectEventFactorsFromDom();if(step23HasPlaceholders(framework)){addLog('warn','Complete all analyst-required fields before confirmation.');return}
  const btn=$('confirm-event-factors-btn');if(btn)btn.disabled=true;showLoad('Confirming event-driven framework…','Deterministic validation; no LLM call');
  try{const d=await apiPost('/api/v1/rpr/step23/event-factors/finalize',{framework,analyst_modified_fields:[...STEP23_ANALYST_MODIFIED_FIELDS]},60000);STEP2_EVENT_FACTORS=d;STEP23_CONFIRMED_FRAMEWORK=d;renderEventFactors();completeStep(2,`Event-driven risk factors confirmed — ${d.factors?.length||0} factors.`);addLog('ok','Step 2.3 confirmed for downstream use.')}catch(e){addLog('warn','Step 2.3 confirmation failed — '+String(e.message||e))}finally{if(btn)btn.disabled=false;hideLoad()}
}

function installStep22Dom(){
  if(STEP22_INSTALLED)return true;
  const host=document.getElementById('t1-step-1');
  if(!host){console.error('[RPR APPEND] Step 2.2 host #t1-step-1 not found');return false;}
  host.innerHTML=STEP22_TEMPLATE;
  STEP22_INSTALLED=true;
  return true;
}
async function activateStep22(){
  if(!installStep22Dom() || STEP22_INITIALIZED)return;
  STEP22_INITIALIZED=true;
  try{await initStep22Portfolio();}catch(e){STEP22_INITIALIZED=false;console.error('[RPR APPEND] Step 2.2 init failed',e); try{addLog('warn','Step 2.2 append init failed — '+String(e.message||e));}catch(_){}}
}
function installStep23Dom(){
  if(STEP23_INSTALLED)return true;
  const host=document.getElementById('t1-step-2');
  if(!host){console.error('[RPR APPEND] Step 2.3 host #t1-step-2 not found');return false;}
  host.innerHTML=STEP23_TEMPLATE;
  STEP23_INSTALLED=true;
  return true;
}
function activateStep23(){installStep23Dom();}

let STEP23_APPEND_HISTORY=[];
function appendStep23AppendFeedback(role,text){
  const c=document.getElementById('step2-3-chat-msgs'); if(!c)return;
  const d=document.createElement('div');d.className='chat-msg '+role;d.style.padding='6px 8px';d.style.borderRadius='6px';d.style.background=role==='user'?'var(--citi-blue-50)':'var(--layer_secondary)';d.textContent=text;c.appendChild(d);c.scrollTop=c.scrollHeight;
}
function clearStep23AppendFeedback(){STEP23_APPEND_HISTORY=[];const c=document.getElementById('step2-3-chat-msgs');if(c)c.innerHTML='';}
async function sendStep23AppendFeedback(){
  const inp=document.getElementById('step2-3-chat-input'); const message=(inp?.value||'').trim(); if(!message)return;
  inp.value='';appendStep23AppendFeedback('user',message);STEP23_APPEND_HISTORY.push({role:'user',text:message});
  try{
    const d=await apiPost('/api/v1/rpr/feedback/step2-3/assist',{message,context:{confirmed_step1:getConfirmedStep1Payload(),confirmed_scenario:STEP2_CONFIRMED_SCENARIO||{},selected_sector:getStep23SectorAnchor(),selected_sectors:[...STEP2_SELECTED_SECTORS],confirmed_portfolio:STEP22_CONFIRMED_PORTFOLIO||null,current_event_factors:STEP2_EVENT_FACTORS||{}},history:STEP23_APPEND_HISTORY.slice(-8)},60000);
    appendStep23AppendFeedback('assistant',d.answer||'');STEP23_APPEND_HISTORY.push({role:'assistant',text:d.answer||''});
    if(d.apply_supported && d.proposed_instruction){const c=document.getElementById('step2-3-chat-msgs');const b=document.createElement('button');b.className='btn btn-p btn-sm';b.textContent='Apply Confirmed Feedback';b.onclick=()=>applyStep23AppendFeedback(d.proposed_instruction);c?.appendChild(b);}
  }catch(e){appendStep23AppendFeedback('assistant','Feedback assistant error: '+String(e.message||e));}
}
async function applyStep23AppendFeedback(instruction){
  if(!STEP2_EVENT_FACTORS)return;
  const sector=getStep23SectorAnchor();if(!sector){appendStep23AppendFeedback('assistant','Confirm Step 2.2 sector context first.');return;}
  try{showLoad('Applying Step 2.3 feedback…','Sonnet 5 targeted revision → deterministic re-weighting');const d=await apiPost('/api/v1/rpr/step23/event-factors/revise',{confirmed_step1:getConfirmedStep1Payload(),confirmed_scenario:STEP2_CONFIRMED_SCENARIO||{},sector,base_framework:collectEventFactorsFromDom(false),confirmed_feedback:instruction,portfolio_context:step23PortfolioContext()},240000);STEP2_EVENT_FACTORS=d;STEP23_CONFIRMED_FRAMEWORK=null;renderEventFactors();logModelsTriggered(d,'Step 2.3 revision');appendStep23AppendFeedback('assistant','Revision applied. Review and confirm the updated framework.');}catch(e){appendStep23AppendFeedback('assistant','Revision failed: '+String(e.message||e));}finally{hideLoad();}
}

// Expose only handlers used by the appended Step 2.2 / Step 2.3 markup.
Object.assign(window,{
  switchStep22Pane,step22ToggleMenu,step22ToggleFilter,step22ClearFilter,step22SelectAllFilter,
  toggleSector,selectAllSectors,clearAllSectors,confirmPortfolioSelection,
  handleStep22UploadDragOver,handleStep22UploadDragLeave,handleStep22UploadDrop,handleStep22PortfolioUpload,confirmUploadedPortfolio,
  generateEventFactors,renderEventFactors,addBlankEventFactor,toggleRF,setEventFactorImportance,addEventFactorMetric,removeEventFactorMetric,deleteEventFactor,saveEventFactorChanges,confirmEventFactors,
  sendStep23AppendFeedback,clearStep23AppendFeedback
});
window.RPR_SAFE_APPEND_STATE={get portfolio(){return STEP22_CONFIRMED_PORTFOLIO;},get eventFactors(){return STEP2_EVENT_FACTORS;},get confirmedEventFactors(){return STEP23_CONFIRMED_FRAMEWORK;}};

function visible(el){if(!el)return false;return getComputedStyle(el).display!=='none';}
function inspectStepVisibility(){const s22=document.getElementById('t1-step-1'),s23=document.getElementById('t1-step-2');if(visible(s22))activateStep22();if(visible(s23))activateStep23();}
function boot(){
  // Crucial: no Step 2 API call and no Step 2 DOM replacement on initial Step 1 load.
  const hosts=[document.getElementById('t1-step-1'),document.getElementById('t1-step-2')].filter(Boolean);
  const obs=new MutationObserver(inspectStepVisibility);hosts.forEach(h=>obs.observe(h,{attributes:true,attributeFilter:['style','class']}));
  document.getElementById('t1-stepbar')?.addEventListener('click',()=>queueMicrotask(inspectStepVisibility));
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot);else boot();
})();
