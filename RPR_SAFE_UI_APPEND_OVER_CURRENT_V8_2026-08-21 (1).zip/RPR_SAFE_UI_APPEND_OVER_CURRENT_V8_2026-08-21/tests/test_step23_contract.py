from pathlib import Path
import sys
import types

ROOT = Path(__file__).resolve().parents[1]
BACKEND = ROOT / "backend"
sys.path.insert(0, str(BACKEND))

# The deterministic contract tests must not call an LLM. Stub only the import dependency.
llm_gateway = types.ModuleType("llm_gateway")
llm_gateway.get_gateway = lambda: None
sys.modules.setdefault("llm_gateway", llm_gateway)

from step23_event_factors_service import compact_portfolio_context, finalize_event_factors, normalize_framework, Step23Error


def metric_v(name):
    return {
        "metric": name,
        "formula": "x/y",
        "unit": "%",
        "bands": {"VERY_HIGH": "> 80", "HIGH": "60-80", "MODERATE": "40-60", "LOW": "< 40"},
        "calibration_status": "SUPPORTED",
    }


def metric_b(name):
    return {
        "metric": name,
        "formula": "a/b",
        "unit": "%",
        "bands": {"STRONG": "> 80", "MODERATE": "60-80", "WEAK": "40-60", "NEGLIGIBLE": "< 40"},
        "calibration_status": "SUPPORTED",
    }


def factor(i, importance="HIGH"):
    return {
        "factor_id": f"RF{i}",
        "name": f"Factor {i}",
        "importance": importance,
        "one_line_rationale": "Structural transmission channel.",
        "narrative": "Structural credit transmission with differentiated vulnerable and resilient company profiles.",
        "vulnerability_metrics": [metric_v("V1"), metric_v("V2")],
        "critical_threshold": {"logic": "AND", "conditions": ["Condition A", "Condition B"]},
        "buffer_metrics": [metric_b("B1"), metric_b("B2")],
        "key_principle": "Durable buffers reduce residual risk only when evidenced.",
        "scoring_logic": [
            {"score": score, "vulnerability_profile": f"Vulnerability profile {score}", "buffer_profile": f"Buffer profile {score}"}
            for score in (5, 4, 3, 2, 1)
        ],
    }


def framework():
    return {
        "factors": [factor(1, "HIGH"), factor(2, "HIGH"), factor(3, "MEDIUM"), factor(4, "MEDIUM")],
        "industry_sensitivity": [
            {"segment": "Vulnerable segment", "type": "ADVERSE", "critical_factor_ids": ["RF1"], "differential_sensitivity": "High exposure."},
            {"segment": "Resilient segment", "type": "RESILIENT", "critical_factor_ids": ["RF2"], "differential_sensitivity": "Durable mitigation."},
        ],
    }


def test_python_owns_importance_scores_and_exact_weights():
    result = normalize_framework(framework())
    assert result["weights_sum_pct"] == 100.0
    assert [f["importance_score"] for f in result["factors"]] == [2, 2, 1, 1]
    assert [f["weight_pct"] for f in result["factors"]] == [33.33, 33.33, 16.67, 16.67]
    assert result["validation"]["weights_sum_100"] is True


def test_critical_threshold_requires_multi_condition_and():
    broken = framework()
    broken["factors"][0]["critical_threshold"] = {"logic": "AND", "conditions": ["Only one condition"]}
    try:
        normalize_framework(broken)
    except Step23Error as exc:
        assert "at least two" in str(exc)
    else:
        raise AssertionError("Expected Step23Error")


def test_compact_portfolio_never_sends_raw_company_rows():
    portfolio = {
        "confirmed_portfolio": {
            "portfolio_id": "p1",
            "selection_mode": "UPLOAD",
            "company_count": 2,
            "filters": {},
            "selected_sector_ids": ["s1"],
            "companies": [
                {"cagid": "1", "company_name": "A", "l2": "Technology", "l3": "Software", "country": "US", "mle": "X"},
                {"cagid": "2", "company_name": "B", "l2": "Technology", "l3": "Software", "country": "GB", "mle": "Y"},
            ],
        }
    }
    result = compact_portfolio_context(portfolio)
    assert "companies" not in result
    assert result["company_count"] == 2
    assert result["selection_mode"] == "UPLOAD"
    assert result["sector_distribution"] == [{"l1": "", "l2": "Technology", "l3": "Software", "company_count": 2}]


def test_finalize_is_deterministic_and_marks_confirmed():
    result = finalize_event_factors(framework(), ["RF1.narrative"])
    assert result["state"] == "CONFIRMED"
    assert result["confirmed_for_downstream"] is True
    assert result["confirmation_method"] == "DETERMINISTIC_VALIDATION"
    assert result["analyst_modified_fields"] == ["RF1.narrative"]
