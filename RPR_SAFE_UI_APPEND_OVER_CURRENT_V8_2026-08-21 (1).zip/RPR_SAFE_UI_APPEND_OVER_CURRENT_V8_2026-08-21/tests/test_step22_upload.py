from pathlib import Path
import csv
import io
import sys

ROOT = Path(__file__).resolve().parents[1]
BACKEND = ROOT / "backend"
sys.path.insert(0, str(BACKEND))

from step22_portfolio_service import Step22PortfolioService


def service():
    return Step22PortfolioService(BACKEND / "data" / "step22")


def first_cagids(n=3):
    path = BACKEND / "data" / "step22" / "rpr_company_master.csv"
    with path.open("r", encoding="utf-8-sig", newline="") as fh:
        return [row["cagid"] for row in list(csv.DictReader(fh))[:n]]


def test_csv_upload_resolves_cagids_and_reports_issues():
    cagids = first_cagids(2)
    payload = ("CAGID\n" + "\n".join([cagids[0], cagids[1], cagids[0], "999999999999"]) + "\n").encode("utf-8")
    result = service().ingest_upload(file_name="portfolio.csv", content_type="text/csv", payload=payload)
    assert result["selection_mode"] == "UPLOAD"
    assert result["matched_count"] == 2
    assert result["duplicate_count"] == 1
    assert result["unmatched_count"] == 1
    assert result["confirmation_allowed"] is True
    assert {c["cagid"] for c in result["companies"]} == set(cagids)


def test_upload_finalize_uses_same_canonical_portfolio_contract():
    svc = service()
    cagids = first_cagids(3)
    payload = ("CAGID\n" + "\n".join(cagids) + "\n").encode("utf-8")
    upload = svc.ingest_upload(file_name="portfolio.csv", content_type="text/csv", payload=payload)
    final = svc.finalize(
        filters={},
        selected_sector_ids=upload["selected_sector_ids"],
        companies=[{"cagid": c["cagid"]} for c in upload["companies"]],
        selection_mode="UPLOAD",
        source_metadata={"file_name": upload["file_name"]},
    )
    assert final["status"] == "ok"
    assert final["selection_mode"] == "UPLOAD"
    assert final["company_count"] == 3
    assert {c["cagid"] for c in final["companies"]} == set(cagids)
    assert final["source_metadata"]["file_name"] == "portfolio.csv"
