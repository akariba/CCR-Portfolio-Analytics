"""Append-only Step 2.3 Event-Driven Risk Factor reasoning service.

This module deliberately does not replace Step 1, Step 2.1, Step 2.2, or the existing
step2_service.py. It consumes their confirmed outputs and generates a governed Step 2.3
proposal using the approved internal R2D2 Claude gateway.

Design split:
- Opus: substantive credit-risk methodology reasoning.
- Sonnet 5 (when explicitly configured): narrow JSON/methodology repair or targeted revision.
- Python: schema validation, importance mapping, exact weight normalization, confirmation gate.
- No public web, no mock/demo fallback, no fabricated runtime output.
"""
from __future__ import annotations

import copy
import json
import logging
import os
from collections import Counter
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Dict, Iterator, List, Optional, Sequence, Tuple

from llm_gateway import get_gateway

try:
    from rpr_model_trace import model_span as _model_span
except Exception:  # pragma: no cover - compatibility with older working packages
    _model_span = None

log = logging.getLogger("uvicorn.error")
PROMPT_DIR = Path(__file__).resolve().parent / "prompts"

# Do not guess the organisation's newest model identifiers. New Step 2.3 routing is explicit
# and environment driven. If not supplied, reuse the currently configured Step-2 Opus model.
MODEL_OPUS = (
    os.environ.get("STEP23_REASONING_MODEL")
    or os.environ.get("STEP2_OPUS_MODEL")
    or os.environ.get("RPR_OPUS_MODEL")
    or "claude-opus-4-6"
).strip()
MODEL_REPAIR = (
    os.environ.get("STEP23_REPAIR_MODEL")
    or os.environ.get("STEP23_REVISION_MODEL")
    or os.environ.get("STEP2_SONNET_MODEL")
    or MODEL_OPUS
).strip()
MODEL_REVISION = (
    os.environ.get("STEP23_REVISION_MODEL")
    or os.environ.get("STEP23_REPAIR_MODEL")
    or os.environ.get("STEP2_SONNET_MODEL")
    or MODEL_OPUS
).strip()

_IMPORTANCE_SCORE = {"HIGH": 2, "MEDIUM": 1}
_VULN_BANDS = ["VERY_HIGH", "HIGH", "MODERATE", "LOW"]
_BUFFER_BANDS = ["STRONG", "MODERATE", "WEAK", "NEGLIGIBLE"]
_SCORE_SET = {1, 2, 3, 4, 5}


class Step23Error(RuntimeError):
    pass


def _text(value: Any) -> str:
    return str(value or "").strip()


def _load_prompt(name: str) -> str:
    path = PROMPT_DIR / name
    if not path.exists():
        raise Step23Error(f"Required Step 2.3 prompt is missing: {path}")
    text = path.read_text(encoding="utf-8").strip()
    if not text:
        raise Step23Error(f"Required Step 2.3 prompt is empty: {path}")
    return text


def _gateway_for_model(model: str):
    gw = get_gateway()
    if not hasattr(gw, "call_raw"):
        raise Step23Error("Step 2.3 requires the existing prompt-oriented R2D2 gateway.")
    if hasattr(gw, "_model"):
        gw._model = model
    return gw


@contextmanager
def _trace(model: str, role: str, scope: str) -> Iterator[Any]:
    if _model_span is not None:
        with _model_span(provider="r2d2", model=model, role=role, scope=scope) as trace:
            yield trace
        return
    log.info("[LLM] START provider=r2d2 model=%s role=%s scope=%s", model, role, scope)
    try:
        yield None
    except Exception:
        log.exception("[LLM] END provider=r2d2 model=%s role=%s scope=%s status=FAILED", model, role, scope)
        raise
    else:
        log.info("[LLM] END provider=r2d2 model=%s role=%s scope=%s status=SUCCESS", model, role, scope)


def _call_json(prompt_name: str, payload: Dict[str, Any], model: str, role: str, max_tokens: int) -> Dict[str, Any]:
    gw = _gateway_for_model(model)
    with _trace(model, role, "step2.3") as trace:
        result = gw.call_raw(
            _load_prompt(prompt_name),
            json.dumps(payload, ensure_ascii=False, separators=(",", ":")),
            max_tokens=max_tokens,
        )
        if trace is not None:
            try:
                trace.output_chars = len(json.dumps(result, ensure_ascii=False))
            except Exception:
                pass
    if not isinstance(result, dict):
        raise Step23Error("Step 2.3 model response must be a JSON object.")
    return result


def _compact_step1(step1: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(step1, dict) or not step1:
        raise Step23Error("Confirmed Step 1 payload is required.")
    keys = (
        "event_overview", "event_history", "direct_impact_geographies",
        "contagion_impact_geographies", "contagious_impact_geographies",
        "equity_market_impact", "credit_market_impact", "commodity_market_impact",
        "assumptions", "scenario_label", "event_summary", "history", "direct_impact",
        "contagion_impact", "equity_impact", "credit_impact", "commodity_impact",
        "machine_payload", "analyst_state", "trigger", "theme", "event",
    )
    compact = {k: step1[k] for k in keys if k in step1}
    return compact or dict(step1)


def _require_confirmed_scenario(scenario: Dict[str, Any]) -> None:
    if not isinstance(scenario, dict) or not scenario:
        raise Step23Error("Confirmed Step 2.1 scenario is required.")
    confirmed = bool(scenario.get("confirmed_for_downstream")) or _text(scenario.get("state")).upper() == "CONFIRMED"
    if not confirmed:
        raise Step23Error("Step 2.3 requires a confirmed Step 2.1 scenario.")


def _top_counts(companies: Sequence[Dict[str, Any]], field: str, limit: int = 20) -> List[Dict[str, Any]]:
    counts = Counter(_text(c.get(field)) for c in companies if isinstance(c, dict) and _text(c.get(field)))
    return [{"value": k, "count": v} for k, v in counts.most_common(limit)]


def compact_portfolio_context(portfolio_context: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    """Bound Step 2.2 context before an LLM call; never forward the raw company universe."""
    raw = dict(portfolio_context or {})
    portfolio = raw.get("confirmed_portfolio")
    if not isinstance(portfolio, dict):
        portfolio = raw if isinstance(raw.get("companies"), list) else {}

    companies = portfolio.get("companies") if isinstance(portfolio, dict) else []
    if not isinstance(companies, list):
        companies = []

    sector_counts: Counter[Tuple[str, str, str]] = Counter()
    for c in companies:
        if not isinstance(c, dict):
            continue
        sector_counts[(_text(c.get("l1")), _text(c.get("l2")), _text(c.get("l3") or c.get("sector_label")))] += 1
    sectors = [
        {"l1": l1, "l2": l2, "l3": l3, "company_count": count}
        for (l1, l2, l3), count in sector_counts.most_common(30)
        if l1 or l2 or l3
    ]

    selected_ids = portfolio.get("selected_sector_ids") if isinstance(portfolio, dict) else []
    if not isinstance(selected_ids, list):
        selected_ids = []
    if not selected_ids:
        selected_ids = raw.get("selected_sectors") if isinstance(raw.get("selected_sectors"), list) else []

    return {
        "portfolio_id": _text(portfolio.get("portfolio_id")) if isinstance(portfolio, dict) else "",
        "selection_mode": _text(portfolio.get("selection_mode") or "FILTERS") if isinstance(portfolio, dict) else "FILTERS",
        "company_count": int(portfolio.get("company_count") or len(companies)) if isinstance(portfolio, dict) else len(companies),
        "filters": dict(portfolio.get("filters") or {}) if isinstance(portfolio, dict) else {},
        "selected_sector_ids": [_text(x) for x in selected_ids if _text(x)][:100],
        "sector_distribution": sectors,
        "other_sector_count": max(0, len(sector_counts) - len(sectors)),
        "geography_distribution": _top_counts(companies, "geography"),
        "country_distribution": _top_counts(companies, "country"),
        "mle_distribution": _top_counts(companies, "mle"),
        "risk_rating_distribution": _top_counts(companies, "risk_rating", limit=12),
        "note": "Aggregate Step 2.2 context only; raw company rows intentionally omitted from the model payload.",
    }


def _normalize_metric(metric: Dict[str, Any], bands: List[str], factor_id: str, kind: str) -> Dict[str, Any]:
    if not isinstance(metric, dict):
        raise Step23Error(f"{factor_id} {kind} metric must be an object.")
    name = _text(metric.get("metric"))
    if not name:
        raise Step23Error(f"{factor_id} {kind} metric is missing a metric name.")
    raw_bands = metric.get("bands")
    if not isinstance(raw_bands, dict):
        raise Step23Error(f"{factor_id} {kind} metric '{name}' is missing bands.")
    clean_bands = {band: _text(raw_bands.get(band)) for band in bands}
    missing = [band for band, value in clean_bands.items() if not value]
    if missing:
        raise Step23Error(f"{factor_id} {kind} metric '{name}' is missing bands: {', '.join(missing)}.")
    calibration = _text(metric.get("calibration_status") or "REQUIRES_METHODOLOGY_REVIEW").upper()
    if calibration not in {"SUPPORTED", "REQUIRES_METHODOLOGY_REVIEW"}:
        calibration = "REQUIRES_METHODOLOGY_REVIEW"
    return {
        "metric": name,
        "formula": metric.get("formula"),
        "unit": metric.get("unit"),
        "bands": clean_bands,
        "calibration_status": calibration,
    }


def _normalize_scoring_logic(rows: Any, factor_id: str) -> List[Dict[str, Any]]:
    if not isinstance(rows, list):
        raise Step23Error(f"{factor_id} must contain scoring_logic rows 1-5.")
    normalized: Dict[int, Dict[str, Any]] = {}
    for row in rows:
        if not isinstance(row, dict):
            continue
        try:
            score = int(row.get("score"))
        except Exception:
            continue
        if score not in _SCORE_SET:
            continue
        vuln = _text(row.get("vulnerability_profile"))
        buf = _text(row.get("buffer_profile"))
        if not vuln or not buf:
            raise Step23Error(f"{factor_id} scoring row {score} requires vulnerability and buffer profiles.")
        normalized[score] = {
            "score": score,
            "vulnerability_profile": vuln,
            "buffer_profile": buf,
        }
    if set(normalized) != _SCORE_SET:
        missing = sorted(_SCORE_SET - set(normalized), reverse=True)
        raise Step23Error(f"{factor_id} scoring_logic is missing score rows: {missing}.")
    return [normalized[i] for i in (5, 4, 3, 2, 1)]


def normalize_framework(result: Dict[str, Any]) -> Dict[str, Any]:
    """Deterministically validate Step 2.3 and own all arithmetic."""
    if not isinstance(result, dict):
        raise Step23Error("Step 2.3 framework must be an object.")
    result = copy.deepcopy(result)
    factors = result.get("factors")
    if not isinstance(factors, list) or not (4 <= len(factors) <= 6):
        raise Step23Error("Step 2.3 must contain 4-6 event-driven risk factors.")

    seen_ids = set()
    importance_scores: List[int] = []
    review_items: List[str] = []

    for index, factor in enumerate(factors, start=1):
        if not isinstance(factor, dict):
            raise Step23Error(f"Risk factor {index} is not an object.")
        fid = _text(factor.get("factor_id") or f"RF{index}")
        if fid in seen_ids:
            raise Step23Error(f"Duplicate Step 2.3 factor_id: {fid}.")
        seen_ids.add(fid)
        factor["factor_id"] = fid
        factor["name"] = _text(factor.get("name"))
        factor["one_line_rationale"] = _text(factor.get("one_line_rationale"))
        factor["narrative"] = _text(factor.get("narrative"))
        if not factor["name"] or not factor["narrative"]:
            raise Step23Error(f"{fid} requires a factor name and narrative.")

        importance = _text(factor.get("importance")).upper()
        if importance not in _IMPORTANCE_SCORE:
            raise Step23Error(f"{fid} importance must be HIGH or MEDIUM.")
        factor["importance"] = importance
        factor["importance_score"] = _IMPORTANCE_SCORE[importance]
        importance_scores.append(_IMPORTANCE_SCORE[importance])

        vuln = factor.get("vulnerability_metrics")
        if not isinstance(vuln, list) or not (2 <= len(vuln) <= 5):
            raise Step23Error(f"{fid} must contain 2-5 vulnerability metrics.")
        factor["vulnerability_metrics"] = [_normalize_metric(m, _VULN_BANDS, fid, "vulnerability") for m in vuln]

        buffers = factor.get("buffer_metrics")
        if not isinstance(buffers, list) or not (2 <= len(buffers) <= 5):
            raise Step23Error(f"{fid} must contain 2-5 durable buffer metrics.")
        factor["buffer_metrics"] = [_normalize_metric(m, _BUFFER_BANDS, fid, "buffer") for m in buffers]

        for metric in factor["vulnerability_metrics"] + factor["buffer_metrics"]:
            if metric["calibration_status"] == "REQUIRES_METHODOLOGY_REVIEW":
                review_items.append(f"{fid}: {metric['metric']}")

        threshold = factor.get("critical_threshold")
        conditions = threshold.get("conditions") if isinstance(threshold, dict) else None
        clean_conditions = [_text(x) for x in conditions or [] if _text(x)] if isinstance(conditions, list) else []
        if len(clean_conditions) < 2:
            raise Step23Error(f"{fid} critical threshold must contain at least two simultaneous AND conditions.")
        factor["critical_threshold"] = {"logic": "AND", "conditions": clean_conditions}

        factor["key_principle"] = _text(factor.get("key_principle") or factor.get("scoring_rationale"))
        if not factor["key_principle"]:
            raise Step23Error(f"{fid} requires a key principle for durable buffer interpretation.")
        factor["scoring_logic"] = _normalize_scoring_logic(factor.get("scoring_logic"), fid)
        factor["net_score_formula"] = "max(1, min(5, Raw Vulnerability Score - Buffer Credit))"

    total = sum(importance_scores)
    weights = [round(score * 100.0 / total, 2) for score in importance_scores]
    if weights:
        weights[-1] = round(weights[-1] + (100.0 - sum(weights)), 2)
    for factor, weight in zip(factors, weights):
        factor["weight_pct"] = weight

    sensitivity = result.get("industry_sensitivity")
    if not isinstance(sensitivity, list):
        sensitivity = []
    clean_sensitivity: List[Dict[str, Any]] = []
    for item in sensitivity:
        if not isinstance(item, dict):
            continue
        kind = _text(item.get("type")).upper()
        if kind not in {"ADVERSE", "RESILIENT", "BENEFICIARY"}:
            kind = "ADVERSE"
        refs = [_text(x) for x in item.get("critical_factor_ids") or [] if _text(x) in seen_ids]
        segment = _text(item.get("segment"))
        rationale = _text(item.get("differential_sensitivity"))
        if segment and rationale:
            clean_sensitivity.append({
                "segment": segment,
                "type": kind,
                "critical_factor_ids": refs,
                "differential_sensitivity": rationale,
            })

    limitations = [_text(x) for x in result.get("methodology_limitations") or [] if _text(x)]
    if review_items:
        limitations.append("Methodology calibration review required for: " + "; ".join(review_items))

    result["factors"] = factors
    result["industry_sensitivity"] = clean_sensitivity
    result["methodology_limitations"] = limitations
    result["importance_mapping"] = {"HIGH": 2, "MEDIUM": 1}
    result["weight_method"] = "DETERMINISTIC_IMPORTANCE_NORMALIZATION"
    result["buffer_credit_mapping"] = {"STRONG": -2, "MODERATE": -1, "WEAK": 0, "NEGLIGIBLE": 0}
    result["score_definitions"] = {
        "1": "fully mitigated / minimal residual risk",
        "2": "substantially mitigated",
        "3": "partially mitigated",
        "4": "weakly mitigated",
        "5": "unmitigated; reserved for confirmed critical threshold breach",
    }
    result["weights_sum_pct"] = round(sum(f["weight_pct"] for f in factors), 2)
    result["validation"] = {
        "factor_count_valid": True,
        "weights_sum_100": abs(result["weights_sum_pct"] - 100.0) < 0.001,
        "importance_mapping_valid": True,
        "critical_threshold_rule": "MULTI_CONDITION_AND",
        "scoring_rows_1_to_5": True,
        "calibration_review_count": len(review_items),
        "raw_company_rows_sent_to_model": False,
    }
    result["state"] = "AI_PROPOSAL"
    return result


def _repair_framework(broken: Dict[str, Any], validation_error: Exception, context: Dict[str, Any]) -> Dict[str, Any]:
    payload = {
        "VALIDATION_ERROR": str(validation_error),
        "BROKEN_FRAMEWORK": broken,
        "GOVERNANCE_CONTEXT": context,
    }
    repaired = _call_json(
        "step23_event_factors_repair.txt",
        payload,
        MODEL_REPAIR,
        role="step23_structural_repair",
        max_tokens=11000,
    )
    return normalize_framework(repaired)


def generate_event_factors(
    confirmed_step1: Dict[str, Any],
    confirmed_scenario: Dict[str, Any],
    sector: str,
    portfolio_context: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    _require_confirmed_scenario(confirmed_scenario)
    sector = _text(sector)
    if not sector:
        raise Step23Error("A Step 2.2 portfolio sector/L2-L3 anchor is required for Step 2.3.")
    compact_portfolio = compact_portfolio_context(portfolio_context)
    payload = {
        "CONFIRMED_STEP1": _compact_step1(confirmed_step1),
        "CONFIRMED_STEP2_SCENARIO": _text(confirmed_scenario.get("scenario_narrative")),
        "CONFIRMED_STEP2_ASSUMPTIONS": confirmed_scenario.get("assumptions") or [],
        "ASSESSMENT_HORIZON": _text(confirmed_scenario.get("assessment_horizon")),
        "SELECTED_SECTOR_ANCHOR": sector,
        "CONFIRMED_PORTFOLIO_CONTEXT": compact_portfolio,
    }
    raw = _call_json(
        "step23_event_factors_opus.txt",
        payload,
        MODEL_OPUS,
        role="step23_event_factor_reasoning",
        max_tokens=14000,
    )
    try:
        result = normalize_framework(raw)
        repair_used = False
    except Step23Error as exc:
        result = _repair_framework(raw, exc, {"sector": sector, "portfolio": compact_portfolio})
        repair_used = True

    result["sector_anchor"] = sector
    result["portfolio_context"] = compact_portfolio
    result["model_path"] = MODEL_OPUS
    result["models_triggered"] = [{"provider": "r2d2", "model": MODEL_OPUS, "role": "step23_event_factor_reasoning"}]
    if repair_used:
        result["models_triggered"].append({"provider": "r2d2", "model": MODEL_REPAIR, "role": "step23_structural_repair"})
    result["prompt_version"] = "step23_event_factors_opus_v1"
    result["repair_used"] = repair_used
    return result


def revise_event_factors(
    confirmed_step1: Dict[str, Any],
    confirmed_scenario: Dict[str, Any],
    sector: str,
    base_framework: Dict[str, Any],
    confirmed_feedback: str,
    portfolio_context: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    _require_confirmed_scenario(confirmed_scenario)
    sector = _text(sector)
    feedback = _text(confirmed_feedback)
    if not sector:
        raise Step23Error("A Step 2.2 sector anchor is required for Step 2.3 revision.")
    if not feedback:
        raise Step23Error("Confirmed analyst feedback is required for Step 2.3 revision.")
    if not isinstance(base_framework, dict) or not isinstance(base_framework.get("factors"), list):
        raise Step23Error("Current Step 2.3 factor framework is required for revision.")

    compact_portfolio = compact_portfolio_context(portfolio_context)
    payload = {
        "CONFIRMED_STEP1": _compact_step1(confirmed_step1),
        "CONFIRMED_STEP2_SCENARIO": _text(confirmed_scenario.get("scenario_narrative")),
        "CONFIRMED_STEP2_ASSUMPTIONS": confirmed_scenario.get("assumptions") or [],
        "SELECTED_SECTOR_ANCHOR": sector,
        "CONFIRMED_PORTFOLIO_CONTEXT": compact_portfolio,
        "CURRENT_FRAMEWORK": base_framework,
        "CONFIRMED_ANALYST_FEEDBACK": feedback,
    }
    raw = _call_json(
        "step23_event_factors_revision.txt",
        payload,
        MODEL_REVISION,
        role="step23_targeted_revision",
        max_tokens=13000,
    )
    try:
        result = normalize_framework(raw)
        repair_used = False
    except Step23Error as exc:
        result = _repair_framework(raw, exc, {"sector": sector, "portfolio": compact_portfolio})
        repair_used = True

    result["state"] = "AI_REVISION"
    result["sector_anchor"] = sector
    result["portfolio_context"] = compact_portfolio
    result["model_path"] = MODEL_REVISION
    result["models_triggered"] = [{"provider": "r2d2", "model": MODEL_REVISION, "role": "step23_targeted_revision"}]
    if repair_used and MODEL_REPAIR != MODEL_REVISION:
        result["models_triggered"].append({"provider": "r2d2", "model": MODEL_REPAIR, "role": "step23_structural_repair"})
    result["prompt_version"] = "step23_event_factors_revision_v1"
    result["revision"] = {
        "feedback_applied": feedback,
        "preserve_unaffected_content": True,
        "requires_reconfirmation": True,
    }
    result["repair_used"] = repair_used
    return result


def finalize_event_factors(framework: Dict[str, Any], analyst_modified_fields: Optional[List[str]] = None) -> Dict[str, Any]:
    """Deterministic Step 2.3 confirmation. No model call."""
    confirmed = normalize_framework(framework)
    confirmed["state"] = "CONFIRMED"
    confirmed["confirmed_for_downstream"] = True
    confirmed["analyst_modified_fields"] = sorted({_text(x) for x in analyst_modified_fields or [] if _text(x)})
    confirmed["confirmation_method"] = "DETERMINISTIC_VALIDATION"
    return confirmed
