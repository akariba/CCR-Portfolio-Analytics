"""Append-only FastAPI routes for live Step 2.3 Event-Driven Risk Factors."""
from __future__ import annotations

from typing import Any, Dict, List

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, ConfigDict, Field

from step23_event_factors_service import (
    Step23Error,
    finalize_event_factors,
    generate_event_factors,
    revise_event_factors,
    normalize_framework,
)

router = APIRouter(
    prefix="/api/v1/rpr/step23/event-factors",
    tags=["RPR Step 2.3 Event-Driven Risk Factors"],
)


class GenerateRequest(BaseModel):
    model_config = ConfigDict(extra="ignore")
    confirmed_step1: Dict[str, Any]
    confirmed_scenario: Dict[str, Any]
    sector: str
    portfolio_context: Dict[str, Any] = Field(default_factory=dict)


class ReviseRequest(GenerateRequest):
    base_framework: Dict[str, Any]
    confirmed_feedback: str


class ValidateRequest(BaseModel):
    model_config = ConfigDict(extra="ignore")
    framework: Dict[str, Any]


class FinalizeRequest(BaseModel):
    model_config = ConfigDict(extra="ignore")
    framework: Dict[str, Any]
    analyst_modified_fields: List[str] = Field(default_factory=list)


def _raise(exc: Exception):
    if isinstance(exc, Step23Error):
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    raise HTTPException(status_code=502, detail=f"Step 2.3 processing failed: {type(exc).__name__}: {exc}") from exc


@router.post("/generate")
def generate(req: GenerateRequest) -> Dict[str, Any]:
    try:
        return generate_event_factors(
            req.confirmed_step1,
            req.confirmed_scenario,
            req.sector,
            req.portfolio_context,
        )
    except Exception as exc:
        _raise(exc)


@router.post("/revise")
def revise(req: ReviseRequest) -> Dict[str, Any]:
    try:
        return revise_event_factors(
            req.confirmed_step1,
            req.confirmed_scenario,
            req.sector,
            req.base_framework,
            req.confirmed_feedback,
            req.portfolio_context,
        )
    except Exception as exc:
        _raise(exc)


@router.post("/validate")
def validate(req: ValidateRequest) -> Dict[str, Any]:
    """Deterministic validation/re-weighting for analyst edits. No LLM call."""
    try:
        result = normalize_framework(req.framework)
        result["state"] = "ANALYST_EDIT"
        result["confirmed_for_downstream"] = False
        return result
    except Exception as exc:
        _raise(exc)


@router.post("/finalize")
def finalize(req: FinalizeRequest) -> Dict[str, Any]:
    try:
        return finalize_event_factors(req.framework, req.analyst_modified_fields)
    except Exception as exc:
        _raise(exc)
