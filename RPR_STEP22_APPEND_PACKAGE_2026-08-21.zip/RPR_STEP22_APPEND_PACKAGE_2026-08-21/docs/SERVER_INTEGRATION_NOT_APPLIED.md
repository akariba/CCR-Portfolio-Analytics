# Server integration — NOT APPLIED

The frozen `server.py` is deliberately not modified in this package.

After review/approval, Claude should make only these two additive changes.

## 1. Import

Near the existing router imports:

```python
from step22_portfolio_routes import router as step22_portfolio_router
```

## 2. Include router

Near the existing `app.include_router(...)` registrations:

```python
app.include_router(step22_portfolio_router)
```

Nothing else in `server.py` should change.

Do not move, refactor, rename, or reformat unrelated code.
