# v31 frontend alignment — NOT APPLIED

No HTML file was modified because the current source HTML was not supplied as a file in
this package. Preserve the v31 visual baseline exactly.

The Stylus diagnosis/API contract supplied by the user is the frontend source of truth.

## Expected frontend calls

### Catalog
`GET /api/v1/rpr/step2/portfolio/catalog`

Response fields:
- `geographies`
- `countries[{code,name,geography}]`
- `mles[{code,name,geography}]`
- `l2_categories`
- `sectors[{id,l1,l2,l3}]`

### Search
`POST /api/v1/rpr/step2/portfolio/search`

Body:
```json
{
  "geography": "",
  "country": "",
  "mle": "",
  "l2": "Technology",
  "l3": []
}
```

`l3` contains backend sector IDs when L3 cards are checked.
An empty `l3` list with `l2="Technology"` means all Technology L3 sectors.

Response:
- `companies`
- `total_count`
- `valid_filters.countries`
- `valid_filters.mles`
- `valid_filters.sectors`

### Finalize
`POST /api/v1/rpr/step2/portfolio/finalize`

Body:
```json
{
  "filters": {
    "geography": "",
    "country": "",
    "mle": "",
    "l2": "Technology"
  },
  "selected_sector_ids": [],
  "companies": []
}
```

If `companies` is empty, backend confirms the full filtered universe.
If company CAGIDs are supplied, backend confirms only those names that are still inside
the filtered universe.

## Design rules

- Zero CSS changes.
- Keep all v31 IDs/classes.
- Reuse existing sector cards/table/components.
- No hard-coded taxonomy/company fallback in JS.
- Upload Portfolio remains untouched for this phase.
