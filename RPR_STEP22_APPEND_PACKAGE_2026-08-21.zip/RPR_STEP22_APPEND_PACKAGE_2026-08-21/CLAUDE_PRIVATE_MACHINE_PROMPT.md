You are integrating an additive Step 2.2 backend package into the current RPR working bone.

STRICT RULES:
1. Do not rewrite or refactor working files.
2. v31 frontend visual design is immutable: zero CSS/layout/color/typography changes.
3. Do not touch Trigger 1, Step 2.1, Step 2.3, Step 2.4, Step 2.5, Step 3, or feedback logic except the minimum Step 2.2 wiring explicitly described.
4. Do not introduce mocks, public-web fallbacks, fabricated runtime results, or model changes.
5. Step 2.2 is deterministic; it does not call an LLM.
6. Before editing, inspect the current `server.py` and v31 HTML and compare against the supplied integration notes.
7. Apply only the two-line additive server integration from `docs/SERVER_INTEGRATION_NOT_APPLIED.md`.
8. Wire the current Step 2.2 HTML/JS to the API contract in `docs/FRONTEND_ALIGNMENT_NOT_APPLIED.md`, preserving the exact v31 visual baseline.
9. Keep the business rule: L2 selected + zero checked L3 cards = all valid L3s under that L2.
10. Run the supplied tests and then test:
    - catalog loads;
    - Technology returns only Technology L3 cards;
    - selecting Software returns only Software companies;
    - Geography/Country/MLE combine correctly;
    - finalize returns the confirmed company universe.
11. Report every changed existing file. Do not make any unrelated change.
