# RPR Step 2.2 — Additive Backend Package

## Strict bone rule

This package **does not overwrite or modify any frozen working file**.

It adds Step 2.2 as a separate deterministic service/router. Trigger 1, Step 2.1,
Step 2.3, feedback, model routing, and the v31 visual baseline remain untouched.

## What is implemented

- Backend-driven Geography / Country / MLE / sector catalog.
- L2 -> L3 cascade.
- Company/CAGID filtering from the Step 2.2 company master.
- Combined filters.
- Business rule: selecting L2 with zero checked L3 cards means **all valid L3s under L2**.
- Finalize endpoint that recomputes/validates the selected universe and returns a
  confirmed Step 2.2 portfolio payload for downstream use.
- CSV file auto-reload when the dataset changes.
- No LLM calls.
- No public internet.
- No fabricated runtime fallback if the CSV files are missing.

## API

- `GET /api/v1/rpr/step2/portfolio/catalog`
- `POST /api/v1/rpr/step2/portfolio/search`
- `POST /api/v1/rpr/step2/portfolio/finalize`

The contract is aligned with the Stylus Step 2.2 diagnosis supplied by the user.

## Demo data

The included CSVs are synthetic and screenshot-inspired. They use field names observed
in the supplied internal-data screenshots, including CAGID, L1/L2/L3/L4, risk rating,
credit classification, country risk code and MLE fields.

They are **not real client data**.

## Files to add

- `backend/step22_portfolio_service.py`
- `backend/step22_portfolio_routes.py`
- `backend/data/step22/*.csv`

## Existing files intentionally not changed

- `server.py`
- `step2_service.py`
- `step2_routes.py`
- the v31 HTML
- all Trigger 1 files
- all Step 2.1 / 2.3 files

See `docs/SERVER_INTEGRATION_NOT_APPLIED.md` and
`docs/FRONTEND_ALIGNMENT_NOT_APPLIED.md` for the minimal reviewed integration steps.
