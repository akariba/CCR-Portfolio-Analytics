from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
BACKEND = ROOT / "backend"
sys.path.insert(0, str(BACKEND))

from step22_portfolio_service import Step22PortfolioService


def service():
    return Step22PortfolioService(BACKEND / "data" / "step22")


def test_catalog_contains_technology_l3s():
    cat = service().catalog()
    assert "Technology" in cat["l2_categories"]
    tech = {s["l3"] for s in cat["sectors"] if s["l2"] == "Technology"}
    expected = {
        "Communications Equipment",
        "Computer & Computer Hardware",
        "Electronic Manufacturing Services",
        "Internet Software & Services",
        "IT SERVICES",
        "Semiconductors & Semiconductor Equipment",
        "Software",
        "Technology",
        "Technology - SPV",
        "Technology Distributors",
    }
    assert expected.issubset(tech)


def test_l2_without_l3_means_all_l3_under_l2():
    svc = service()
    result = svc.search(l2="Technology", sector_ids=[])
    assert result["total_count"] > 0
    assert {c["l2"] for c in result["companies"]} == {"Technology"}
    assert len({c["l3"] for c in result["companies"]}) >= 10


def test_l2_to_l3_cascade_returns_only_technology_sectors():
    svc = service()
    result = svc.search(l2="Technology", sector_ids=[])
    sectors = result["valid_filters"]["sectors"]
    assert sectors
    assert {s["l2"] for s in sectors} == {"Technology"}


def test_select_software_sector_filters_companies():
    svc = service()
    cat = svc.catalog()
    software = next(s for s in cat["sectors"] if s["l2"] == "Technology" and s["l3"] == "Software")
    result = svc.search(l2="Technology", sector_ids=[software["id"]])
    assert result["total_count"] > 0
    assert {c["l3"] for c in result["companies"]} == {"Software"}


def test_combined_geography_and_l2_filter():
    svc = service()
    result = svc.search(geography="Europe", l2="Technology", sector_ids=[])
    assert result["total_count"] > 0
    assert {c["geography"] for c in result["companies"]} == {"Europe"}
    assert {c["l2"] for c in result["companies"]} == {"Technology"}


def test_finalize_recomputes_and_confirms_universe():
    svc = service()
    search = svc.search(l2="Technology", sector_ids=[])
    final = svc.finalize(
        filters={"l2": "Technology"},
        selected_sector_ids=[],
        companies=[],
    )
    assert final["status"] == "ok"
    assert final["portfolio_id"].startswith("step22-")
    assert final["company_count"] == search["total_count"]
    assert {c["l2"] for c in final["companies"]} == {"Technology"}
