RPR V31 VISUAL PATCH V3

V2 safely aborted before writing any project files because the detector pattern
was over-escaped and therefore looked for literal '\s' text.

V3 fixes only that detector. All bone-protection rules remain unchanged.

Run from the Rapid Portfolio Review_AI root:

python .\apply_rpr_v31_visual_patch_v3.py

If PASS:
- Ctrl+F5
- check Step 2.2 and Step 2.3

If ABORTED:
- stop
- send the exact message
