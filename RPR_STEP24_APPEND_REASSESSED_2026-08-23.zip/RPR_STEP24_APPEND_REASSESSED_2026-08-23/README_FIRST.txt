RPR STEP 2.4 APPEND — REASSESSED PACKAGE — 2026-08-23

PURPOSE
Append live Step 2.4 Sector-Inherent Risk Factors on top of the CURRENT working Step 1 + 2.1 + 2.2 + 2.3 building bones. Nothing in the existing working bones is replaced.

COPY INTO YOUR CURRENT ROOT
C:\Users\ak54743\Downloads\OneDrive_2026-07-16\Rapid Portfolio Review_AI

A. COPY NEW BACKEND FILES
Package backend\step24_sector_factors_service.py
  -> Rapid Portfolio Review_AI\backend\step24_sector_factors_service.py
Package backend\step24_sector_factors_routes.py
  -> Rapid Portfolio Review_AI\backend\step24_sector_factors_routes.py

B. COPY NEW PROMPTS
Package backend\prompts\step24_sector_inherent_v5_2.txt
  -> Rapid Portfolio Review_AI\backend\prompts\step24_sector_inherent_v5_2.txt
Package backend\prompts\step24_sector_inherent_revision.txt
  -> Rapid Portfolio Review_AI\backend\prompts\step24_sector_inherent_revision.txt

C. COPY NEW DATA FOLDER
Package backend\data\step24\*
  -> Rapid Portfolio Review_AI\backend\data\step24\*
Do NOT touch backend\data\step22.

D. APPEND TWO LINES TO EXISTING server.py
Follow SERVER_APPEND_ONLY.txt. Do not replace server.py.

E. COPY FRONTEND APPENDS
Package frontend_append\rpr_step24_append.js
  -> Rapid Portfolio Review_AI\UI Design\rpr_step24_append.js
Package frontend_append\rpr_step24_append.css
  -> Rapid Portfolio Review_AI\UI Design\rpr_step24_append.css

F. APPEND TWO TAGS TO THE CURRENT WORKING HTML
Follow HTML_APPEND_ONLY.txt. Do not replace the working SAFE Step22/Step23 HTML.

G. MODEL ENVIRONMENT
Use MODEL_ENV_APPEND_ONLY.txt. Reuse the exact approved Opus and Sonnet 5 identifiers already proven in your environment.

H. OPTIONAL TEST COPY
Copy tests\test_step24_sector_factors.py and tests\test_step24_frontend_contract.py into Rapid Portfolio Review_AI\tests\.
Run from project root:
  python -m pytest tests\test_step24_sector_factors.py tests\test_step24_frontend_contract.py -q

I. RESTART BACKEND AS YOU DO NOW
From Rapid Portfolio Review_AI\backend:
  uvicorn server:app --host 127.0.0.1 --port 8000 --reload

VERIFY
1. http://127.0.0.1:8000/health still returns 200.
2. http://127.0.0.1:8000/docs includes:
   GET  /api/v1/rpr/step24/sector-factors/catalog
   POST /api/v1/rpr/step24/sector-factors/resolve
   POST /api/v1/rpr/step24/sector-factors/generate
   POST /api/v1/rpr/step24/sector-factors/revise
   POST /api/v1/rpr/step24/sector-factors/finalize
3. Open the SAME working SAFE HTML you already use.
4. Test Step 1 and Step 2.1 quickly: behavior must be unchanged.
5. Confirm Step 2.2 portfolio as before.
6. Generate/confirm Step 2.3 as before.
7. Open Step 2.4. Existing sector dropdown remains the V31 control. Click Generate Sector Factors.
8. For Technology > Software, expect five governed factors from the supplied reference list. Backend logs should show Opus only for core Step 2.4 reasoning.
9. Confirm Step 2.4; finalization is deterministic and does not call an LLM.

IMPORTANT DATA LIMITATION
Only Technology > Software factor names/details were supplied in the screenshots. The architecture is ready for every L3, but each other L3 needs approved factor rows added to backend\data\step24\sector_inherent_factors.csv. The service intentionally refuses to invent missing sector taxonomy.
