from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
JS = (ROOT / "frontend_append" / "rpr_step24_append.js").read_text(encoding="utf-8")
CSS = (ROOT / "frontend_append" / "rpr_step24_append.css").read_text(encoding="utf-8")


def test_step24_js_only_calls_step24_api_for_core_generation():
    assert "/api/v1/rpr/step24/sector-factors/generate" in JS
    assert "confirmed_step1:" not in JS
    assert "confirmed_scenario:" not in JS
    assert "/step23/" not in JS


def test_step24_css_is_scoped():
    rules = [x.strip() for x in CSS.split("}") if "{" in x]
    assert rules
    for rule in rules:
        selector = rule.split("{",1)[0].strip()
        assert selector.startswith("#t1-step-3") or selector.startswith("/*")


def test_append_wraps_existing_switch_step_instead_of_replacing_other_steps():
    assert "const oldSwitch=switchStep" in JS
    assert "if(Number(idx)===3)" in JS
