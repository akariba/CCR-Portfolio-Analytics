import importlib
import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BACKEND = ROOT / "backend"
sys.path.insert(0, str(BACKEND))

os.environ.setdefault("STEP24_REASONING_MODEL", "approved-opus-test")
os.environ.setdefault("STEP24_REVISION_MODEL", "approved-sonnet5-test")
os.environ.setdefault("STEP24_REPAIR_MODEL", "approved-sonnet5-test")

svc = importlib.import_module("step24_sector_factors_service")


def sample_model_output():
    governed = svc.governed_sector({"l3": "Software"})
    factors = []
    for i, g in enumerate(governed["factors"], 1):
        factors.append({
            "factor_order": i,
            "name": g["name"],
            "rationale": "Sector-inherent mechanism.",
            "importance": "HIGH" if i in {1,2,4,5} else "MEDIUM",
            "importance_justification": "Structural sector relevance.",
            "vulnerability_metrics": [
                {"metric": f"V{i}A", "source":"Financials", "formula":"A/B*100", "direction":"HIGHER_WORSE", "bands":{"VERY_HIGH":">40%","HIGH":"30-40%","MODERATE":"15-30%","LOW":"<15%"}},
                {"metric": f"V{i}B", "source":"Financials", "formula":"C/D*100", "direction":"LOWER_WORSE", "bands":{"VERY_HIGH":"<5%","HIGH":"5-10%","MODERATE":"10-20%","LOW":">20%"}},
                {"metric": f"V{i}C", "source":"Financials", "formula":"E/F", "direction":"HIGHER_WORSE", "bands":{"VERY_HIGH":">8x","HIGH":"5-8x","MODERATE":"3-5x","LOW":"<3x"}},
            ],
            "critical_threshold":{"conditions":["V1 > 40%","V2 < 5%","V3 > 8x"]},
            "buffer_metrics": [
                {"metric": f"B{i}A", "source":"Financials", "formula":"G/H*100", "direction":"HIGHER_STRONGER", "bands":{"STRONG":">60%","MODERATE":"40-60%","WEAK":"20-40%","NEGLIGIBLE":"<20%"}},
                {"metric": f"B{i}B", "source":"Financials", "formula":"I/J", "direction":"HIGHER_STRONGER", "bands":{"STRONG":">5x","MODERATE":"3-5x","WEAK":"1.5-3x","NEGLIGIBLE":"<1.5x"}},
                {"metric": f"B{i}C", "source":"Financials", "formula":"K/L*100", "direction":"LOWER_STRONGER", "bands":{"STRONG":"<10%","MODERATE":"10-20%","WEAK":"20-30%","NEGLIGIBLE":">30%"}},
            ],
            "key_principle":"Formal credit requires multiple strong buffers.",
            "scoring":[{"score":s,"vulnerability_profile":f"v{s}","buffer_profile":f"b{s}"} for s in [5,4,3,2,1]],
            "reference_raw_score": 3,
            "reference_buffer_strength":"WEAK",
            "credit_implication":"Reference sector risk only."
        })
    return {"sector_preamble":"Reference sector framework.","factors":factors}


def test_software_master_has_five_governed_factors():
    sec = svc.governed_sector({"l3":"Software"})
    assert sec["l2"] == "Technology"
    assert [x["name"] for x in sec["factors"]] == [
        "Cybersecurity Vulnerabilities",
        "Talent Acquisition",
        "High Customer Switching Costs (Vendor Lock-in)",
        "Pace of Innovation",
        "Competition",
    ]


def test_weights_are_backend_controlled_and_exact_100():
    sec = svc.governed_sector({"l3":"Software"})
    out = svc._validate_and_govern(sample_model_output(), sec)
    assert out["weights_sum_pct"] == 100.0
    # 4 High (2 each) + 1 Medium = 9 -> 22.22 / 11.11 pattern, final row absorbs rounding.
    assert out["factors"][0]["importance_score"] == 2
    assert out["factors"][2]["importance_score"] == 1
    assert abs(sum(x["weight_pct"] for x in out["factors"]) - 100.0) < 1e-9


def test_buffer_sign_is_unambiguous_reduction():
    obj = sample_model_output()
    obj["factors"][0]["reference_raw_score"] = 4
    obj["factors"][0]["reference_buffer_strength"] = "STRONG"
    out = svc._validate_and_govern(obj, svc.governed_sector({"l3":"Software"}))
    f = out["factors"][0]
    assert f["buffer_credit_points"] == 2
    assert f["buffer_adjustment"] == -2
    assert f["net_reference_score"] == 2


def test_model_cannot_rename_governed_factor():
    obj = sample_model_output(); obj["factors"][0]["name"] = "Made Up Factor"
    try:
        svc._validate_and_govern(obj, svc.governed_sector({"l3":"Software"}))
        assert False, "expected failure"
    except svc.Step24ModelError:
        pass


def test_missing_sector_fails_instead_of_inventing_taxonomy():
    try:
        svc.governed_sector({"l3":"Unknown Sector"})
        assert False, "expected failure"
    except svc.Step24DataError as exc:
        assert "No approved Step 2.4 factor rows" in str(exc)


def test_generate_does_not_need_event_or_scenario(monkeypatch):
    payload = sample_model_output()
    monkeypatch.setattr(svc, "_gateway_call", lambda *a, **k: json.dumps(payload))
    out = svc.generate({"l3":"Software"})
    assert out["sector"]["l3"] == "Software"
    assert out["weights_sum_pct"] == 100.0
    assert "confirmed_step1" not in json.dumps(out).lower()
