"""Additive Step 2.4 sector-inherent factor service.

Design contract:
- Step 2.2 owns the confirmed sector universe.
- Step 2.3 is event/scenario-driven and is NOT an input here.
- Step 2.4 uses only the confirmed L3 sector + a governed factor master.
- Opus proposes methodology; deterministic Python validates and calculates arithmetic.
- Sonnet 5 is reserved for targeted analyst revision / structural repair.
- No public-web, mock, or demo runtime fallback.
"""
from __future__ import annotations

import csv
import json
import os
import re
import threading
from copy import deepcopy
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Sequence

try:
    from rpr_model_trace import model_span
except Exception:  # pragma: no cover - tracing is optional for unit tests only
    from contextlib import contextmanager

    @contextmanager
    def model_span(**_: Any):
        class _Trace:
            output_chars = 0
        yield _Trace()

BASE_DIR = Path(__file__).resolve().parent
DATA_PATH = Path(os.environ.get("STEP24_FACTOR_MASTER", BASE_DIR / "data" / "step24" / "sector_inherent_factors.csv"))
PROMPT_PATH = BASE_DIR / "prompts" / "step24_sector_inherent_v5_2.txt"
REVISION_PROMPT_PATH = BASE_DIR / "prompts" / "step24_sector_inherent_revision.txt"

_REASONING_MODEL = (os.environ.get("STEP24_REASONING_MODEL") or os.environ.get("STEP2_OPUS_MODEL") or "").strip()
_REVISION_MODEL = (os.environ.get("STEP24_REVISION_MODEL") or os.environ.get("STEP2_SONNET_MODEL") or "").strip()
_REPAIR_MODEL = (os.environ.get("STEP24_REPAIR_MODEL") or _REVISION_MODEL).strip()
_REASONING_TIMEOUT = int(os.environ.get("STEP24_REASONING_TIMEOUT", "240"))
_REVISION_TIMEOUT = int(os.environ.get("STEP24_REVISION_TIMEOUT", "180"))
_MAX_TOKENS = int(os.environ.get("STEP24_MAX_TOKENS", "16000"))

IMPORTANCE_SCORE = {"HIGH": 2, "MEDIUM": 1}
BUFFER_REDUCTION = {"STRONG": 2, "MODERATE": 1, "WEAK": 0, "NEGLIGIBLE": 0}
VULN_BANDS = ("VERY_HIGH", "HIGH", "MODERATE", "LOW")
BUFFER_BANDS = ("STRONG", "MODERATE", "WEAK", "NEGLIGIBLE")
VULN_DIR = {"HIGHER_WORSE", "LOWER_WORSE"}
BUFFER_DIR = {"HIGHER_STRONGER", "LOWER_STRONGER"}

class Step24DataError(ValueError):
    pass

class Step24ModelError(RuntimeError):
    pass


def _text(value: Any) -> str:
    return str(value or "").strip()


def _read(path: Path) -> str:
    if not path.exists():
        raise Step24DataError(f"Required Step 2.4 file is missing: {path.name}")
    return path.read_text(encoding="utf-8").strip()


def _norm(value: Any) -> str:
    return re.sub(r"\s+", " ", _text(value)).casefold()


def _strip_json_fence(text: str) -> str:
    value = _text(text)
    value = re.sub(r"^```(?:json)?\s*", "", value, flags=re.I)
    value = re.sub(r"\s*```$", "", value)
    return value.strip()


def _parse_json(text: str) -> Dict[str, Any]:
    value = _strip_json_fence(text)
    try:
        obj = json.loads(value)
    except json.JSONDecodeError:
        start = value.find("{")
        end = value.rfind("}")
        if start < 0 or end <= start:
            raise Step24ModelError("Step 2.4 model returned no JSON object")
        try:
            obj = json.loads(value[start : end + 1])
        except json.JSONDecodeError as exc:
            raise Step24ModelError(f"Step 2.4 model returned invalid JSON: {exc}") from exc
    if not isinstance(obj, dict):
        raise Step24ModelError("Step 2.4 model output must be a JSON object")
    return obj


def _gateway_call(model: str, system_prompt: str, user_prompt: str, timeout: int, role: str) -> str:
    if not model:
        raise Step24ModelError(
            f"No approved model configured for {role}. Set STEP24_* or reuse the existing STEP2_OPUS_MODEL/STEP2_SONNET_MODEL."
        )
    result: Dict[str, str] = {}
    error: Dict[str, BaseException] = {}

    def runner() -> None:
        try:
            from llm_gateway import get_gateway  # local approved gateway
            gateway = get_gateway()
            if gateway.__class__.__name__.lower().startswith("mock"):
                raise Step24ModelError("Step 2.4 refuses MockLLMGateway in runtime.")
            if not hasattr(gateway, "call_text"):
                raise Step24ModelError("Approved R2D2 gateway does not expose call_text().")
            if hasattr(gateway, "_model"):
                gateway._model = model
            result["text"] = str(
                gateway.call_text(system_prompt=system_prompt, user_prompt=user_prompt, max_tokens=_MAX_TOKENS) or ""
            )
        except BaseException as exc:  # noqa: BLE001
            error["exc"] = exc

    with model_span(provider="r2d2", model=model, role=role, scope="step2.4") as trace:
        thread = threading.Thread(target=runner, daemon=True)
        thread.start()
        thread.join(timeout)
        if thread.is_alive():
            raise Step24ModelError(f"{role} exceeded {timeout}s")
        if "exc" in error:
            raise Step24ModelError(str(error["exc"])) from error["exc"]
        text = _text(result.get("text"))
        trace.output_chars = len(text)
    if not text:
        raise Step24ModelError(f"{role} returned an empty response")
    return text


def _repair_json(raw: str, error_message: str) -> Dict[str, Any]:
    if not _REPAIR_MODEL:
        raise Step24ModelError(error_message)
    system = (
        "Repair ONLY the JSON structure for an RPR Step 2.4 response. Preserve substantive content, factor names, "
        "metric thresholds, and meanings. Return JSON only. Do not introduce new factors."
    )
    user = f"VALIDATION ERROR:\n{error_message}\n\nRAW OUTPUT:\n{raw}"
    repaired = _gateway_call(_REPAIR_MODEL, system, user, _REVISION_TIMEOUT, "step24_structural_repair")
    return _parse_json(repaired)


def _source_rows() -> List[Dict[str, str]]:
    if not DATA_PATH.exists():
        raise Step24DataError(f"Step 2.4 governed factor master not found: {DATA_PATH}")
    with DATA_PATH.open("r", encoding="utf-8-sig", newline="") as fh:
        rows = [dict(r) for r in csv.DictReader(fh)]
    required = {"sector_l1", "sector_l2", "sector_l3", "factor_order", "risk_factor_name", "risk_factor_details"}
    if not rows:
        raise Step24DataError("Step 2.4 factor master is empty")
    if not required.issubset(rows[0].keys()):
        raise Step24DataError(f"Step 2.4 factor master missing columns: {sorted(required - set(rows[0].keys()))}")
    return rows


def catalog() -> Dict[str, Any]:
    rows = _source_rows()
    sectors: Dict[str, Dict[str, Any]] = {}
    for row in rows:
        key = _norm(row["sector_l3"])
        sec = sectors.setdefault(key, {
            "l1": _text(row["sector_l1"]), "l2": _text(row["sector_l2"]), "l3": _text(row["sector_l3"]),
            "factor_count": 0, "version": _text(row.get("version")) or "unversioned"
        })
        sec["factor_count"] += 1
    return {"sectors": list(sectors.values()), "source": DATA_PATH.name}


def governed_sector(sector: Mapping[str, Any] | str) -> Dict[str, Any]:
    if isinstance(sector, str):
        wanted_l3, wanted_l2, wanted_l1 = _norm(sector), "", ""
    else:
        wanted_l3 = _norm(sector.get("l3") or sector.get("name") or sector.get("sector_label"))
        wanted_l2 = _norm(sector.get("l2"))
        wanted_l1 = _norm(sector.get("l1"))
    if not wanted_l3:
        raise Step24DataError("Step 2.4 requires a confirmed L3 sector")

    matches = []
    for row in _source_rows():
        if _norm(row["sector_l3"]) != wanted_l3:
            continue
        if wanted_l2 and _norm(row["sector_l2"]) != wanted_l2:
            continue
        if wanted_l1 and _norm(row["sector_l1"]) != wanted_l1:
            continue
        matches.append(row)
    if not matches:
        raise Step24DataError(
            f"No approved Step 2.4 factor rows exist for L3 sector '{_text(sector if isinstance(sector, str) else sector.get('l3') or sector.get('name'))}'. "
            "Add the sector to backend/data/step24/sector_inherent_factors.csv; no LLM fallback is allowed to invent the governed taxonomy."
        )
    matches.sort(key=lambda r: int(_text(r.get("factor_order")) or "999"))
    return {
        "l1": _text(matches[0]["sector_l1"]),
        "l2": _text(matches[0]["sector_l2"]),
        "l3": _text(matches[0]["sector_l3"]),
        "version": _text(matches[0].get("version")) or "unversioned",
        "factors": [
            {
                "factor_order": int(_text(r.get("factor_order")) or i + 1),
                "name": _text(r["risk_factor_name"]),
                "details": _text(r["risk_factor_details"]),
            }
            for i, r in enumerate(matches)
        ],
    }


def _metric(metric: Mapping[str, Any], bands: Sequence[str], directions: set[str], label: str) -> Dict[str, Any]:
    out = {
        "metric": _text(metric.get("metric")),
        "source": _text(metric.get("source")),
        "formula": _text(metric.get("formula")),
        "direction": _text(metric.get("direction")).upper(),
        "bands": {b: _text((metric.get("bands") or {}).get(b)) for b in bands},
    }
    if not out["metric"] or not out["formula"]:
        raise Step24ModelError(f"{label} metric name/formula is missing")
    if out["direction"] not in directions:
        raise Step24ModelError(f"{label} metric '{out['metric']}' has invalid direction")
    if any(not out["bands"][b] for b in bands):
        raise Step24ModelError(f"{label} metric '{out['metric']}' is missing threshold bands")
    return out


def _scoring(rows: Iterable[Mapping[str, Any]]) -> List[Dict[str, Any]]:
    by_score = {}
    for row in rows or []:
        try:
            score = int(row.get("score"))
        except Exception:
            continue
        if score in {1, 2, 3, 4, 5}:
            by_score[score] = {
                "score": score,
                "vulnerability_profile": _text(row.get("vulnerability_profile")),
                "buffer_profile": _text(row.get("buffer_profile")),
            }
    if set(by_score) != {1, 2, 3, 4, 5}:
        raise Step24ModelError("Each Step 2.4 factor must contain exactly scoring rows 5,4,3,2,1")
    if any(not by_score[s]["vulnerability_profile"] or not by_score[s]["buffer_profile"] for s in by_score):
        raise Step24ModelError("Step 2.4 scoring rows require both vulnerability and buffer profiles")
    return [by_score[s] for s in (5, 4, 3, 2, 1)]


def _validate_and_govern(obj: Mapping[str, Any], governed: Mapping[str, Any]) -> Dict[str, Any]:
    raw_factors = obj.get("factors")
    if not isinstance(raw_factors, list):
        raise Step24ModelError("Step 2.4 output must contain factors[]")
    gf = list(governed["factors"])
    if len(raw_factors) != len(gf):
        raise Step24ModelError(f"Model returned {len(raw_factors)} factors; governed master requires {len(gf)}")

    # Match by order/name but restore names/details from governed data no matter what model emitted.
    raw_by_order = {}
    for idx, factor in enumerate(raw_factors, 1):
        if not isinstance(factor, dict):
            raise Step24ModelError("Each Step 2.4 factor must be an object")
        try:
            order = int(factor.get("factor_order") or idx)
        except Exception:
            order = idx
        raw_by_order[order] = factor

    factors: List[Dict[str, Any]] = []
    for idx, g in enumerate(gf, 1):
        order = int(g["factor_order"])
        f = raw_by_order.get(order)
        if not f:
            raise Step24ModelError(f"Missing governed factor order {order}: {g['name']}")
        emitted_name = _norm(f.get("name"))
        if emitted_name and emitted_name != _norm(g["name"]):
            raise Step24ModelError(f"Model attempted to rename governed factor '{g['name']}'")
        importance = _text(f.get("importance")).upper()
        if importance not in IMPORTANCE_SCORE:
            raise Step24ModelError(f"Factor '{g['name']}' importance must be HIGH or MEDIUM")
        vuln = [_metric(m, VULN_BANDS, VULN_DIR, "Vulnerability") for m in (f.get("vulnerability_metrics") or [])]
        buf = [_metric(m, BUFFER_BANDS, BUFFER_DIR, "Buffer") for m in (f.get("buffer_metrics") or [])]
        if len(vuln) < 3 or len(buf) < 3:
            raise Step24ModelError(f"Factor '{g['name']}' requires at least 3 vulnerability and 3 buffer metrics")
        if len(vuln) != len(buf):
            raise Step24ModelError(f"Factor '{g['name']}' Set 1 and Set 2 metric counts must match")
        critical = [_text(x) for x in ((f.get("critical_threshold") or {}).get("conditions") or []) if _text(x)]
        if len(critical) < 3:
            raise Step24ModelError(f"Factor '{g['name']}' critical threshold must contain at least 3 simultaneous AND conditions")
        try:
            raw_score = int(f.get("reference_raw_score"))
        except Exception as exc:
            raise Step24ModelError(f"Factor '{g['name']}' reference_raw_score must be an integer") from exc
        # No live issuer observations are supplied at Step 2.4, therefore 5 is not permitted as a reference baseline.
        raw_score = max(1, min(4, raw_score))
        strength = _text(f.get("reference_buffer_strength")).upper()
        if strength not in BUFFER_REDUCTION:
            raise Step24ModelError(f"Factor '{g['name']}' has invalid reference_buffer_strength")
        reduction = BUFFER_REDUCTION[strength]
        net = max(1, min(5, raw_score - reduction))
        factors.append({
            "factor_id": f"RF{idx}",
            "factor_order": order,
            "name": g["name"],
            "details": g["details"],
            "rationale": _text(f.get("rationale")),
            "narrative": _text(f.get("rationale")) or g["details"],
            "importance": importance,
            "importance_score": IMPORTANCE_SCORE[importance],
            "importance_justification": _text(f.get("importance_justification")),
            "vulnerability_metrics": vuln,
            "critical_threshold": {"operator": "AND", "conditions": critical},
            "buffer_metrics": buf,
            "key_principle": _text(f.get("key_principle")),
            "scoring": _scoring(f.get("scoring") or []),
            "reference_raw_score": raw_score,
            "reference_buffer_strength": strength,
            "buffer_credit_points": reduction,
            "buffer_adjustment": -reduction,
            "net_reference_score": net,
            "credit_implication": _text(f.get("credit_implication")),
        })

    total_imp = sum(f["importance_score"] for f in factors)
    if total_imp <= 0:
        raise Step24ModelError("Step 2.4 importance total must be positive")
    running = 0.0
    for i, f in enumerate(factors):
        if i == len(factors) - 1:
            weight = round(100.0 - running, 2)
        else:
            weight = round(f["importance_score"] / total_imp * 100.0, 2)
            running += weight
        f["weight_pct"] = weight
    weight_sum = round(sum(f["weight_pct"] for f in factors), 2)
    composite = round(sum((f["weight_pct"] / 100.0) * f["net_reference_score"] for f in factors), 3)
    return {
        "state": "GENERATED",
        "sector": {k: governed[k] for k in ("l1", "l2", "l3", "version")},
        "sector_preamble": _text(obj.get("sector_preamble")),
        "factors": factors,
        "weights_sum_pct": weight_sum,
        "composite_reference_score": composite,
        "scoring_formula": "net=max(1, raw-buffer_credit_points); composite=sum(weight*net)",
        "methodology_note": "Step 2.4 scores are sector-reference methodology values, not observed issuer measurements; issuer scoring belongs downstream.",
    }


def _generation_user_prompt(governed: Mapping[str, Any]) -> str:
    return json.dumps(
        {
            "sector": {k: governed[k] for k in ("l1", "l2", "l3", "version")},
            "governed_risk_factors": governed["factors"],
        },
        ensure_ascii=False,
        indent=2,
    )


def generate(sector: Mapping[str, Any] | str) -> Dict[str, Any]:
    governed = governed_sector(sector)
    system = _read(PROMPT_PATH)
    user = "GOVERNED STEP 2.4 INPUT:\n" + _generation_user_prompt(governed)
    raw = _gateway_call(_REASONING_MODEL, system, user, _REASONING_TIMEOUT, "step24_sector_inherent_reasoning")
    try:
        parsed = _parse_json(raw)
        result = _validate_and_govern(parsed, governed)
    except (Step24ModelError, ValueError) as first_error:
        repaired = _repair_json(raw, str(first_error))
        result = _validate_and_govern(repaired, governed)
        result["repaired"] = True
    result["model_path"] = f"R2D2 {_REASONING_MODEL} sector-inherent reasoning -> deterministic validation/weighting"
    result["models_triggered"] = [{"provider": "r2d2", "model": _REASONING_MODEL, "role": "step24_sector_inherent_reasoning"}]
    return result


def revise(sector: Mapping[str, Any] | str, base_framework: Mapping[str, Any], confirmed_feedback: str) -> Dict[str, Any]:
    governed = governed_sector(sector)
    instruction = _text(confirmed_feedback)
    if not instruction:
        raise Step24DataError("Confirmed Step 2.4 feedback is required")
    if not _REVISION_MODEL:
        raise Step24ModelError("No approved Sonnet 5 model configured for Step 2.4 revision")
    system = _read(REVISION_PROMPT_PATH) + "\n\n" + _read(PROMPT_PATH)
    user = json.dumps(
        {
            "sector": {k: governed[k] for k in ("l1", "l2", "l3", "version")},
            "governed_risk_factors": governed["factors"],
            "base_framework": base_framework,
            "confirmed_analyst_feedback": instruction,
        },
        ensure_ascii=False,
        indent=2,
    )
    raw = _gateway_call(_REVISION_MODEL, system, user, _REVISION_TIMEOUT, "step24_targeted_revision")
    try:
        parsed = _parse_json(raw)
        result = _validate_and_govern(parsed, governed)
    except (Step24ModelError, ValueError) as first_error:
        repaired = _repair_json(raw, str(first_error))
        result = _validate_and_govern(repaired, governed)
        result["repaired"] = True
    result["state"] = "REVISED"
    result["model_path"] = f"R2D2 {_REVISION_MODEL} targeted revision -> deterministic validation/weighting"
    result["models_triggered"] = [{"provider": "r2d2", "model": _REVISION_MODEL, "role": "step24_targeted_revision"}]
    return result


def finalize(sector: Mapping[str, Any] | str, framework: Mapping[str, Any]) -> Dict[str, Any]:
    governed = governed_sector(sector)
    # Framework is already normalized; reconstruct a model-like object for one deterministic validation pass.
    factors = []
    for f in framework.get("factors") or []:
        factors.append({
            "factor_order": f.get("factor_order"),
            "name": f.get("name"),
            "rationale": f.get("rationale") or f.get("narrative"),
            "importance": f.get("importance"),
            "importance_justification": f.get("importance_justification"),
            "vulnerability_metrics": f.get("vulnerability_metrics"),
            "critical_threshold": f.get("critical_threshold"),
            "buffer_metrics": f.get("buffer_metrics"),
            "key_principle": f.get("key_principle"),
            "scoring": f.get("scoring"),
            "reference_raw_score": f.get("reference_raw_score"),
            "reference_buffer_strength": f.get("reference_buffer_strength"),
            "credit_implication": f.get("credit_implication"),
        })
    out = _validate_and_govern({"sector_preamble": framework.get("sector_preamble"), "factors": factors}, governed)
    out["state"] = "CONFIRMED"
    out["model_path"] = "deterministic Step 2.4 finalization"
    out["models_triggered"] = []
    return out
