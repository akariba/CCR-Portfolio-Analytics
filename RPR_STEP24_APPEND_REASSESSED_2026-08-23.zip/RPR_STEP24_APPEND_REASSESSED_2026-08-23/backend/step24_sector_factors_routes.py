"""Additive FastAPI routes for RPR Step 2.4."""
from __future__ import annotations

from typing import Any, Dict
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from step24_sector_factors_service import (
    Step24DataError,
    Step24ModelError,
    catalog,
    finalize,
    generate,
    governed_sector,
    revise,
)

router = APIRouter(prefix="/api/v1/rpr/step24/sector-factors", tags=["RPR Step 2.4 Sector-Inherent Risk Factors"])

class SectorRef(BaseModel):
    id: str = ""
    l1: str = ""
    l2: str = ""
    l3: str = ""
    name: str = ""
    sector_label: str = ""

class GenerateRequest(BaseModel):
    sector: SectorRef
    confirmed_portfolio: Dict[str, Any] = Field(default_factory=dict)  # provenance only; not fed to the model

class ReviseRequest(BaseModel):
    sector: SectorRef
    base_framework: Dict[str, Any]
    confirmed_feedback: str

class FinalizeRequest(BaseModel):
    sector: SectorRef
    framework: Dict[str, Any]


def _handle(func, *args):
    try:
        return func(*args)
    except Step24DataError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except Step24ModelError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc

@router.get("/catalog")
def step24_catalog() -> Dict[str, Any]:
    return _handle(catalog)

@router.post("/resolve")
def step24_resolve(req: GenerateRequest) -> Dict[str, Any]:
    return _handle(governed_sector, req.sector.model_dump())

@router.post("/generate")
def step24_generate(req: GenerateRequest) -> Dict[str, Any]:
    # IMPORTANT: confirmed_portfolio is deliberately NOT passed into the model service.
    # It is accepted so the client can carry provenance and future auth can validate membership.
    return _handle(generate, req.sector.model_dump())

@router.post("/revise")
def step24_revise(req: ReviseRequest) -> Dict[str, Any]:
    return _handle(revise, req.sector.model_dump(), req.base_framework, req.confirmed_feedback)

@router.post("/finalize")
def step24_finalize(req: FinalizeRequest) -> Dict[str, Any]:
    return _handle(finalize, req.sector.model_dump(), req.framework)
