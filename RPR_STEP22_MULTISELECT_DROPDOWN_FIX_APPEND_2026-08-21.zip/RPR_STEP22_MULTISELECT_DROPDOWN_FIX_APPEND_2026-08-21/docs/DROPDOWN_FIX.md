# Step 2.2 dropdown visibility fix

## Root cause
The v31 global `.card` rule uses `overflow:hidden`. Step 2.2 multi-select menus are
`position:absolute` and extend outside the Portfolio Filters card, so the menu was
being rendered but clipped by its parent card.

## Additive fix only
The Step 2.2 Portfolio Filters card receives one additional class:

`ps22-filter-card`

The appended Step 2.2 CSS scopes `overflow:visible` and z-index changes only to this
card and its multi-select controls. No global `.card`, panel, layout, color, typography,
or non-Step-2.2 rules are changed.

## Expected result
Clicking Geography, Country, MLE, or L2 Category now opens the visible checklist menu.
The full catalog options remain available and multi-select remains enabled.
