from __future__ import annotations

import csv
import io
import os
import sys
import types
import unittest
from pathlib import Path
from unittest.mock import patch


BACKEND = Path(__file__).resolve().parents[1]
if str(BACKEND) not in sys.path:
    sys.path.insert(0, str(BACKEND))

os.environ.setdefault("STEP2_SONNET_MODEL", "company-sonnet-5-test-config")

gateway_stub = types.ModuleType("llm_gateway")
gateway_stub.get_gateway = lambda: None
sys.modules.setdefault("llm_gateway", gateway_stub)

import step2_service  # noqa: E402
from step2_uploads import UploadExtractionError, extract_assumption_file  # noqa: E402


STEP1 = {
    "event_overview": "Confirmed event: funding conditions tightened during the observed period.",
    "credit_market_impact": "Credit spreads widened for lower-rated issuers.",
}


def scenario_response():
    return {
        "scenario_narrative": "Funding pressure remains elevated through the selected horizon while stronger borrowers retain market access.",
        "assumptions": [
            {
                "code": f"A{index}",
                "type": "Model support",
                "quantified_or_bounded_value": text,
                "rationale": "Supports the scenario path.",
                "horizon": "12 months",
                "direction": "HEADWIND",
                "origin": "MODEL_GENERATED",
                "source_reference": None,
                "confidence": "MEDIUM",
            }
            for index, text in enumerate(
                (
                    "Market access remains selective.",
                    "Liquidity buffers absorb near-term volatility.",
                    "Margins weaken for highly leveraged borrowers.",
                    "Refinancing calendars remain a key differentiator.",
                ),
                start=1,
            )
        ],
    }


def clear_assessment():
    return {
        "assessment_status": "CLEAR",
        "typed_context": {"status": "USE", "role": "CONTROLLING_SCENARIO_INSTRUCTION", "reason": "Usable."},
        "uploaded_assumption_reviews": [],
        "conflicts": [],
        "curated_legacy_context": [],
        "limitations": [],
    }


class Step21AnalystInputTests(unittest.TestCase):
    def _fake_calls(self, capture):
        def fake(system_prompt, payload, model, max_tokens=5000, role="step2"):
            capture.append({"system_prompt": system_prompt, "payload": payload, "model": model, "role": role})
            if role == "step2_context_assessor":
                return clear_assessment()
            if role == "step2_scenario_generation":
                return scenario_response()
            raise AssertionError(f"Unexpected role: {role}")

        return fake

    def test_no_analyst_context_uses_step1_and_horizon(self):
        calls = []
        with patch.object(step2_service, "_call_json", side_effect=self._fake_calls(calls)):
            result = step2_service.generate_scenario(STEP1, "12 months")
        self.assertEqual([call["role"] for call in calls], ["step2_scenario_generation"])
        self.assertEqual(result["context_assessment"]["overall_decision"], "STEP1_HORIZON_ONLY")
        self.assertEqual(result["assumption_provenance_summary"]["analyst_supplied_count"], 0)
        self.assertTrue(all(item["provenance"] == "Model generated" for item in result["assumptions"]))

    def test_typed_additional_context_is_prioritized_and_preserved(self):
        calls = []
        context = "Assume refinancing spreads widen by 100 bps during the scenario horizon."
        with patch.object(step2_service, "_call_json", side_effect=self._fake_calls(calls)):
            result = step2_service.generate_scenario(STEP1, "12 months", additional_context=context)
        scenario_call = next(call for call in calls if call["role"] == "step2_scenario_generation")
        self.assertTrue(scenario_call["system_prompt"].startswith("PRIORITIZED ANALYST INPUTS"))
        self.assertEqual(scenario_call["payload"]["PRIORITY_2_ANALYST_ADDITIONAL_CONTEXT"], context)
        analyst = [item for item in result["assumptions"] if item["provenance"] == "Analyst supplied"]
        self.assertEqual(len(analyst), 1)
        self.assertEqual(analyst[0]["assumption"], context)

    def test_csv_upload(self):
        content = (
            "assumption,time_horizon,analyst_notes\n"
            "Borrowing costs increase,12 months,Focus on leveraged borrowers\n"
            "Credit demand weakens,,\n"
        ).encode("utf-8")
        result = extract_assumption_file("assumptions.csv", content, "text/csv")
        self.assertEqual(result["processing_status"], "PARSED")
        self.assertEqual(result["assumption_count"], 2)
        self.assertEqual(result["assumptions"][0]["provenance"], "Analyst supplied")

    def test_xlsx_upload(self):
        from openpyxl import Workbook

        workbook = Workbook()
        sheet = workbook.active
        sheet.title = "Assumptions"
        sheet.append(["assumption", "time_horizon", "analyst_notes"])
        sheet.append(["Refinancing spreads widen.", "18 months", "Lower-rated issuers"])
        data = io.BytesIO()
        workbook.save(data)
        workbook.close()
        result = extract_assumption_file(
            "assumptions.xlsx",
            data.getvalue(),
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )
        self.assertEqual(result["assumption_count"], 1)
        self.assertEqual(result["assumptions"][0]["source_sheet"], "Assumptions")

    def test_packaged_example_templates_parse_all_rows(self):
        templates = BACKEND.parent / "templates"
        csv_result = extract_assumption_file(
            "step2_assumptions_example.csv",
            (templates / "step2_assumptions_example.csv").read_bytes(),
            "text/csv",
        )
        xlsx_result = extract_assumption_file(
            "step2_assumptions_example.xlsx",
            (templates / "step2_assumptions_example.xlsx").read_bytes(),
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )
        self.assertEqual(csv_result["assumption_count"], 5)
        self.assertEqual(xlsx_result["assumption_count"], 5)

    def test_typed_context_plus_uploaded_assumptions(self):
        calls = []
        uploaded = [
            {
                "input_id": "upload-1",
                "assumption": "Borrowing costs increase for leveraged borrowers.",
                "time_horizon": "12 months",
                "analyst_notes": "",
                "source_reference": "assumptions.csv / row 2",
            }
        ]
        with patch.object(step2_service, "_call_json", side_effect=self._fake_calls(calls)):
            result = step2_service.generate_scenario(
                STEP1,
                "12 months",
                additional_context="Assume policy rates rise by 50 basis points.",
                uploaded_assumptions=uploaded,
            )
        self.assertEqual(result["assumption_provenance_summary"]["analyst_supplied_count"], 2)
        analyst_text = [item["assumption"] for item in result["assumptions"] if item["provenance"] == "Analyst supplied"]
        self.assertIn(uploaded[0]["assumption"], analyst_text)

    def test_invalid_file_is_rejected(self):
        with self.assertRaisesRegex(UploadExtractionError, "Upload .csv or .xlsx"):
            extract_assumption_file("assumptions.pdf", b"not a workbook", "application/pdf")
        malformed = b"time_horizon,analyst_notes\n12 months,missing required column\n"
        with self.assertRaisesRegex(UploadExtractionError, "required column 'assumption'"):
            extract_assumption_file("assumptions.csv", malformed, "text/csv")

    def test_conflict_requires_warning_then_explicit_override(self):
        calls = []

        def fake(system_prompt, payload, model, max_tokens=5000, role="step2"):
            calls.append(role)
            if role == "step2_context_assessor":
                return {
                    **clear_assessment(),
                    "assessment_status": "CONFLICTS_FOUND",
                    "conflicts": [
                        {
                            "conflict_id": "conflict-current-rate",
                            "input_id": "manual-additional-context",
                            "optional_source": "Additional Context",
                            "optional_statement": "The current policy rate is 9%.",
                            "step1_anchor": "Step 1 confirms a different current rate.",
                            "warning": "The analyst statement conflicts with a confirmed current fact.",
                            "treatment": "REQUIRES_EXPLICIT_OVERRIDE",
                        }
                    ],
                }
            if role == "step2_scenario_generation":
                return scenario_response()
            raise AssertionError(role)

        context = "The current policy rate is 9%."
        with patch.object(step2_service, "_call_json", side_effect=fake):
            warning = step2_service.generate_scenario(STEP1, "12 months", additional_context=context)
            self.assertEqual(warning["status"], "VALIDATION_WARNING")
            self.assertFalse(warning["scenario_generated"])
            generated = step2_service.generate_scenario(
                STEP1,
                "12 months",
                additional_context=context,
                accepted_conflict_overrides=["conflict-current-rate"],
            )
        self.assertEqual(generated["status"], "GENERATED")
        self.assertEqual(calls.count("step2_scenario_generation"), 1)

    def test_provenance_labels_are_exact(self):
        calls = []
        with patch.object(step2_service, "_call_json", side_effect=self._fake_calls(calls)):
            result = step2_service.generate_scenario(
                STEP1,
                "12 months",
                additional_context="Assume demand weakens.",
            )
        labels = {item["provenance"] for item in result["assumptions"]}
        self.assertEqual(labels, {"Analyst supplied", "Model generated"})


if __name__ == "__main__":
    unittest.main(verbosity=2)
