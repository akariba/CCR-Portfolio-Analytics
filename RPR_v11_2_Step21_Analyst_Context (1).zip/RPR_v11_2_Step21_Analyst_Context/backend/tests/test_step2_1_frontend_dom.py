from __future__ import annotations

import unittest
from html.parser import HTMLParser
from pathlib import Path


HTML_PATH = Path(__file__).resolve().parents[2] / "frontend" / "rpr-v8-consolidated-test.html"


class DomCollector(HTMLParser):
    def __init__(self):
        super().__init__()
        self.ids = set()
        self.attributes = {}

    def handle_starttag(self, tag, attrs):
        attr_map = dict(attrs)
        element_id = attr_map.get("id")
        if element_id:
            self.ids.add(element_id)
            self.attributes[element_id] = attr_map


class Step21FrontendDomTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.html = HTML_PATH.read_text(encoding="utf-8")
        cls.dom = DomCollector()
        cls.dom.feed(cls.html)

    def test_required_step21_controls_exist(self):
        required = {
            "additional-context-ta",
            "assumption-file-input",
            "assumption-review-list",
            "generate-scenario-btn",
            "step21-context-note",
            "assumption-rows",
        }
        self.assertTrue(required.issubset(self.dom.ids))

    def test_upload_accepts_only_csv_and_xlsx(self):
        self.assertEqual(self.dom.attributes["assumption-file-input"].get("accept"), ".csv,.xlsx")

    def test_review_remove_warning_and_provenance_wiring(self):
        for marker in (
            "removeUploadedAssumption",
            "/api/v1/rpr/step2/assumptions/extract",
            "Override and generate",
            "Analyst supplied",
            "Model generated",
            "step2_assumptions_blank.xlsx",
            "step2_assumptions_example.xlsx",
        ):
            self.assertIn(marker, self.html)


if __name__ == "__main__":
    unittest.main(verbosity=2)
