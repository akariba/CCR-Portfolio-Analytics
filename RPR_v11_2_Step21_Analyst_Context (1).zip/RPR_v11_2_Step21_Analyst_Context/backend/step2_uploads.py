"""Safe, bounded extraction for Step-2.1 optional scenario-context uploads."""
from __future__ import annotations

import csv
import hashlib
import io
import logging
from pathlib import Path
from typing import Any, Dict, List

MAX_BYTES = 20 * 1024 * 1024
MAX_EXTRACTED_CHARS = 40000
ALLOWED_EXTENSIONS = {".pdf", ".doc", ".docx", ".txt", ".csv", ".xlsx"}
ASSUMPTION_MAX_BYTES = 5 * 1024 * 1024
ASSUMPTION_MAX_ROWS = 500
ASSUMPTION_EXTENSIONS = {".csv", ".xlsx"}
ASSUMPTION_COLUMNS = ("assumption", "time_horizon", "analyst_notes")

log = logging.getLogger("uvicorn.error")


class UploadExtractionError(ValueError):
    pass


def _cell_text(value: Any) -> str:
    if value is None:
        return ""
    return str(value).replace("\x00", "").strip()


def _normalize_header(value: Any) -> str:
    return "_".join(_cell_text(value).lower().split())


def _parse_assumption_rows(
    rows: List[List[Any]], *, file_name: str, sheet_name: str = ""
) -> List[Dict[str, Any]]:
    first_nonblank = next(
        (index for index, row in enumerate(rows) if any(_cell_text(value) for value in row)),
        None,
    )
    if first_nonblank is None:
        return []

    raw_headers = rows[first_nonblank]
    headers = [_normalize_header(value) for value in raw_headers]
    while headers and not headers[-1]:
        headers.pop()
    if not headers:
        return []
    if any(not header for header in headers):
        raise UploadExtractionError(
            f"{file_name}: the header row contains a blank column between populated columns."
        )
    if len(headers) != len(set(headers)):
        raise UploadExtractionError(f"{file_name}: duplicate column names are not allowed.")
    unsupported = [header for header in headers if header not in ASSUMPTION_COLUMNS]
    if unsupported:
        raise UploadExtractionError(
            f"{file_name}: unsupported column(s): {', '.join(unsupported)}. "
            "Allowed columns are assumption, time_horizon, analyst_notes."
        )
    if "assumption" not in headers:
        raise UploadExtractionError(
            f"{file_name}: required column 'assumption' is missing."
        )

    parsed: List[Dict[str, Any]] = []
    for row_index, raw_row in enumerate(rows[first_nonblank + 1 :], start=first_nonblank + 2):
        row = list(raw_row[: len(headers)])
        if len(row) < len(headers):
            row.extend([""] * (len(headers) - len(row)))
        values = {header: _cell_text(row[index]) for index, header in enumerate(headers)}
        if not any(values.values()):
            continue
        if not values.get("assumption"):
            location = f" sheet '{sheet_name}'," if sheet_name else ""
            raise UploadExtractionError(
                f"{file_name}:{location} row {row_index} is nonblank but has no assumption."
            )
        source_reference = f"{file_name}"
        if sheet_name:
            source_reference += f" / {sheet_name}"
        source_reference += f" / row {row_index}"
        parsed.append(
            {
                "input_id": "",
                "assumption": values["assumption"],
                "time_horizon": values.get("time_horizon", ""),
                "analyst_notes": values.get("analyst_notes", ""),
                "source_name": file_name,
                "source_reference": source_reference,
                "source_row": row_index,
                "source_sheet": sheet_name or None,
                "provenance": "Analyst supplied",
            }
        )
        if len(parsed) > ASSUMPTION_MAX_ROWS:
            raise UploadExtractionError(
                f"{file_name}: more than {ASSUMPTION_MAX_ROWS} assumptions were supplied."
            )
    return parsed


def _assumption_csv_rows(data: bytes, file_name: str) -> List[List[Any]]:
    text, _ = _extract_txt(data)
    try:
        return [list(row) for row in csv.reader(io.StringIO(text))]
    except csv.Error as exc:
        raise UploadExtractionError(f"{file_name}: malformed CSV: {exc}") from exc


def _assumption_xlsx_rows(data: bytes, file_name: str) -> List[Dict[str, Any]]:
    try:
        from openpyxl import load_workbook
    except Exception as exc:
        raise UploadExtractionError("openpyxl is required for XLSX assumption uploads.") from exc
    try:
        workbook = load_workbook(io.BytesIO(data), read_only=True, data_only=False)
    except Exception as exc:
        raise UploadExtractionError(f"{file_name}: malformed XLSX workbook.") from exc
    sheets: List[Dict[str, Any]] = []
    try:
        for worksheet in workbook.worksheets:
            rows = [list(row) for row in worksheet.iter_rows(values_only=True)]
            if any(any(_cell_text(value) for value in row) for row in rows):
                sheets.append({"name": worksheet.title, "rows": rows})
    finally:
        workbook.close()
    return sheets


def extract_assumption_file(file_name: str, data: bytes, content_type: str = "") -> Dict[str, Any]:
    """Parse a governed analyst assumption file without dropping populated rows."""
    name = Path(file_name or "upload").name
    extension = Path(name).suffix.lower()
    if extension not in ASSUMPTION_EXTENSIONS:
        raise UploadExtractionError(
            f"Unsupported assumption file type: {extension or 'no extension'}. Upload .csv or .xlsx."
        )
    if not data:
        raise UploadExtractionError("Uploaded assumption file is empty.")
    if len(data) > ASSUMPTION_MAX_BYTES:
        raise UploadExtractionError("Uploaded assumption file exceeds the 5 MB limit.")

    assumptions: List[Dict[str, Any]] = []
    if extension == ".csv":
        assumptions = _parse_assumption_rows(
            _assumption_csv_rows(data, name), file_name=name
        )
    else:
        for sheet in _assumption_xlsx_rows(data, name):
            assumptions.extend(
                _parse_assumption_rows(
                    sheet["rows"], file_name=name, sheet_name=sheet["name"]
                )
            )

    if not assumptions:
        raise UploadExtractionError(
            f"{name}: no analyst assumptions were found below the header row."
        )
    if len(assumptions) > ASSUMPTION_MAX_ROWS:
        raise UploadExtractionError(
            f"{name}: more than {ASSUMPTION_MAX_ROWS} assumptions were supplied."
        )

    digest = hashlib.sha256(data).hexdigest()
    for index, assumption in enumerate(assumptions, start=1):
        assumption["input_id"] = f"upload-{digest[:12]}-{index}"

    log.info(
        "[STEP2.1] assumption_upload status=SUCCESS file_type=%s size_bytes=%s assumption_count=%s",
        extension.lstrip("."),
        len(data),
        len(assumptions),
    )
    return {
        "file_name": name,
        "file_type": extension.lstrip("."),
        "content_type": content_type or "",
        "size_bytes": len(data),
        "sha256": digest,
        "processing_status": "PARSED",
        "assumption_count": len(assumptions),
        "assumptions": assumptions,
        "warnings": [],
    }


def _bounded(text: str):
    text = (text or "").replace("\x00", "").strip()
    warnings: List[str] = []
    if len(text) > MAX_EXTRACTED_CHARS:
        text = text[:MAX_EXTRACTED_CHARS]
        warnings.append(f"Extracted text truncated to {MAX_EXTRACTED_CHARS} characters.")
    return text, warnings


def _extract_txt(data: bytes):
    for encoding in ("utf-8-sig", "utf-8", "cp1252"):
        try:
            return data.decode(encoding), []
        except UnicodeDecodeError:
            continue
    raise UploadExtractionError("TXT encoding could not be decoded.")


def _extract_csv(data: bytes):
    text, _ = _extract_txt(data)
    rows = []
    for i, row in enumerate(csv.reader(io.StringIO(text))):
        if i >= 250:
            break
        rows.append(" | ".join(str(x) for x in row[:30]))
    return "\n".join(rows), [{"type": "rows", "start": 1, "end": len(rows)}]


def _extract_docx(data: bytes):
    try:
        from docx import Document
    except Exception as exc:
        raise UploadExtractionError("python-docx is required for DOCX extraction.") from exc
    doc = Document(io.BytesIO(data))
    parts = [p.text for p in doc.paragraphs if p.text.strip()]
    for ti, table in enumerate(doc.tables[:30], start=1):
        parts.append(f"[TABLE {ti}]")
        for row in table.rows[:100]:
            parts.append(" | ".join(cell.text.strip() for cell in row.cells))
    return "\n".join(parts), [{"type": "document", "paragraphs": len(doc.paragraphs), "tables": len(doc.tables)}]


def _extract_pdf(data: bytes):
    try:
        from pypdf import PdfReader
    except Exception as exc:
        raise UploadExtractionError("pypdf is required for PDF extraction.") from exc
    reader = PdfReader(io.BytesIO(data))
    parts, refs = [], []
    for i, page in enumerate(reader.pages[:80], start=1):
        text = (page.extract_text() or "").strip()
        if text:
            parts.append(f"[PAGE {i}]\n{text}")
            refs.append({"type": "page", "page": i})
    return "\n".join(parts), refs


def _extract_xlsx(data: bytes):
    try:
        from openpyxl import load_workbook
    except Exception as exc:
        raise UploadExtractionError("openpyxl is required for XLSX extraction.") from exc
    wb = load_workbook(io.BytesIO(data), read_only=True, data_only=True)
    parts, refs = [], []
    for ws in wb.worksheets[:15]:
        parts.append(f"[SHEET {ws.title}]")
        row_count = 0
        for row in ws.iter_rows(values_only=True):
            row_count += 1
            if row_count > 250:
                break
            parts.append(" | ".join("" if v is None else str(v) for v in row[:30]))
        refs.append({"type": "sheet", "sheet": ws.title, "rows_extracted": row_count})
    return "\n".join(parts), refs


def extract_context_file(file_name: str, data: bytes, content_type: str = "") -> Dict[str, Any]:
    name = Path(file_name or "upload").name
    ext = Path(name).suffix.lower()
    if ext not in ALLOWED_EXTENSIONS:
        raise UploadExtractionError(f"Unsupported file type: {ext or 'no extension'}")
    if not data:
        raise UploadExtractionError("Uploaded file is empty.")
    if len(data) > MAX_BYTES:
        raise UploadExtractionError("Uploaded file exceeds the 20 MB Step-2.1 limit.")

    if ext == ".txt":
        text, refs = _extract_txt(data)
    elif ext == ".csv":
        text, refs = _extract_csv(data)
    elif ext == ".docx":
        text, refs = _extract_docx(data)
    elif ext == ".pdf":
        text, refs = _extract_pdf(data)
    elif ext == ".xlsx":
        text, refs = _extract_xlsx(data)
    elif ext == ".doc":
        raise UploadExtractionError("Legacy .doc extraction is not supported by this test package. Convert to DOCX or PDF.")
    else:
        raise UploadExtractionError(f"Unsupported file type: {ext}")

    text, warnings = _bounded(text)
    if not text:
        raise UploadExtractionError("No usable text could be extracted from the uploaded file.")
    return {
        "file_name": name,
        "file_type": ext.lstrip("."),
        "content_type": content_type or "",
        "size_bytes": len(data),
        "sha256": hashlib.sha256(data).hexdigest(),
        "extraction_status": "SUCCESS",
        "extracted_text": text,
        "page_or_sheet_refs": refs,
        "warnings": warnings,
    }
