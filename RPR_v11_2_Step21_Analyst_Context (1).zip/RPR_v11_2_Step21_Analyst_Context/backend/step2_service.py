"""Governed Step 2.1 / Step 2.3 service for RPR.

Additive by design: this module does not replace the current RPRService until live tests pass.
"""
from __future__ import annotations

import json
import hashlib
import logging
import os
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

from llm_gateway import get_gateway

PROMPT_DIR = Path(__file__).resolve().parent / "prompts"
MODEL_SONNET = os.environ.get("STEP2_SONNET_MODEL", "").strip()
MODEL_OPUS = os.environ.get("STEP2_OPUS_MODEL", "claude-opus-4-6")
_ASSUMPTION_DIRECTIONS = {"HEADWIND", "TAILWIND", "MIXED", "NEUTRAL"}
_IMPORTANCE_SCORE = {"HIGH": 2, "MEDIUM": 1}

log = logging.getLogger("uvicorn.error")


class Step2Error(RuntimeError):
    pass


def _load_prompt(name: str) -> str:
    path = PROMPT_DIR / name
    if not path.exists():
        raise Step2Error(f"Required Step-2 prompt is missing: {path}")
    text = path.read_text(encoding="utf-8").strip()
    if not text:
        raise Step2Error(f"Required Step-2 prompt is empty: {path}")
    return text


def _gateway_for_model(model: str):
    if not str(model or "").strip():
        raise Step2Error(
            "STEP2_SONNET_MODEL must be set to the exact organization-approved Sonnet 5 identifier."
        )
    gw = get_gateway()
    # Current R2D2LLMGateway stores model on the instance. Instance-level routing avoids
    # mutating process-wide R2D2_MODEL and therefore avoids cross-request model races.
    if hasattr(gw, "_model"):
        gw._model = model
    return gw


def _call_json(
    system_prompt: str,
    user_payload: Dict[str, Any],
    model: str,
    max_tokens: int = 5000,
    role: str = "step2",
) -> Dict[str, Any]:
    gw = _gateway_for_model(model)
    if not hasattr(gw, "call_raw"):
        raise Step2Error("Prompt-oriented Step-2 calls require the R2D2 gateway.")
    started = time.monotonic()
    log.info("[STEP2.1] model_call status=STARTED role=%s model=%s", role, model)
    try:
        result = gw.call_raw(
            system_prompt,
            json.dumps(user_payload, ensure_ascii=False, indent=2),
            max_tokens=max_tokens,
        )
    except Exception as exc:
        log.error(
            "[STEP2.1] model_call status=FAILED role=%s model=%s duration_ms=%s error_type=%s",
            role,
            model,
            int((time.monotonic() - started) * 1000),
            type(exc).__name__,
        )
        raise
    log.info(
        "[STEP2.1] model_call status=SUCCESS role=%s model=%s duration_ms=%s",
        role,
        model,
        int((time.monotonic() - started) * 1000),
    )
    if not isinstance(result, dict):
        raise Step2Error("Step-2 model response must be a JSON object.")
    return result


def _compact_step1(step1: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(step1, dict) or not step1:
        raise Step2Error("Confirmed Step-1 payload is required.")
    keep: Dict[str, Any] = {}
    keys = (
        "event_overview", "event_history", "direct_impact_geographies",
        "contagion_impact_geographies", "contagious_impact_geographies",
        "equity_market_impact", "credit_market_impact", "commodity_market_impact",
        "assumptions", "scenario_label", "event_summary", "history", "direct_impact",
        "contagion_impact", "equity_impact", "credit_impact", "commodity_impact",
        "machine_payload", "analyst_state", "trigger", "theme", "event",
    )
    for key in keys:
        if key in step1:
            keep[key] = step1[key]
    return keep or dict(step1)


def _clean_uploads(uploaded_contexts: Optional[List[Dict[str, Any]]]) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    for item in uploaded_contexts or []:
        if not isinstance(item, dict):
            continue
        text = str(item.get("extracted_text") or item.get("text") or "").strip()
        status = str(item.get("extraction_status") or "SUCCESS").upper()
        if status != "SUCCESS" or not text:
            continue
        out.append({
            "file_name": str(item.get("file_name") or "uploaded_context"),
            "file_type": str(item.get("file_type") or ""),
            "size_bytes": item.get("size_bytes"),
            "sha256": item.get("sha256"),
            "extracted_text": text[:16000],
            "page_or_sheet_refs": item.get("page_or_sheet_refs") or [],
            "warnings": item.get("warnings") or [],
        })
    return out


def _combined_additional_context(additional_context: str, typed_context: str) -> str:
    current = str(additional_context or "").strip()
    legacy = str(typed_context or "").strip()
    if current and legacy and current != legacy:
        return f"{current}\n\n{legacy}"
    return current or legacy


def _clean_uploaded_assumptions(
    uploaded_assumptions: Optional[List[Dict[str, Any]]],
) -> List[Dict[str, Any]]:
    flattened: List[Dict[str, Any]] = []
    for outer_index, item in enumerate(uploaded_assumptions or [], start=1):
        if not isinstance(item, dict):
            raise Step2Error(f"Uploaded assumption item {outer_index} is not an object.")
        children = item.get("assumptions")
        if children is not None:
            if not isinstance(children, list):
                raise Step2Error(f"Uploaded assumption file {outer_index} has an invalid assumptions list.")
            source_name = str(item.get("file_name") or "uploaded assumptions")
            for child in children:
                if not isinstance(child, dict):
                    raise Step2Error(f"{source_name} contains a malformed assumption row.")
                merged = dict(child)
                merged.setdefault("source_name", source_name)
                flattened.append(merged)
        else:
            flattened.append(dict(item))

    normalized: List[Dict[str, Any]] = []
    seen_ids = set()
    for index, item in enumerate(flattened, start=1):
        text = str(item.get("assumption") or "").strip()
        if not text:
            raise Step2Error(f"Uploaded assumption {index} is missing required field 'assumption'.")
        input_id = str(item.get("input_id") or f"uploaded-assumption-{index}").strip()
        if input_id in seen_ids:
            input_id = f"{input_id}-{index}"
        seen_ids.add(input_id)
        normalized.append(
            {
                "input_id": input_id,
                "assumption": text,
                "time_horizon": str(item.get("time_horizon") or "").strip(),
                "analyst_notes": str(item.get("analyst_notes") or "").strip(),
                "source_name": str(item.get("source_name") or "uploaded assumptions"),
                "source_reference": str(
                    item.get("source_reference") or item.get("source_name") or "uploaded assumptions"
                ),
                "provenance": "Analyst supplied",
            }
        )
    return normalized


def _analyst_inputs(additional_context: str, assumptions: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    items: List[Dict[str, Any]] = []
    if additional_context:
        items.append(
            {
                "input_id": "manual-additional-context",
                "text": additional_context,
                "origin": "ADDITIONAL_CONTEXT",
                "source_name": "Additional Context",
                "role": "CONTROLLING_SCENARIO_INSTRUCTION",
                "provenance": "Analyst supplied",
            }
        )
    for assumption in assumptions:
        items.append(
            {
                "input_id": assumption["input_id"],
                "text": assumption["assumption"],
                "origin": "UPLOADED_ASSUMPTION",
                "source_name": assumption["source_name"],
                "source_reference": assumption["source_reference"],
                "time_horizon": assumption["time_horizon"],
                "analyst_notes": assumption["analyst_notes"],
                "role": "CONTROLLING_SCENARIO_ASSUMPTION",
                "provenance": "Analyst supplied",
            }
        )
    return items


def _conflict_id(conflict: Dict[str, Any]) -> str:
    existing = str(conflict.get("conflict_id") or "").strip()
    if existing:
        return existing
    material = "|".join(
        str(conflict.get(key) or "")
        for key in ("input_id", "optional_source", "optional_statement", "step1_anchor")
    )
    return "conflict-" + hashlib.sha256(material.encode("utf-8")).hexdigest()[:12]


def assess_optional_context(
    confirmed_step1: Dict[str, Any],
    horizon: str,
    typed_context: str = "",
    uploaded_contexts: Optional[List[Dict[str, Any]]] = None,
    *,
    additional_context: str = "",
    uploaded_assumptions: Optional[List[Dict[str, Any]]] = None,
    accepted_conflict_overrides: Optional[List[str]] = None,
) -> Dict[str, Any]:
    step1 = _compact_step1(confirmed_step1)
    horizon = str(horizon or "").strip()
    if not horizon:
        raise Step2Error("Assessment horizon is required.")

    typed = _combined_additional_context(additional_context, typed_context)
    assumptions = _clean_uploaded_assumptions(uploaded_assumptions)
    legacy_uploads = _clean_uploads(uploaded_contexts)
    analyst_inputs = _analyst_inputs(typed, assumptions)
    accepted_overrides = {str(value).strip() for value in accepted_conflict_overrides or [] if str(value).strip()}

    log.info(
        "[STEP2.1] context_processing status=STARTED additional_context_present=%s uploaded_assumption_count=%s legacy_context_file_count=%s accepted_override_count=%s",
        bool(typed),
        len(assumptions),
        len(legacy_uploads),
        len(accepted_overrides),
    )

    if not analyst_inputs and not legacy_uploads:
        log.info("[STEP2.1] context_processing status=BYPASSED analyst_input_count=0")
        return {
            "overall_decision": "STEP1_HORIZON_ONLY",
            "typed_context": {
                "status": "NOT_PROVIDED",
                "role": None,
                "reason": "No Additional Context provided.",
                "usable_items": [],
                "excluded_items": [],
            },
            "uploaded_contexts": [],
            "uploaded_assumptions": [],
            "conflicts": [],
            "validation_warnings": [],
            "requires_explicit_override": False,
            "accepted_conflict_overrides": [],
            "curated_context": [],
            "limitations": [],
            "assessor_bypassed": True,
        }

    payload = {
        "PRIORITY_1_CONFIRMED_STEP1_AND_ACCEPTED_OVERRIDES": {
            "confirmed_step1": step1,
            "accepted_conflict_override_ids": sorted(accepted_overrides),
        },
        "PRIORITY_2_ANALYST_ADDITIONAL_CONTEXT": typed or None,
        "PRIORITY_3_ANALYST_UPLOADED_ASSUMPTIONS": assumptions,
        "PRIORITY_4_ASSESSMENT_HORIZON": horizon,
        "CONFIRMED_STEP1": step1,
        "ASSESSMENT_HORIZON": horizon,
        "ANALYST_INPUTS": analyst_inputs,
        "LEGACY_UPLOADED_CONTEXTS": legacy_uploads,
    }
    result = _call_json(
        _load_prompt("step2_context_assessor.txt"),
        payload,
        MODEL_SONNET,
        max_tokens=4500,
        role="step2_context_assessor",
    )

    conflicts = result.get("conflicts") or []
    if not isinstance(conflicts, list):
        raise Step2Error("Context assessor returned an invalid conflicts list.")
    normalized_conflicts: List[Dict[str, Any]] = []
    warnings: List[Dict[str, Any]] = []
    for conflict in conflicts:
        if not isinstance(conflict, dict):
            raise Step2Error("Context assessor returned a malformed conflict.")
        item = dict(conflict)
        item["conflict_id"] = _conflict_id(item)
        item["override_accepted"] = item["conflict_id"] in accepted_overrides
        item["can_override"] = True
        normalized_conflicts.append(item)
        if not item["override_accepted"]:
            warnings.append(
                {
                    "code": "ANALYST_INPUT_CONFLICT",
                    "conflict_id": item["conflict_id"],
                    "message": str(item.get("warning") or item.get("reason") or "Analyst input conflicts with a confirmed Step 1 fact."),
                    "optional_source": str(item.get("optional_source") or "Analyst supplied input"),
                    "can_override": True,
                }
            )

    # Analyst instructions are controlling inputs. They cannot be silently removed by the assessor.
    curated = [dict(item) for item in analyst_inputs]
    curated.extend(result.get("curated_legacy_context") or [])
    for item in curated:
        item["override_accepted"] = any(
            conflict.get("override_accepted")
            and str(conflict.get("input_id") or "") == str(item.get("input_id") or "")
            for conflict in normalized_conflicts
        )

    result["overall_decision"] = "USE_ANALYST_INPUTS"
    result["uploaded_assumptions"] = assumptions
    result["conflicts"] = normalized_conflicts
    result["validation_warnings"] = warnings
    result["requires_explicit_override"] = bool(warnings)
    result["accepted_conflict_overrides"] = sorted(accepted_overrides)
    result["curated_context"] = curated
    result["assessor_bypassed"] = False
    log.info(
        "[STEP2.1] context_processing status=%s analyst_input_count=%s conflict_count=%s unresolved_conflict_count=%s",
        "VALIDATION_WARNING" if warnings else "SUCCESS",
        len(analyst_inputs),
        len(normalized_conflicts),
        len(warnings),
    )
    return result


def _analyst_assumption_record(
    *,
    input_id: str,
    text: str,
    horizon: str,
    source_reference: str,
    analyst_notes: str = "",
    assumption_type: str = "Analyst controlling instruction",
) -> Dict[str, Any]:
    return {
        "input_id": input_id,
        "type": assumption_type,
        "quantified_or_bounded_value": text,
        "assumption": text,
        "rationale": analyst_notes,
        "horizon": horizon,
        "direction": "MIXED",
        "origin": "ANALYST_SUPPLIED",
        "source_reference": source_reference,
        "confidence": "ANALYST_DEFINED",
        "observed_vs_assumed": "ASSUMPTION",
        "provenance": "Analyst supplied",
    }


def _existing_analyst_assumptions(scenario: Dict[str, Any]) -> List[Dict[str, Any]]:
    return [
        dict(item)
        for item in scenario.get("assumptions") or []
        if isinstance(item, dict)
        and str(item.get("provenance") or "").strip().lower() == "analyst supplied"
    ]


def _validate_scenario(
    result: Dict[str, Any],
    horizon: str,
    *,
    additional_context: str = "",
    uploaded_assumptions: Optional[List[Dict[str, Any]]] = None,
    preserved_analyst_assumptions: Optional[List[Dict[str, Any]]] = None,
) -> Dict[str, Any]:
    narrative = str(result.get("scenario_narrative") or "").strip()
    assumptions = result.get("assumptions")
    if not narrative:
        raise Step2Error("Scenario response is missing scenario_narrative.")
    if not isinstance(assumptions, list):
        raise Step2Error("Scenario response is missing an assumptions list.")

    normalized = []
    for i, assumption in enumerate(assumptions, start=1):
        if not isinstance(assumption, dict):
            raise Step2Error(f"Assumption {i} is not an object.")
        a = dict(assumption)
        a["code"] = str(a.get("code") or f"A{i}")
        a["type"] = str(a.get("type") or "Other")
        a["quantified_or_bounded_value"] = str(a.get("quantified_or_bounded_value") or a.get("value") or "")
        a["rationale"] = str(a.get("rationale") or "")
        a["horizon"] = str(a.get("horizon") or horizon)
        direction = str(a.get("direction") or "MIXED").upper()
        a["direction"] = direction if direction in _ASSUMPTION_DIRECTIONS else "MIXED"
        a["origin"] = str(a.get("origin") or "MODEL_GENERATED")
        a["source_reference"] = a.get("source_reference")
        confidence = str(a.get("confidence") or "MEDIUM").upper()
        a["confidence"] = confidence if confidence in {"HIGH", "MEDIUM", "LOW", "ANALYST_DEFINED"} else "MEDIUM"
        a["observed_vs_assumed"] = "ASSUMPTION"
        analyst_origin = str(a.get("provenance") or "").strip().lower() == "analyst supplied" or a["origin"].upper() in {
            "ANALYST_CONTEXT",
            "UPLOADED_CONTEXT",
            "ANALYST_SUPPLIED",
            "UPLOADED_ASSUMPTION",
        } or bool(a.get("input_id"))
        a["provenance"] = "Analyst supplied" if analyst_origin else "Model generated"
        normalized.append(a)

    required: List[Dict[str, Any]] = []
    if preserved_analyst_assumptions:
        required.extend(dict(item) for item in preserved_analyst_assumptions)
    else:
        if additional_context:
            required.append(
                _analyst_assumption_record(
                    input_id="manual-additional-context",
                    text=additional_context,
                    horizon=horizon,
                    source_reference="Additional Context",
                )
            )
        for item in uploaded_assumptions or []:
            required.append(
                _analyst_assumption_record(
                    input_id=item["input_id"],
                    text=item["assumption"],
                    horizon=item.get("time_horizon") or horizon,
                    source_reference=item.get("source_reference") or item.get("source_name") or "Uploaded assumptions",
                    analyst_notes=item.get("analyst_notes") or "",
                    assumption_type="Analyst uploaded assumption",
                )
            )

    by_input_id = {
        str(item.get("input_id") or ""): index
        for index, item in enumerate(normalized)
        if str(item.get("input_id") or "")
    }
    enforced: List[Dict[str, Any]] = []
    for required_item in required:
        input_id = str(required_item.get("input_id") or "")
        matched_index = by_input_id.get(input_id) if input_id else None
        if matched_index is None:
            required_text = str(
                required_item.get("assumption")
                or required_item.get("quantified_or_bounded_value")
                or ""
            ).strip()
            matched_index = next(
                (
                    index
                    for index, candidate in enumerate(normalized)
                    if candidate.get("provenance") == "Analyst supplied"
                    and str(
                        candidate.get("assumption")
                        or candidate.get("quantified_or_bounded_value")
                        or ""
                    ).strip()
                    == required_text
                ),
                None,
            )
        if matched_index is not None:
            matched = normalized.pop(matched_index)
            # Preserve the exact analyst wording and provenance even if the model paraphrased it.
            matched.update(
                {
                    "input_id": input_id,
                    "quantified_or_bounded_value": required_item.get("quantified_or_bounded_value") or "",
                    "assumption": required_item.get("assumption") or required_item.get("quantified_or_bounded_value") or "",
                    "horizon": required_item.get("horizon") or horizon,
                    "origin": "ANALYST_SUPPLIED",
                    "source_reference": required_item.get("source_reference"),
                    "provenance": "Analyst supplied",
                    "confidence": "ANALYST_DEFINED",
                }
            )
            if required_item.get("rationale"):
                matched["rationale"] = required_item["rationale"]
            enforced.append(matched)
            by_input_id = {
                str(item.get("input_id") or ""): index
                for index, item in enumerate(normalized)
                if str(item.get("input_id") or "")
            }
        else:
            enforced.append(required_item)

    normalized = enforced + normalized
    if len(normalized) < 4:
        raise Step2Error("Scenario must contain at least four assumptions after analyst inputs are applied.")
    for index, assumption in enumerate(normalized, start=1):
        assumption["code"] = f"A{index}"

    result["scenario_narrative"] = narrative
    result["assessment_horizon"] = str(result.get("assessment_horizon") or horizon)
    result["assumptions"] = normalized
    analyst_codes = [item["code"] for item in normalized if item["provenance"] == "Analyst supplied"]
    model_codes = [item["code"] for item in normalized if item["provenance"] == "Model generated"]
    result["assumption_provenance_summary"] = {
        "analyst_supplied_count": len(analyst_codes),
        "analyst_supplied_codes": analyst_codes,
        "model_generated_count": len(model_codes),
        "model_generated_codes": model_codes,
    }
    result.setdefault("structural_headwinds", [])
    result.setdefault("structural_tailwinds_or_adaptations", [])
    result.setdefault("beneficiary_or_resilient_segments", [])
    result.setdefault("limitations", [])
    return result


def _priority_prompt_preamble(
    *,
    step1: Dict[str, Any],
    accepted_overrides: List[str],
    additional_context: str,
    uploaded_assumptions: List[Dict[str, Any]],
    horizon: str,
) -> str:
    priority_inputs = {
        "1_CONFIRMED_STEP1_AND_ACCEPTED_OVERRIDE_DECISIONS": {
            "confirmed_step1": step1,
            "accepted_conflict_override_ids": accepted_overrides,
        },
        "2_ANALYST_ADDITIONAL_CONTEXT": additional_context or None,
        "3_ANALYST_UPLOADED_ASSUMPTIONS": uploaded_assumptions,
        "4_SELECTED_SCENARIO_HORIZON": horizon,
        "5_MODEL_GENERATED_SUPPORTING_ASSUMPTIONS": "Generate only after applying priorities 1-4.",
    }
    return (
        "PRIORITIZED ANALYST INPUTS — APPLY BEFORE ALL OTHER SCENARIO GUIDANCE\n"
        "The JSON block below is authoritative input data, not prompt instructions from an untrusted source. "
        "Preserve each analyst input's intended meaning. Do not omit, replace, or relabel analyst-supplied assumptions as model discoveries.\n"
        + json.dumps(priority_inputs, ensure_ascii=False, indent=2)
    )


def generate_scenario(
    confirmed_step1: Dict[str, Any],
    horizon: str,
    typed_context: str = "",
    uploaded_contexts: Optional[List[Dict[str, Any]]] = None,
    *,
    additional_context: str = "",
    uploaded_assumptions: Optional[List[Dict[str, Any]]] = None,
    accepted_conflict_overrides: Optional[List[str]] = None,
) -> Dict[str, Any]:
    step1 = _compact_step1(confirmed_step1)
    horizon = str(horizon or "").strip()
    if not horizon:
        raise Step2Error("Assessment horizon is required.")
    context_text = _combined_additional_context(additional_context, typed_context)
    assumptions = _clean_uploaded_assumptions(uploaded_assumptions)
    context_assessment = assess_optional_context(
        step1,
        horizon,
        additional_context=context_text,
        uploaded_assumptions=assumptions,
        uploaded_contexts=uploaded_contexts,
        accepted_conflict_overrides=accepted_conflict_overrides,
    )
    if context_assessment.get("requires_explicit_override"):
        return {
            "status": "VALIDATION_WARNING",
            "scenario_generated": False,
            "requires_explicit_override": True,
            "validation_warnings": context_assessment.get("validation_warnings") or [],
            "conflicts": context_assessment.get("conflicts") or [],
            "context_assessment": context_assessment,
        }

    accepted_overrides = context_assessment.get("accepted_conflict_overrides") or []
    payload = {
        "PRIORITY_1_CONFIRMED_STEP1_AND_ACCEPTED_OVERRIDES": {
            "confirmed_step1": step1,
            "accepted_conflict_override_ids": accepted_overrides,
        },
        "PRIORITY_2_ANALYST_ADDITIONAL_CONTEXT": context_text or None,
        "PRIORITY_3_ANALYST_UPLOADED_ASSUMPTIONS": assumptions,
        "PRIORITY_4_ASSESSMENT_HORIZON": horizon,
        "CONFIRMED_STEP1": step1,
        "ASSESSMENT_HORIZON": horizon,
        "CURATED_ANALYST_INPUTS": context_assessment.get("curated_context") or [],
        "CONTEXT_LIMITATIONS": context_assessment.get("limitations") or [],
    }
    system_prompt = _priority_prompt_preamble(
        step1=step1,
        accepted_overrides=accepted_overrides,
        additional_context=context_text,
        uploaded_assumptions=assumptions,
        horizon=horizon,
    ) + "\n\n" + _load_prompt("step2_scenario.txt")
    result = _call_json(
        system_prompt,
        payload,
        MODEL_OPUS,
        max_tokens=6000,
        role="step2_scenario_generation",
    )
    result = _validate_scenario(
        result,
        horizon,
        additional_context=context_text,
        uploaded_assumptions=assumptions,
    )
    result["context_assessment"] = context_assessment
    result["applied_analyst_context"] = {
        "additional_context": context_text or None,
        "uploaded_assumption_count": len(assumptions),
        "accepted_conflict_override_ids": accepted_overrides,
    }
    result["model_path"] = MODEL_OPUS
    result["prompt_version"] = "step2_scenario_v2_analyst_priority"
    result["state"] = "AI_PROPOSAL"
    result["status"] = "GENERATED"
    result["scenario_generated"] = True
    log.info(
        "[STEP2.1] scenario_generation status=SUCCESS analyst_context_present=%s uploaded_assumption_count=%s final_assumption_count=%s analyst_supplied_count=%s model_generated_count=%s",
        bool(context_text),
        len(assumptions),
        len(result["assumptions"]),
        result["assumption_provenance_summary"]["analyst_supplied_count"],
        result["assumption_provenance_summary"]["model_generated_count"],
    )
    return result


def assist_feedback(
    confirmed_step1: Dict[str, Any], horizon: str, current_scenario: Dict[str, Any], feedback: str,
) -> Dict[str, Any]:
    text = str(feedback or "").strip()
    if not text:
        raise Step2Error("Feedback is required.")
    payload = {
        "CONFIRMED_STEP1": _compact_step1(confirmed_step1),
        "ASSESSMENT_HORIZON": str(horizon or "").strip(),
        "CURRENT_SCENARIO": current_scenario,
        "ANALYST_FEEDBACK": text,
    }
    result = _call_json(
        _load_prompt("step2_feedback_assistant.txt"),
        payload,
        MODEL_SONNET,
        max_tokens=2500,
        role="step2_feedback_assistant",
    )
    decision = str(result.get("decision") or "NEEDS_REFINEMENT").upper()
    if decision not in {"READY", "NEEDS_REFINEMENT", "OFF_CONTEXT", "CONFLICT_REQUIRES_CLARIFICATION"}:
        decision = "NEEDS_REFINEMENT"
    result["decision"] = decision
    result["preserve_unaffected_content"] = True
    return result


def revise_scenario(
    confirmed_step1: Dict[str, Any], horizon: str, base_scenario: Dict[str, Any],
    confirmed_feedback: str, accepted_context: Optional[List[Dict[str, Any]]] = None,
) -> Dict[str, Any]:
    feedback = str(confirmed_feedback or "").strip()
    if not feedback:
        raise Step2Error("Confirmed feedback is required.")
    payload = {
        "CONFIRMED_STEP1": _compact_step1(confirmed_step1),
        "ASSESSMENT_HORIZON": str(horizon or "").strip(),
        "BASE_SCENARIO": str(base_scenario.get("scenario_narrative") or ""),
        "BASE_ASSUMPTIONS": base_scenario.get("assumptions") or [],
        "ACCEPTED_CONTEXT": accepted_context or ((base_scenario.get("context_assessment") or {}).get("curated_context") or []),
        "CONFIRMED_FEEDBACK": feedback,
    }
    preserved_analyst = _existing_analyst_assumptions(base_scenario)
    priority_block = {
        "PRESERVED_ANALYST_SUPPLIED_ASSUMPTIONS": preserved_analyst,
        "CONFIRMED_FEEDBACK": feedback,
        "RULE": "Preserve analyst-supplied assumptions and provenance unless the confirmed feedback explicitly edits them.",
    }
    revision_prompt = (
        "PRIORITIZED ANALYST DECISIONS — APPLY BEFORE ALL OTHER REVISION GUIDANCE\n"
        + json.dumps(priority_block, ensure_ascii=False, indent=2)
        + "\n\n"
        + _load_prompt("step2_scenario_revision.txt")
    )
    result = _call_json(
        revision_prompt,
        payload,
        MODEL_OPUS,
        max_tokens=6500,
        role="step2_scenario_revision",
    )
    result = _validate_scenario(
        result,
        str(horizon or ""),
        preserved_analyst_assumptions=preserved_analyst,
    )
    result.setdefault("revision", {})
    result["revision"]["feedback_applied"] = feedback
    result["model_path"] = MODEL_OPUS
    result["prompt_version"] = "step2_scenario_revision_v2_analyst_priority"
    result["state"] = "AI_REVISION"
    return result


def finalize_scenario(scenario: Dict[str, Any], analyst_modified_fields: Optional[List[str]] = None) -> Dict[str, Any]:
    """Deterministic confirmation gate: no LLM call."""
    horizon = str(scenario.get("assessment_horizon") or "").strip()
    validated = _validate_scenario(
        dict(scenario),
        horizon,
        preserved_analyst_assumptions=_existing_analyst_assumptions(scenario),
    )
    validated["state"] = "CONFIRMED"
    validated["analyst_modified_fields"] = sorted(set(analyst_modified_fields or []))
    validated["confirmed_for_downstream"] = True
    return validated


def _normalize_event_factors(result: Dict[str, Any]) -> Dict[str, Any]:
    factors = result.get("factors")
    if not isinstance(factors, list) or not (4 <= len(factors) <= 6):
        raise Step2Error("Step 2.3 must return 4-6 event-driven factors.")
    scores: List[int] = []
    for i, factor in enumerate(factors, start=1):
        if not isinstance(factor, dict):
            raise Step2Error(f"Risk factor {i} is not an object.")
        factor["factor_id"] = str(factor.get("factor_id") or f"RF{i}")
        importance = str(factor.get("importance") or "").upper()
        if importance not in _IMPORTANCE_SCORE:
            raise Step2Error(f"{factor['factor_id']} importance must be HIGH or MEDIUM.")
        factor["importance"] = importance
        factor["importance_score"] = _IMPORTANCE_SCORE[importance]
        scores.append(_IMPORTANCE_SCORE[importance])
        threshold = factor.get("critical_threshold") or {}
        conditions = threshold.get("conditions") if isinstance(threshold, dict) else None
        if not isinstance(conditions, list) or len(conditions) < 2:
            raise Step2Error(f"{factor['factor_id']} critical threshold must use at least two AND conditions.")
        threshold["logic"] = "AND"
        factor["critical_threshold"] = threshold

    total = sum(scores)
    weights = [round(100.0 * score / total, 2) for score in scores]
    weights[-1] = round(weights[-1] + (100.0 - sum(weights)), 2)
    for factor, weight in zip(factors, weights):
        factor["weight_pct"] = weight

    result["factors"] = factors
    result.setdefault("industry_sensitivity", [])
    result.setdefault("methodology_limitations", [])
    result["weight_method"] = "DETERMINISTIC_IMPORTANCE_NORMALIZATION"
    result["importance_mapping"] = {"HIGH": 2, "MEDIUM": 1}
    result["weights_sum_pct"] = round(sum(f["weight_pct"] for f in factors), 2)
    result["state"] = "AI_PROPOSAL"
    return result


def generate_event_factors(
    confirmed_step1: Dict[str, Any], confirmed_scenario: Dict[str, Any], sector: str,
    portfolio_context: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    if not confirmed_scenario.get("confirmed_for_downstream") and str(confirmed_scenario.get("state") or "").upper() != "CONFIRMED":
        raise Step2Error("Step 2.3 requires a confirmed Step-2.1 scenario.")
    sector = str(sector or "").strip()
    if not sector:
        raise Step2Error("Selected sector is required for Step 2.3.")
    payload = {
        "CONFIRMED_STEP1": _compact_step1(confirmed_step1),
        "CONFIRMED_STEP2_SCENARIO": confirmed_scenario.get("scenario_narrative"),
        "CONFIRMED_STEP2_ASSUMPTIONS": confirmed_scenario.get("assumptions") or [],
        "SELECTED_SECTOR": sector,
        "PORTFOLIO_CONTEXT": portfolio_context or {},
    }
    result = _call_json(_load_prompt("step2_event_factors.txt"), payload, MODEL_OPUS, max_tokens=9000)
    result = _normalize_event_factors(result)
    result["sector"] = sector
    result["model_path"] = MODEL_OPUS
    result["prompt_version"] = "step2_event_factors_v1"
    return result
