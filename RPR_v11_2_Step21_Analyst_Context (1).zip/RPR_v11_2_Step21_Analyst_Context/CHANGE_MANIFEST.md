# RPR v11.2 — Step 2.1 Analyst Context and Assumption Upload

## Baseline

This package is built on `RPR_v11_1_Trigger1(1).zip`, the newest supplied Trigger 1 package. Its Trigger 1 runtime files, Bible-rule event limit, prompts, AI Assist behavior, polling, timeouts, and event orchestration are preserved.

The active Step 2.1 route, service, upload parser, and prompts were taken from the current project files and merged into that baseline before editing.

## Production files changed

| File | Change |
|---|---|
| `RUNTIME_ENV.ps1` | Keeps Gemini and Opus routing unchanged; enforces `LLM_PROVIDER=r2d2`; removes hard-coded Sonnet 4.6 assignments; requires the exact company-approved Sonnet 5 ID through `RPR_APPROVED_SONNET5_MODEL`. |
| `backend/step2_routes.py` | Adds `additional_context`, `uploaded_assumptions`, and `accepted_conflict_overrides` while preserving legacy `typed_context` and `uploaded_contexts`; adds `POST /api/v1/rpr/step2/assumptions/extract`. |
| `backend/step2_uploads.py` | Adds strict `.csv`/`.xlsx` parsing for `assumption`, optional `time_horizon`, and optional `analyst_notes`; rejects malformed/unsupported files and nonblank rows without an assumption. |
| `backend/step2_service.py` | Applies the required priority order at the beginning of the prompt; never silently drops analyst inputs; returns conflict warnings before generation; supports explicit override IDs; deterministically preserves analyst wording and provenance; logs counts/status without logging contents or tokens. |
| `backend/prompts/step2_context_assessor.txt` | Makes Sonnet a conflict/quality gate and distinguishes future assumptions from conflicting current-fact claims. |
| `backend/prompts/step2_scenario.txt` | Requires Opus to apply analyst context and every uploaded assumption before generating supporting assumptions; requires provenance fields. |
| `backend/prompts/step2_scenario_revision.txt` | Preserves analyst assumptions and provenance during targeted revision. |
| `frontend/rpr-v8-consolidated-test.html` | Preserves the v31 layout/styles; adds CSV/XLSX assumption upload, parsed-row review/removal, template links, conflict edit/override controls, and `Analyst supplied` / `Model generated` labels. |
| `backend/theme_assistant_batch.py` | Removes the Sonnet 4.6 default and requires the configured approved Sonnet 5 ID; behavior otherwise unchanged. |
| `backend/theme_assistant.py` | Routes individual theme-assistant Sonnet calls through the configured approved ID; AI Assist behavior remains unchanged. |
| `backend/rpr_feedback_service.py` | Removes the Sonnet 4.6 fallback and requires the configured approved Sonnet 5 ID; separate per-step feedback behavior remains unchanged. |

## New files

- `backend/tests/test_step2_1_analyst_inputs.py`
- `backend/tests/test_step2_1_frontend_dom.py`
- `templates/step2_assumptions_blank.csv`
- `templates/step2_assumptions_blank.xlsx`
- `templates/step2_assumptions_example.csv`
- `templates/step2_assumptions_example.xlsx`

## Behavior now implemented

1. Confirmed Step 1 facts and accepted override decisions remain first priority.
2. Additional Context is a controlling instruction, not an optional low-priority note.
3. Every parsed uploaded assumption is passed into generation and preserved in final assumptions.
4. Horizon is applied after analyst instructions.
5. Model-created supporting assumptions are added last.
6. A conflict returns `status=VALIDATION_WARNING` without calling scenario generation. The UI lets the analyst edit the input or explicitly override the listed conflict IDs.
7. Final assumptions carry exact provenance labels: `Analyst supplied` or `Model generated`.

## Explicitly unchanged / out of scope

- Trigger 1 `market_event_scout.py`, `server.py`, `rpr_search_agent.py`, and all `trigger1_*.txt` prompts are byte-identical to v11.1.
- Trigger 1 remains up to three events per accepted theme.
- Trigger 1 orchestration, limits, timeouts, and prompts are unchanged.
- Gemini and Opus routing are unchanged.
- AI Assist and separate step feedback panels are preserved.
- Step 2.2 and Step 2.3 onward are not redesigned or implemented by this change.
- CAGID/sector database work is not included.

## Sonnet 5 configuration status

No exact company API identifier for Sonnet 5 exists in the supplied active configuration, current Step 2 files, or stored project files inspected for this build. The identifier was therefore not guessed. Active runtime code contains no hard-coded Sonnet 4.6 default; startup now fails clearly until `RPR_APPROVED_SONNET5_MODEL` is set to the exact approved ID.

## Recorded open issue — not changed

Some successful Trigger 1 model responses may use a different event schema and lead to `Discovery response did not contain an events array.` This is recorded only. Trigger 1 was not changed to address it in this Step 2.1 package.
