# RPR v10 progressive-per-theme runtime settings.
# This script does not contain, print or persist a token.

# Works both when dot-sourced and when corporate policy requires
# Get-Content .\RUNTIME_ENV.ps1 -Raw | Invoke-Expression from the project root.
$rprRoot = if ($PSScriptRoot) { $PSScriptRoot } else { (Get-Location).Path }

$env:RPR_GEMINI_MODEL = "gemini-3.5-flash"
$env:RPR_GEMINI_DISCOVERY_MODEL = "gemini-3.5-flash"
$env:RPR_GEMINI_EVIDENCE_MODEL = "gemini-3.5-flash"
$env:RPR_GEMINI_THEME_MODEL = "gemini-3.5-flash"
$env:RPR_GEMINI_LOCATION = "us"
$env:RPR_STEP1_REFINEMENT_MODEL = "claude-opus-4-6"
$env:STEP2_OPUS_MODEL = "claude-opus-4-6"

# Sonnet 5 must come from the organization-approved company configuration.  This
# package deliberately does not guess an internal R2D2 identifier.
$approvedSonnet5 = if ($env:RPR_APPROVED_SONNET5_MODEL) {
    $env:RPR_APPROVED_SONNET5_MODEL.Trim()
} elseif ($env:STEP2_SONNET_MODEL) {
    $env:STEP2_SONNET_MODEL.Trim()
} else {
    ""
}
if (-not $approvedSonnet5) {
    throw "Set RPR_APPROVED_SONNET5_MODEL to the exact organization-approved Sonnet 5 identifier before loading RUNTIME_ENV.ps1."
}
if ($approvedSonnet5 -match 'sonnet.*4[-._]?6') {
    throw "The configured Sonnet model is not Sonnet 5. Update RPR_APPROVED_SONNET5_MODEL using the approved company model catalogue."
}
$env:STEP2_SONNET_MODEL = $approvedSonnet5
$env:RPR_FEEDBACK_MODEL = $approvedSonnet5
$env:RPR_THEME_GATE_MODEL = $approvedSonnet5
$env:R2D2_MODEL = $approvedSonnet5
$env:LLM_PROVIDER = "r2d2"

# v11: each theme runs a fast discovery call that finds up to RPR_T1_MAX_EVENTS_PER_THEME
# distinct events (Bible rule: 3, not reduced for performance). Each discovered event then
# runs its own independent evidence-enrichment -> Opus-refinement pipeline in a dedicated
# background thread, so a theme's events progress at their own pace -- one event reaching
# "refined" never waits for its slower siblings. /market-events/fetch returns almost
# immediately with a job_id; a theme's events appear as soon as ITS OWN discovery call
# finishes, independent of any other theme still running.
$env:RPR_T1_THEME_WORKERS = "3"
$env:RPR_T1_OPUS_WORKERS = "2"
# Bible rule: up to 3 events per accepted theme. Discovery stays fast at this count because
# it only asks for a short overview + a few sources per event, never a full report -- do
# not lower this for performance reasons; see RPR_T1_DISCOVERY_TIMEOUT below instead if
# discovery latency needs tuning.
$env:RPR_T1_MAX_EVENTS_PER_THEME = "3"

# Fast-fail ceiling for the discovery call (title, date, short overview, 2-4 sources per
# event, up to 3 events -- no eight-section report at this stage). These are SAFETY
# CEILINGS, not performance targets -- lowering them does not make model calls faster.
# Measured live execution: discovery ~36-41s, enrichment ~109-138s/event, refinement
# ~122-150+s/event. Defaults below carry real headroom above that observed range.
$env:RPR_T1_DISCOVERY_TIMEOUT = "50"
$env:RPR_T1_ENRICHMENT_TIMEOUT = "150"
$env:RPR_T1_REFINEMENT_TIMEOUT = "180"
$env:RPR_T1_TARGETED_TIMEOUT = "90"
$env:RPR_T1_THEME_GATE_TIMEOUT = "45"
$env:RPR_T1_OPUS_MAX_TOKENS = "4200"
$env:RPR_T1_GEMINI_MAX_CHARS = "36000"
$env:RPR_T1_CACHE_SECONDS = "900"
$env:RPR_T1_JOB_TTL_SECONDS = "3600"
$env:RPR_HELIX_TOKEN_CACHE_SECONDS = "480"

# Canonical adapter names, bridged from the already-approved RPR environment.
$env:VERTEX_LOCATION = "us"
if ($env:VERTEX_PROJECT_ID -and -not $env:VERTEX_PROJECT) {
    $env:VERTEX_PROJECT = $env:VERTEX_PROJECT_ID
}

$candidateUrls = @(
    $env:RPR_VERTEX_BASE_URL,
    $env:R2D2_BASE_URL,
    $env:VERTEX_ENDPOINT,
    $env:BASE_VERTEX_URL,
    $env:R2D2_UAT_URL
)
$rawVertexUrl = $candidateUrls | Where-Object { $_ -and $_.Trim() } | Select-Object -First 1

# If the current process has no URL variables, read the existing non-secret gateway default.
if (-not $rawVertexUrl) {
    $pythonExe = Join-Path $rprRoot "portfolio-agent\.venv\Scripts\python.exe"
    if (Test-Path $pythonExe) {
        $gatewayUrl = & $pythonExe -c "from llm_gateway import R2D2LLMGateway; print(R2D2LLMGateway._UAT_URL)"
        if ($LASTEXITCODE -eq 0 -and $gatewayUrl) {
            $rawVertexUrl = $gatewayUrl.Trim()
        }
    }
}

if ($rawVertexUrl) {
    # google-genai appends /v1 itself. Remove an existing API-version suffix exactly once.
    $cleanVertexUrl = $rawVertexUrl.Trim().TrimEnd('/') -replace '/v1(?:alpha\d*|beta\d*)?$', ''
    $env:RPR_VERTEX_BASE_URL = $cleanVertexUrl.TrimEnd('/')
    $env:VERTEX_ENDPOINT = $env:RPR_VERTEX_BASE_URL
}

$endpointReady = [bool]$env:RPR_VERTEX_BASE_URL
$projectReady = [bool]($env:VERTEX_PROJECT -or $env:VERTEX_PROJECT_ID -or $env:R2D2_GCP_PROJECT)
Write-Host "RPR v11 runtime loaded. endpointReady=$endpointReady projectReady=$projectReady model=$env:RPR_GEMINI_MODEL discoveryTimeout=$($env:RPR_T1_DISCOVERY_TIMEOUT)s maxEventsPerTheme=$env:RPR_T1_MAX_EVENTS_PER_THEME"
