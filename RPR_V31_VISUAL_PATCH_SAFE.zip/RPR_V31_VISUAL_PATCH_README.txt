RPR V31 VISUAL PATCH — SAFE ACTION PACKAGE

This package lets ChatGPT implement the approved visual changes against the exact
working files on your machine without reconstructing the full 320-line JS file.

CHANGED
- UI Design\rpr_step22_step23_append.js
- UI Design\rpr_step22_step23_append.css

UNTOUCHED
- UI Design\rpr_step24_append.js
- UI Design\rpr_step24_append.css
- backend/*
- prompts/*
- Step 1 / Step 2.1

VISUAL CHANGES
Step 2.2:
- L1 -> L2 -> existing L3 card hierarchy.
- No new per-L2 Select All/Deselect All behavior.
- Current filters, selection, search, companies, upload and confirmation preserved.

Step 2.3:
- Total Weight footer.
- Net Score explanatory caption.
- Action order: Generate -> Add -> Save -> Confirm.
- Current generation/scoring/API/confirmation logic preserved.

Step 2.4:
- No code change in this package.
- Proven-working Step 2.4 remains the functional bone.

HOW TO RUN
1. Copy apply_rpr_v31_visual_patch.py into the Rapid Portfolio Review_AI project root.
2. Open a terminal in that root.
3. Run:
   python apply_rpr_v31_visual_patch.py
4. The script creates timestamped .bone-backup-* copies automatically.
5. If it prints PASS, use Ctrl+F5 in the browser.

The script aborts instead of guessing when expected working-bone markers are absent.

FUNCTIONAL CONTRACTS PRESERVED
