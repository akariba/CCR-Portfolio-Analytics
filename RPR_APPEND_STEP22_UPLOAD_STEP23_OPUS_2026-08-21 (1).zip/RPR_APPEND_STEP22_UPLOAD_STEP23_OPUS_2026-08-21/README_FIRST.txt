RPR APPEND — STEP 2.2 UPLOAD + STEP 2.3 OPUS
================================================

Purpose
- Preserve the current working building blocks unchanged.
- Append real Step 2.2 Upload Portfolio functionality.
- Append live Step 2.3 Event-Driven Risk Factor reasoning using Opus.
- Preserve the v31 visual structure; no Step 1 or Step 2.1 redesign.

WHAT THIS PACKAGE IMPLEMENTS
1) Step 2.2 Upload Portfolio
   - CSV/XLSX upload.
   - CAGID is the matching key.
   - Resolves canonical company/sector/country/MLE from the existing Step 2.2 company master.
   - Reports unmatched, duplicate and malformed rows.
   - Uses the SAME finalized portfolio contract as manual/filter selection.
   - Deterministic; no LLM call.

2) Step 2.3 Event-Driven Risk Factors
   - Opus performs the substantive credit-risk reasoning.
   - 4-6 event-driven factors.
   - Vulnerability metrics + formulas + threshold bands.
   - Multi-condition AND critical threshold.
   - Durable buffer metrics.
   - 1-5 scoring methodology rows.
   - HIGH/MEDIUM importance proposed by AI.
   - Python maps HIGH=2, MEDIUM=1 and normalizes exact weights to 100%.
   - Analyst can edit, add/remove metrics, add/remove factors, save and confirm.
   - Save/Confirm are deterministic validation operations.
   - Targeted feedback revision is routed separately (configure Sonnet 5).

NOT IMPLEMENTED IN THIS APPEND
- Step 2.4 live sector-inherent engine.
- Step 2.5 live company/name-level assessment.
- Step 3 live portfolio aggregation.
These existing pages remain as they were. Do not infer that they were completed by this package.

START WITH COPY_MAP.txt.
