# RPR append change manifest

## Existing working building blocks preserved
No intentional changes were made to the existing Step 1 or Step 2.1 functions. Static comparison against the source HTML used for this append confirmed identical implementations for key functions including `assistThemes`, `runScan`, `confirmEv`, `generateStep21Scenario`, `confirmStep21`, `readScenarioFromDom`, and `renderAssumptionRows`.

## Step 2.2 additions
- `step22_portfolio_service.py`: real CSV/XLSX upload ingestion, CAGID resolution, issue reporting, `selection_mode` and upload source metadata on finalize.
- `step22_portfolio_routes.py`: adds `POST /api/v1/rpr/step2/portfolio/upload`; existing catalog/search/finalize routes remain.
- Full HTML: activates the existing Upload Portfolio tab and maps upload confirmation into the same normalized Step 2.2 portfolio object used by filter selection.

## Step 2.3 additions
- New additive `step23_event_factors_service.py`.
- New additive `step23_event_factors_routes.py`.
- New governed prompts for Opus reasoning, Sonnet-targeted revision, and structural repair.
- New API prefix `/api/v1/rpr/step23/event-factors` with generate / validate / revise / finalize.
- Full HTML Step 2.3 editor now supports the v31 risk-factor structure: narrative, importance, vulnerability metrics/formulas/bands, AND critical threshold, buffer metrics/formulas/bands, key principle, 1-5 scoring logic, factor/metric editing, deterministic Save and deterministic Confirm.

## Governance split
- Opus: substantive event-driven credit-risk reasoning.
- Sonnet 5: targeted revision / structural repair when configured.
- Python: schema rules, factor count, importance mapping, exact weights, score-row presence, AND-threshold rule and confirmation.
- Step 2.2: deterministic only.
