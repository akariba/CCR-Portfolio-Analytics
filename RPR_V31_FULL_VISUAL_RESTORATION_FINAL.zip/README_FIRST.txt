RPR FULL V31 VISUAL RESTORATION — FINAL SAFE PACKAGE
====================================================

BASED ON THE EXACT STYLUS FORENSIC HANDOFF.

STEP 2.2
- L1 -> L2 -> existing backend-driven L3 visual hierarchy.
- Current filters/search/upload/company results/selection/confirmation remain unchanged.
- NO new per-L2 Select All/Deselect All behavior.

STEP 2.3
- Adds Total Weight footer.
- Adds exact v31-style Net Score caption under Scoring Logic.
- PRESERVES current action order: Add -> Generate -> Save -> Confirm.
- Generation/edit/save/confirm/API/model behavior remains unchanged.

STEP 2.4
- rpr_step24_append.js is IMMUTABLE and untouched.
- Only tightly scoped Step 2.4 CSS parity rules are appended.

NOT CHANGED
-----------
backend/*
prompts/*
models
Step 1
Step 2.1
any API endpoint
any existing state contract

HOW TO RUN
----------
1. Copy these 3 Python files into Rapid Portfolio Review_AI root:
   apply_rpr_v31_full_visual_upgrade.py
   validate_rpr_v31_full_visual_upgrade.py
   rollback_rpr_v31_full_visual_upgrade.py

2. Run:
   python .\apply_rpr_v31_full_visual_upgrade.py

3. Require:
   PASS — RPR FULL v31 visual restoration applied safely.
   FUNCTIONAL CONTRACTS PRESERVED

4. Run:
   python .\validate_rpr_v31_full_visual_upgrade.py

5. Require:
   VALIDATION PASS
   FUNCTIONAL CONTRACTS PRESERVED

6. Ctrl+F5 and test Steps 2.2 / 2.3 / 2.4.

IF ABORTED OR VALIDATION FAILED
-------------------------------
STOP. Do not manually edit the app.
If apply had already printed PASS, rollback with:
   python .\rollback_rpr_v31_full_visual_upgrade.py

BACKUPS
-------
The apply script creates timestamped .bone-backup-* files and:
.rpr_v31_visual_upgrade_state.json

STEP 2.4 V6.0
-------------
The V6.0 prompt is now the Step 2.4 business source of truth, but is deliberately
NOT mixed into this visual-restoration deployment. That backend/prompt upgrade is
separate so the proven-working Step 2.4 UI/API bone remains protected.
