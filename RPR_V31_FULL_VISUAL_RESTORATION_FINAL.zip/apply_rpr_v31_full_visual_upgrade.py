#!/usr/bin/env python3
from pathlib import Path
from datetime import datetime
import hashlib, json, shutil, sys

ROOT = Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path.cwd().resolve()
UI = ROOT/'UI Design'
JS = UI/'rpr_step22_step23_append.js'
CSS = UI/'rpr_step22_step23_append.css'
STEP24_JS = UI/'rpr_step24_append.js'
STEP24_CSS = UI/'rpr_step24_append.css'
STATE = ROOT/'.rpr_v31_visual_upgrade_state.json'
STAMP = datetime.now().strftime('%Y%m%d_%H%M%S')

def fail(msg): raise SystemExit('ABORTED — '+msg)
def read(path):
    if not path.exists(): fail(f'Required file not found: {path}')
    return path.read_text(encoding='utf-8-sig')
def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for c in iter(lambda:f.read(1024*1024),b''): h.update(c)
    return h.hexdigest()
def backup(path):
    dst=path.with_name(path.name+f'.bone-backup-{STAMP}')
    shutil.copy2(path,dst); return dst

def function_span(src,name):
    start=src.find(f'function {name}(')
    if start<0: fail(f'Function not found: {name}')
    brace=src.find('{',start)
    if brace<0: fail(f'Opening brace not found for {name}')
    depth=0; i=brace; state='code'; quote=None
    while i<len(src):
        ch=src[i]; nxt=src[i+1] if i+1<len(src) else ''
        if state=='code':
            if ch in ("'",'"','`'): quote=ch; state='string'
            elif ch=='/' and nxt=='/': state='line'; i+=1
            elif ch=='/' and nxt=='*': state='block'; i+=1
            elif ch=='{': depth+=1
            elif ch=='}':
                depth-=1
                if depth==0: return start,i+1
        elif state=='string':
            if ch=='\\': i+=1
            elif ch==quote: state='code'; quote=None
        elif state=='line':
            if ch=='\n': state='code'
        elif state=='block':
            if ch=='*' and nxt=='/': state='code'; i+=1
        i+=1
    fail(f'Could not determine end of function {name}')

js=read(JS); css=read(CSS); step24_css=read(STEP24_CSS) if STEP24_CSS.exists() else ''

required=[
 'const STEP22_TEMPLATE','const STEP23_TEMPLATE','let STEP22_CONFIRMED_PORTFOLIO=null;',
 'function buildPortfolioSelectionUI()','function refreshSelectionUI()','function toggleSector(',
 'function selectAllSectors(','function clearAllSectors(','function runStep22Search()',
 'function confirmPortfolioSelection()','function rebuildSectorDropdowns()','function step23PortfolioContext()',
 'function generateEventFactors()','function renderEventFactors()','function buildRFCard(',
 'function saveEventFactorChanges()','function confirmEventFactors()',
 '/api/v1/rpr/step2/portfolio/catalog','/api/v1/rpr/step2/portfolio/search','/api/v1/rpr/step2/portfolio/finalize',
 '/api/v1/rpr/step23/event-factors/generate','id=\\"ed-summary-body\\"','id=\\"generate-event-factors-btn\\"',
 'id=\\"save-event-factors-btn\\"','id=\\"confirm-event-factors-btn\\"','Scoring Logic (1–5)']
missing=[x for x in required if x not in js]
if missing: fail('Current JS differs from proven bone. Missing: '+', '.join(missing))
if 'step22SelectAllByL2' in js or 'selectAllByL2' in js: fail('Unapproved per-L2 Select-All code already exists.')

# Preserve exact current Add -> Generate -> Save -> Confirm order.
a=js.find('const STEP23_TEMPLATE'); b=js.find('let STEP22_INSTALLED',a); tpl=js[a:b]
tokens=['addBlankEventFactor()','generateEventFactors()','saveEventFactorChanges()','confirmEventFactors()']
pos=[tpl.find(x) for x in tokens]
if any(x<0 for x in pos) or pos!=sorted(pos): fail('Current Step 2.3 action order is not the proven Add -> Generate -> Save -> Confirm bone.')
step24_hash_before=sha(STEP24_JS) if STEP24_JS.exists() else None

new_build = '''function buildPortfolioSelectionUI(){
 const c=$('ps-sector-grid');if(!c)return;
 if(!STEP22_CATALOG_OK){c.innerHTML='<div class="pla-placeholder" style="grid-column:1/-1"><div class="pla-placeholder-title">Portfolio catalog unavailable</div></div>';refreshSelectionUI();return}
 if(!ALL_SECTORS.length){c.innerHTML='<div class="pla-placeholder" style="grid-column:1/-1"><div class="pla-placeholder-title">No L3 sectors match the current filters</div><div class="pla-placeholder-sub">Change Geography, Country, MLE or L2 selection.</div></div>';refreshSelectionUI();return}
 const l1Groups={};
 ALL_SECTORS.forEach(s=>{const l1=s.l1||'Other',l2=s.l2||'Other';if(!l1Groups[l1])l1Groups[l1]={};if(!l1Groups[l1][l2])l1Groups[l1][l2]=[];l1Groups[l1][l2].push(s)});
 c.innerHTML=Object.entries(l1Groups).map(([l1,l2Groups])=>`<div class="ps-group"><div class="ps-group-label"><span class="ps-group-label-dot"></span><span>${esc(l1)}</span></div>${Object.entries(l2Groups).map(([l2,sectors])=>`<div class="ps-l2-group"><div class="ps-l2-header"><span class="ps-l2-label">${esc(l2)}</span><span class="ps-l2-count">${sectors.length} sectors</span></div><div class="ps-sector-grid">${sectors.map(s=>`<div class="ps-sector-card ${STEP2_SELECTED_SECTORS.has(s.id)?'selected':''}" onclick="toggleSector('${esc(s.id)}')"><div class="ps-check">${STEP2_SELECTED_SECTORS.has(s.id)?'✓':''}</div><div><div class="ps-sector-name">${esc(s.name)}</div><div class="ps-sector-path">${esc(s.path)}</div></div></div>`).join('')}</div></div>`).join('')}</div>`).join('');
 refreshSelectionUI();
}'''
s,e=function_span(js,'buildPortfolioSelectionUI'); js=js[:s]+new_build+js[e:]

new_render = '''function renderEventFactors(){
 const fs=STEP2_EVENT_FACTORS?.factors||[];$('ed-factor-count').textContent=fs.length;
 const totalWeight=fs.reduce((sum,f)=>sum+(Number(f.weight_pct)||0),0);
 $('ed-summary-body').innerHTML=fs.length?fs.map((f,i)=>`<tr><td>${esc(f.factor_id||('RF'+(i+1)))}</td><td>${esc(f.name||'')}</td><td>${esc(f.importance||'')}</td><td>${esc(f.importance_score??'')}</td><td>${esc(f.weight_pct??'')}%</td></tr>`).join('')+`<tr class="ed-total-row"><td colspan="4" style="text-align:right;padding-right:12px;font-weight:700">Total Weight</td><td style="font-weight:700">${totalWeight.toFixed(1)}%</td></tr>`:`<tr><td colspan="5" style="color:var(--text_disabled)">Generate the event-driven framework after confirming Step 2.1 and Step 2.2.</td></tr>`;
 $('ed-rf-cards').innerHTML=fs.map((f,i)=>buildRFCard(f,i===0,i)).join('');
}'''
s,e=function_span(js,'renderEventFactors'); js=js[:s]+new_render+js[e:]

# Add exact v31-style Net Score caption using the exact U+2013 label from the live file.
if 'class="net-score-note"' not in js:
    bs,be=function_span(js,'buildRFCard'); seg=js[bs:be]; rel=seg.find('Scoring Logic (1–5)')
    if rel<0: fail('Exact Scoring Logic (1–5) label not found inside buildRFCard.')
    label_abs=bs+rel; table_open=js.find('<table class="metric-tbl">',label_abs,be)
    if table_open<0: fail('Scoring table not found after exact Step 2.3 label.')
    table_close=js.find('</table>',table_open,be)
    if table_close<0: fail('Scoring table closing tag not found.')
    insert_at=table_close+len('</table>')
    caption='<div class="net-score-note">Net Score = Raw Score − Buffer Credit (Strong: -2 / Moderate: -1 / Weak: 0). Floor: 1.</div>'
    js=js[:insert_at]+caption+js[insert_at:]

marker='/* RPR FINAL V31 VISUAL RESTORATION — STEP 2.2 / 2.3 */'
css_add='''

/* RPR FINAL V31 VISUAL RESTORATION — STEP 2.2 / 2.3 */
#ps-sector-grid > .ps-group{grid-column:1/-1;margin-bottom:var(--sp16,16px)}
#ps-sector-grid > .ps-group:last-child{margin-bottom:0}
#ps-sector-grid .ps-group-label{font-size:var(--fs-2xs,10px);font-weight:var(--fw-bold,700);text-transform:uppercase;letter-spacing:.1em;color:var(--text_weak);margin-bottom:var(--sp10,10px);display:flex;align-items:center;gap:var(--sp8,8px);padding-bottom:var(--sp8,8px);border-bottom:1px solid var(--border_weak)}
#ps-sector-grid .ps-group-label-dot{width:8px;height:8px;border-radius:50%;flex-shrink:0;background:var(--primary)}
#ps-sector-grid .ps-l2-group{margin-bottom:var(--sp14,14px)}
#ps-sector-grid .ps-l2-group:last-child{margin-bottom:0}
#ps-sector-grid .ps-l2-header{display:flex;align-items:center;gap:var(--sp8,8px);padding:var(--sp6,6px) 0 var(--sp8,8px);margin-bottom:var(--sp8,8px);border-bottom:1px dashed var(--border_weak)}
#ps-sector-grid .ps-l2-label{font-size:var(--fs-xs,11px);font-weight:var(--fw-bold,700);color:var(--heading_primary,var(--text_strong))}
#ps-sector-grid .ps-l2-count{font-size:var(--fs-2xs,10px);color:var(--text_disabled)}
#ps-sector-grid .ps-l2-group > .ps-sector-grid{margin-top:0}
#ed-summary-body .ed-total-row td{border-top:1px solid var(--border_weak);background:var(--layer_secondary)}
#ed-rf-cards .net-score-note{background:var(--layer_secondary);border:1px solid var(--border_weak);border-radius:var(--radius-sm,4px);padding:5px 7px;margin-top:6px;font-size:10px;font-style:italic;color:var(--text_weak)}
'''
if marker not in css: css=css.rstrip()+css_add+'\n'

step24_marker='/* RPR FINAL V31 VISUAL RESTORATION — STEP 2.4 CSS ONLY */'
step24_add='''

/* RPR FINAL V31 VISUAL RESTORATION — STEP 2.4 CSS ONLY */
#t1-step-3 .s23-sector-bar{display:flex;align-items:center;gap:var(--sp12,12px)}
#t1-step-3 .card.summary-card .card-hdr{display:flex;align-items:center}
#t1-step-3 .formula-banner{margin-bottom:12px}
#t1-step-3 .action-row{justify-content:flex-end}
#t1-step-3 .panel-feedback{margin-top:12px}
'''
if STEP24_CSS.exists() and step24_marker not in step24_css: step24_css=step24_css.rstrip()+step24_add+'\n'

# Contract checks before writing.
must=['let STEP22_CONFIRMED_PORTFOLIO=null;','function refreshSelectionUI()','function toggleSector(','function selectAllSectors(','function clearAllSectors(','function runStep22Search()','function confirmPortfolioSelection()','function rebuildSectorDropdowns()','function step23PortfolioContext()','function generateEventFactors()','function saveEventFactorChanges()','function confirmEventFactors()','/api/v1/rpr/step23/event-factors/generate']
bad=[x for x in must if x not in js]
if bad: fail('Post-patch functional contract check failed: '+', '.join(bad))
if 'step22SelectAllByL2' in js or 'selectAllByL2' in js: fail('Unapproved per-L2 selection behavior was introduced.')
if js.count('function buildPortfolioSelectionUI(')!=1 or js.count('function renderEventFactors(')!=1: fail('Renderer duplication detected.')
a=js.find('const STEP23_TEMPLATE'); b=js.find('let STEP22_INSTALLED',a); tpl2=js[a:b]; pos2=[tpl2.find(x) for x in tokens]
if pos2!=sorted(pos2): fail('Step 2.3 action order changed unexpectedly.')

backups={}
for p in (JS,CSS): backups[str(p)]=str(backup(p))
if STEP24_CSS.exists(): backups[str(STEP24_CSS)]=str(backup(STEP24_CSS))
before={str(JS):sha(JS),str(CSS):sha(CSS),str(STEP24_JS):step24_hash_before}
if STEP24_CSS.exists(): before[str(STEP24_CSS)]=sha(STEP24_CSS)

JS.write_text(js,encoding='utf-8'); CSS.write_text(css,encoding='utf-8')
if STEP24_CSS.exists(): STEP24_CSS.write_text(step24_css,encoding='utf-8')

step24_hash_after=sha(STEP24_JS) if STEP24_JS.exists() else None
if step24_hash_before!=step24_hash_after:
    for o,bkp in backups.items(): shutil.copy2(bkp,o)
    fail('Step 2.4 JS hash changed unexpectedly. All modified files restored.')

after={str(JS):sha(JS),str(CSS):sha(CSS),str(STEP24_JS):step24_hash_after}
if STEP24_CSS.exists(): after[str(STEP24_CSS)]=sha(STEP24_CSS)
STATE.write_text(json.dumps({'version':'RPR_V31_FULL_VISUAL_RESTORATION_FINAL','timestamp':STAMP,'root':str(ROOT),'backups':backups,'before_hashes':before,'after_hashes':after,'step24_js_immutable':True},indent=2),encoding='utf-8')

print('PASS — RPR FULL v31 visual restoration applied safely.')
print('FUNCTIONAL CONTRACTS PRESERVED')
print('Step 2.4 JS UNTOUCHED')
print('State:',STATE)
