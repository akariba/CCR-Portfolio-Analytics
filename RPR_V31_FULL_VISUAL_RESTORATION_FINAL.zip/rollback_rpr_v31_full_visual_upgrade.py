#!/usr/bin/env python3
from pathlib import Path
import json,shutil,sys
ROOT=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path.cwd().resolve(); STATE=ROOT/'.rpr_v31_visual_upgrade_state.json'
if not STATE.exists(): raise SystemExit('No state file found.')
st=json.loads(STATE.read_text(encoding='utf-8')); backups=st.get('backups',{})
if not backups: raise SystemExit('No backups recorded.')
for o,b in backups.items():
 op=Path(o); bp=Path(b)
 if not bp.exists(): raise SystemExit(f'Backup missing: {bp}')
 shutil.copy2(bp,op); print('RESTORED:',op)
print('ROLLBACK PASS')
print('Step 2.4 JS was never modified by this package.')
