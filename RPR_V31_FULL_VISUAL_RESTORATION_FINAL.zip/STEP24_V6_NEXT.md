# Step 2.4 V6.0 — Next Additive Upgrade (NOT APPLIED HERE)

V6.0 changes Step 2.4 from pre-defined taxonomy expansion to research-driven identification.

Target flow:
L1/L2/L3 -> approved research -> identify 4–5 persistent structural factors -> vulnerability/buffer metrics -> deterministic scoring/weights -> analyst confirmation.

Core rules already established:
- input is Sector L1/L2/L3; no pre-defined factor names/details required
- 4–5 factors
- Structural Persistence Test separates 2.4 from event-driven 2.3
- minimum 3 quantitative vulnerability metrics plus corresponding buffers
- HIGH=2, MEDIUM=1
- weights sum 100%
- Net Score = Raw Vulnerability Score − Buffer Credit
- Strong −2, Moderate −1, Weak/Negligible 0
- floor 1, ceiling 5
- Score 5 only for simultaneous breach of all critical conditions
- composite score is deterministic weighted aggregation

Implement this next behind the existing Step 2.4 UI/API contract, using the exact internal V6.0 source file rather than reconstructing governed wording from screenshots.
