# Bone Rules

1. Current working code is functional truth.
2. v31 is visual truth only.
3. Step 2.4 JavaScript is immutable.
4. No backend/API/model/prompt changes in this package.
5. No new per-L2 Select-All behavior.
6. Back up before write.
7. Abort rather than guess.
