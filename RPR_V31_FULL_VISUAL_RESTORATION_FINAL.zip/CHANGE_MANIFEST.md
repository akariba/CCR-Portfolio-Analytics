# Change Manifest

| Step | Change | Functional impact |
|---|---|---|
| 2.2 | L1 -> L2 -> L3 visual hierarchy | Renderer only |
| 2.2 | No per-L2 Select-All | Protects current behavior |
| 2.3 | Total Weight footer | Display only |
| 2.3 | Net Score caption | Display only |
| 2.3 | Add -> Generate -> Save -> Confirm | Preserved |
| 2.4 | CSS-only parity | Visual only |
| 2.4 JS | No changes | Immutable bone |
| Backend/prompts/models | No changes | None |

Exact forensic fact: live Step 2.3 label is `Scoring Logic (1–5)` using U+2013 EN DASH.
