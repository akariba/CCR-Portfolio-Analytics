#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,sys
ROOT=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path.cwd().resolve(); UI=ROOT/'UI Design'
JS=UI/'rpr_step22_step23_append.js'; STATE=ROOT/'.rpr_v31_visual_upgrade_state.json'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for c in iter(lambda:f.read(1024*1024),b''): h.update(c)
 return h.hexdigest()
errs=[]
if not STATE.exists(): errs.append('State file missing')
else:
 st=json.loads(STATE.read_text(encoding='utf-8'))
 for p,h in st.get('after_hashes',{}).items():
  q=Path(p)
  if not q.exists(): errs.append(f'Missing file: {q}')
  elif sha(q)!=h: errs.append(f'Hash changed: {q}')
if JS.exists():
 s=JS.read_text(encoding='utf-8-sig')
 for m in ['class="ps-group"','class="ps-l2-group"','class="ed-total-row"','class="net-score-note"','Scoring Logic (1–5)','/api/v1/rpr/step23/event-factors/generate','function confirmPortfolioSelection()','function confirmEventFactors()']:
  if m not in s: errs.append('Missing marker: '+m)
 if 'step22SelectAllByL2' in s or 'selectAllByL2' in s: errs.append('Unapproved per-L2 selector found')
if errs:
 print('VALIDATION FAILED')
 for e in errs: print(' -',e)
 raise SystemExit(1)
print('VALIDATION PASS')
print('FUNCTIONAL CONTRACTS PRESERVED')
