RPR STEP 2.2 DATA CONTRACT
===========================
portfolio_sector_taxonomy.csv
- Governed deterministic L2 -> L3 hierarchy.
- The six current rows preserve the choices already present in the working HTML.

portfolio_company_master.csv
- Production internal company/exposure reference table.
- Headers only in this package. No company, CAGID, MLE or exposure data is fabricated.

portfolio_upload_template.csv
- End-user CSV template for the alternative upload path.

Step 2.2 membership is deterministic. No generative prompt selects portfolio membership.
The separate Step 2.2 feedback assistant may explain/recommend but cannot mutate selection.
