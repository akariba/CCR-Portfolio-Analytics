"""Deterministic Step 2.2 Portfolio Selection service."""
from __future__ import annotations
import csv, io
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Set

DATA_DIR = Path(__file__).resolve().parent / "data"
TAXONOMY_PATH = DATA_DIR / "portfolio_sector_taxonomy.csv"
COMPANY_MASTER_PATH = DATA_DIR / "portfolio_company_master.csv"
MAX_UPLOAD_BYTES = 5 * 1024 * 1024
REQUIRED_UPLOAD_COLUMNS = {
    "cagid","company_name","mle","sector_id","l2_name","l3_name",
    "country","legal_entity","exposure_amount","exposure_currency",
}

class PortfolioSelectionError(RuntimeError): pass

def _truthy(v: Any) -> bool:
    return str(v or "").strip().lower() in {"1","true","yes","y","active"}

def _read_csv(path: Path) -> List[Dict[str,str]]:
    if not path.exists(): raise PortfolioSelectionError(f"Required Step 2.2 data file is missing: {path}")
    with path.open("r",encoding="utf-8-sig",newline="") as f:
        return [dict(r) for r in csv.DictReader(f)]

def _number(v: Any) -> Optional[float]:
    s=str(v or "").strip().replace(",","")
    if not s: return None
    try: return float(s)
    except ValueError as exc: raise PortfolioSelectionError(f"Invalid exposure_amount: {v}") from exc

def load_taxonomy() -> List[Dict[str,Any]]:
    out=[]; seen:Set[str]=set()
    for row in _read_csv(TAXONOMY_PATH):
        sid=str(row.get("sector_id") or "").strip()
        l2=str(row.get("l2_name") or "").strip()
        l3=str(row.get("l3_name") or "").strip()
        if not sid or not l2 or not l3: raise PortfolioSelectionError("Taxonomy rows require sector_id, l2_name and l3_name.")
        if sid in seen: raise PortfolioSelectionError(f"Duplicate sector_id in taxonomy: {sid}")
        seen.add(sid)
        if not _truthy(row.get("active","true")): continue
        out.append({"id":sid,"sector_id":sid,"l2_name":l2,"l3_name":l3,"name":l3,
                    "path":str(row.get("display_path") or f"{l2} / {l3}").strip(),"active":True})
    if not out: raise PortfolioSelectionError("Step 2.2 taxonomy contains no active rows.")
    return out

def _normalize_company(row: Dict[str,Any], source: str) -> Dict[str,Any]:
    cagid=str(row.get("cagid") or "").strip()
    company=str(row.get("company_name") or "").strip()
    sid=str(row.get("sector_id") or "").strip()
    if not cagid and not company: raise PortfolioSelectionError("Each company row requires cagid or company_name.")
    if not sid: raise PortfolioSelectionError(f"Company row '{cagid or company}' requires sector_id.")
    return {"cagid":cagid,"company_name":company,"mle":str(row.get("mle") or "").strip(),
            "sector_id":sid,"l2_name":str(row.get("l2_name") or "").strip(),
            "l3_name":str(row.get("l3_name") or "").strip(),"country":str(row.get("country") or "").strip(),
            "legal_entity":str(row.get("legal_entity") or "").strip(),"exposure_amount":_number(row.get("exposure_amount")),
            "exposure_currency":str(row.get("exposure_currency") or "").strip(),"source":source}

def load_company_master() -> List[Dict[str,Any]]:
    out=[]
    for row in _read_csv(COMPANY_MASTER_PATH):
        if not any(str(v or "").strip() for v in row.values()): continue
        if str(row.get("active") or "").strip() and not _truthy(row.get("active")): continue
        out.append(_normalize_company(row,"MASTER"))
    return out

def get_catalog() -> Dict[str,Any]:
    tax=load_taxonomy(); companies=load_company_master(); counts={}
    for c in companies: counts[c["sector_id"]]=counts.get(c["sector_id"],0)+1
    for t in tax: t["company_count"]=counts.get(t["sector_id"],0)
    groups={}
    for t in tax: groups.setdefault(t["l2_name"],[]).append(t)
    return {"state":"REFERENCE_DATA","selection_mode":"DETERMINISTIC","llm_membership":False,
            "taxonomy":tax,"hierarchy":[{"l2_name":k,"l3":sorted(v,key=lambda x:x["l3_name"])} for k,v in sorted(groups.items())],
            "company_master_count":len(companies)}

def preview_selection(selected_sector_ids: Iterable[str], selected_l2_names: Optional[Iterable[str]]=None) -> Dict[str,Any]:
    tax=load_taxonomy(); companies=load_company_master()
    valid={t["sector_id"] for t in tax}
    ids={str(x).strip() for x in (selected_sector_ids or []) if str(x).strip()}
    l2s={str(x).strip() for x in (selected_l2_names or []) if str(x).strip()}
    unknown=sorted(ids-valid)
    if unknown: raise PortfolioSelectionError("Unknown sector_id(s): "+", ".join(unknown))
    if l2s: ids |= {t["sector_id"] for t in tax if t["l2_name"] in l2s}
    selected=[t for t in tax if t["sector_id"] in ids]
    matched=[c for c in companies if c["sector_id"] in ids]
    by_ccy={}
    for c in matched:
        if c["exposure_amount"] is not None and c["exposure_currency"]:
            cur=c["exposure_currency"]; by_ccy[cur]=round(by_ccy.get(cur,0.0)+c["exposure_amount"],2)
    return {"state":"SELECTION_PREVIEW","selection_mode":"FILTER","selected_sector_ids":sorted(ids),
            "selected_sectors":selected,"companies":matched,"company_count":len(matched),"exposure_by_currency":by_ccy}

def parse_uploaded_portfolio(filename: str, content: bytes) -> Dict[str,Any]:
    if not filename.lower().endswith(".csv"): raise PortfolioSelectionError("Step 2.2 portfolio upload currently accepts CSV only.")
    if len(content)>MAX_UPLOAD_BYTES: raise PortfolioSelectionError("Portfolio CSV exceeds the 5 MB limit.")
    try: text=content.decode("utf-8-sig")
    except UnicodeDecodeError as exc: raise PortfolioSelectionError("Portfolio CSV must be UTF-8 encoded.") from exc
    reader=csv.DictReader(io.StringIO(text)); cols=set(reader.fieldnames or [])
    missing=sorted(REQUIRED_UPLOAD_COLUMNS-cols)
    if missing: raise PortfolioSelectionError("Portfolio CSV missing required column(s): "+", ".join(missing))
    tax={t["sector_id"]:t for t in load_taxonomy()}; rows=[]
    for line,row in enumerate(reader,start=2):
        if not any(str(v or "").strip() for v in row.values()): continue
        item=_normalize_company(row,"UPLOAD")
        if item["sector_id"] not in tax: raise PortfolioSelectionError(f"Line {line}: unknown sector_id '{item['sector_id']}'.")
        item["l2_name"]=tax[item["sector_id"]]["l2_name"]; item["l3_name"]=tax[item["sector_id"]]["l3_name"]
        rows.append(item)
    if not rows: raise PortfolioSelectionError("Portfolio CSV contains no data rows.")
    return {"state":"UPLOAD_PREVIEW","selection_mode":"UPLOAD","filename":filename,"rows":rows,
            "company_count":len(rows),"selected_sector_ids":sorted({r["sector_id"] for r in rows})}

def finalize_portfolio_selection(payload: Dict[str,Any]) -> Dict[str,Any]:
    mode=str(payload.get("selection_mode") or "").upper()
    if mode=="FILTER":
        p=preview_selection(payload.get("selected_sector_ids") or [],payload.get("selected_l2_names") or [])
    elif mode=="UPLOAD":
        rows=payload.get("rows")
        if not isinstance(rows,list) or not rows: raise PortfolioSelectionError("Uploaded portfolio rows are required for confirmation.")
        tax={t["sector_id"]:t for t in load_taxonomy()}; normalized=[]
        for row in rows:
            item=_normalize_company(row,"UPLOAD")
            if item["sector_id"] not in tax: raise PortfolioSelectionError(f"Unknown sector_id '{item['sector_id']}'.")
            item["l2_name"]=tax[item["sector_id"]]["l2_name"]; item["l3_name"]=tax[item["sector_id"]]["l3_name"]
            normalized.append(item)
        ids=sorted({r["sector_id"] for r in normalized})
        p={"selection_mode":"UPLOAD","selected_sector_ids":ids,"selected_sectors":[tax[i] for i in ids],
           "companies":normalized,"company_count":len(normalized),"exposure_by_currency":{}}
    else: raise PortfolioSelectionError("selection_mode must be FILTER or UPLOAD.")
    if not p["selected_sector_ids"]: raise PortfolioSelectionError("At least one portfolio sector must be selected.")
    return {**p,"state":"CONFIRMED","confirmed_for_downstream":True,
            "confirmation_method":"DETERMINISTIC_PORTFOLIO_SELECTION","llm_membership":False}
