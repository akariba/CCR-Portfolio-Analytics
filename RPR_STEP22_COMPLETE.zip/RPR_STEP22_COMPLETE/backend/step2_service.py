"""Governed Step 2.1 / Step 2.3 service for RPR.

Additive by design: this module does not replace the current RPRService until live tests pass.
"""
from __future__ import annotations

import json
import logging
import os
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

from llm_gateway import get_gateway

log = logging.getLogger("uvicorn.error")
PROMPT_DIR = Path(__file__).resolve().parent / "prompts"
MODEL_SONNET = os.environ.get("STEP2_SONNET_MODEL", "claude-sonnet-4-6")
MODEL_OPUS = os.environ.get("STEP2_OPUS_MODEL", "claude-opus-4-6")
MODEL_REVISION = os.environ.get("STEP2_REVISION_MODEL", MODEL_OPUS)
_ASSUMPTION_DIRECTIONS = {"HEADWIND", "TAILWIND", "MIXED", "NEUTRAL"}
_IMPORTANCE_SCORE = {"HIGH": 2, "MEDIUM": 1}


class Step2Error(RuntimeError):
    pass


def _load_prompt(name: str) -> str:
    path = PROMPT_DIR / name
    if not path.exists():
        raise Step2Error(f"Required Step-2 prompt is missing: {path}")
    text = path.read_text(encoding="utf-8").strip()
    if not text:
        raise Step2Error(f"Required Step-2 prompt is empty: {path}")
    return text


def _gateway_for_model(model: str):
    gw = get_gateway()
    # Current R2D2LLMGateway stores model on the instance. Instance-level routing avoids
    # mutating process-wide R2D2_MODEL and therefore avoids cross-request model races.
    if hasattr(gw, "_model"):
        gw._model = model
    return gw


def _call_json(
    system_prompt: str,
    user_payload: Dict[str, Any],
    model: str,
    max_tokens: int = 5000,
    role: str = "step2",
) -> Dict[str, Any]:
    gw = _gateway_for_model(model)
    if not hasattr(gw, "call_raw"):
        raise Step2Error("Prompt-oriented Step-2 calls require the R2D2 gateway.")
    started = time.monotonic()
    log.info("[LLM] START provider=r2d2 model=%s role=%s scope=step2", model, role)
    try:
        result = gw.call_raw(
            system_prompt,
            json.dumps(user_payload, ensure_ascii=False, indent=2),
            max_tokens=max_tokens,
        )
    except Exception:
        duration_ms = int((time.monotonic() - started) * 1000)
        log.exception("[LLM] END provider=r2d2 model=%s role=%s scope=step2 status=FAILED duration_ms=%s", model, role, duration_ms)
        raise
    duration_ms = int((time.monotonic() - started) * 1000)
    log.info("[LLM] END provider=r2d2 model=%s role=%s scope=step2 status=SUCCESS duration_ms=%s", model, role, duration_ms)
    if not isinstance(result, dict):
        raise Step2Error("Step-2 model response must be a JSON object.")
    result.setdefault("model_path", model)
    result.setdefault("models_triggered", [{"provider": "r2d2", "model": model, "role": role}])
    return result


def _compact_step1(step1: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(step1, dict) or not step1:
        raise Step2Error("Confirmed Step-1 payload is required.")
    keep: Dict[str, Any] = {}
    keys = (
        "event_overview", "event_history", "direct_impact_geographies",
        "contagion_impact_geographies", "contagious_impact_geographies",
        "equity_market_impact", "credit_market_impact", "commodity_market_impact",
        "assumptions", "scenario_label", "event_summary", "history", "direct_impact",
        "contagion_impact", "equity_impact", "credit_impact", "commodity_impact",
        "machine_payload", "analyst_state", "trigger", "theme", "event",
    )
    for key in keys:
        if key in step1:
            keep[key] = step1[key]
    return keep or dict(step1)


def _clean_uploads(uploaded_contexts: Optional[List[Dict[str, Any]]]) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    for item in uploaded_contexts or []:
        if not isinstance(item, dict):
            continue
        text = str(item.get("extracted_text") or item.get("text") or "").strip()
        status = str(item.get("extraction_status") or "SUCCESS").upper()
        if status != "SUCCESS" or not text:
            continue
        out.append({
            "file_name": str(item.get("file_name") or "uploaded_context"),
            "file_type": str(item.get("file_type") or ""),
            "size_bytes": item.get("size_bytes"),
            "sha256": item.get("sha256"),
            "extracted_text": text[:16000],
            "page_or_sheet_refs": item.get("page_or_sheet_refs") or [],
            "warnings": item.get("warnings") or [],
        })
    return out


def assess_optional_context(
    confirmed_step1: Dict[str, Any],
    horizon: str,
    typed_context: str = "",
    uploaded_contexts: Optional[List[Dict[str, Any]]] = None,
) -> Dict[str, Any]:
    step1 = _compact_step1(confirmed_step1)
    horizon = str(horizon or "").strip()
    if not horizon:
        raise Step2Error("Assessment horizon is required.")

    typed = str(typed_context or "").strip()
    uploads = _clean_uploads(uploaded_contexts)

    # Default path requested by business: Step 1 + horizon only. No unnecessary extra call.
    if not typed and not uploads:
        return {
            "overall_decision": "STEP1_HORIZON_ONLY",
            "typed_context": {"status": "NOT_PROVIDED", "role": None, "reason": "No typed context provided.", "usable_items": [], "excluded_items": []},
            "uploaded_contexts": [], "conflicts": [], "curated_context": [], "limitations": [],
            "assessor_bypassed": True,
        }

    usable_uploads: List[Dict[str, Any]] = []
    preexcluded: List[Dict[str, Any]] = []
    for upload in uploads:
        if len(upload["extracted_text"]) < 40:
            preexcluded.append({
                "file_name": upload["file_name"], "status": "INSUFFICIENT_QUALITY",
                "reason": "Extracted content is too short to provide meaningful scenario context.",
                "usable_items": [], "excluded_items": [{"text": upload["extracted_text"], "reason": "Too little usable content."}],
            })
        else:
            usable_uploads.append(upload)

    if not typed and not usable_uploads:
        return {
            "overall_decision": "STEP1_HORIZON_ONLY",
            "typed_context": {"status": "NOT_PROVIDED", "role": None, "reason": "No typed context provided.", "usable_items": [], "excluded_items": []},
            "uploaded_contexts": preexcluded, "conflicts": [], "curated_context": [],
            "limitations": ["Optional uploaded context was not strong enough to use."],
            "assessor_bypassed": True,
        }

    payload = {
        "CONFIRMED_STEP1": step1,
        "ASSESSMENT_HORIZON": horizon,
        "TYPED_CONTEXT": typed or None,
        "UPLOADED_CONTEXTS": usable_uploads,
    }
    try:
        result = _call_json(_load_prompt("step2_context_assessor.txt"), payload, MODEL_SONNET, max_tokens=4500, role="step2_context_assessment")
    except Exception as exc:
        # Quality-preserving fallback: optional context can fail without degrading the strong anchor.
        return {
            "overall_decision": "STEP1_HORIZON_ONLY",
            "typed_context": {
                "status": "INSUFFICIENT_QUALITY" if typed else "NOT_PROVIDED", "role": None,
                "reason": "Optional-context assessment did not complete; context was not applied.",
                "usable_items": [], "excluded_items": [],
            },
            "uploaded_contexts": preexcluded + [{
                "file_name": u["file_name"], "status": "INSUFFICIENT_QUALITY",
                "reason": "Optional-context assessment did not complete; file was not applied.",
                "usable_items": [], "excluded_items": [],
            } for u in usable_uploads],
            "conflicts": [], "curated_context": [],
            "limitations": [f"Context assessor fallback used: {type(exc).__name__}"],
            "assessor_bypassed": False, "assessor_fallback": True,
        }

    if not isinstance(result.get("curated_context"), list):
        result["curated_context"] = []
    result["uploaded_contexts"] = (result.get("uploaded_contexts") or []) + preexcluded
    result["assessor_bypassed"] = False
    return result


def _validate_scenario(result: Dict[str, Any], horizon: str) -> Dict[str, Any]:
    narrative = str(result.get("scenario_narrative") or "").strip()
    assumptions = result.get("assumptions")
    if not narrative:
        raise Step2Error("Scenario response is missing scenario_narrative.")
    if not isinstance(assumptions, list) or not (4 <= len(assumptions) <= 7):
        raise Step2Error("Scenario must contain 4-7 assumptions.")

    normalized = []
    for i, assumption in enumerate(assumptions, start=1):
        if not isinstance(assumption, dict):
            raise Step2Error(f"Assumption {i} is not an object.")
        a = dict(assumption)
        a["code"] = str(a.get("code") or f"A{i}")
        a["type"] = str(a.get("type") or "Other")
        a["quantified_or_bounded_value"] = str(a.get("quantified_or_bounded_value") or a.get("value") or "")
        a["rationale"] = str(a.get("rationale") or "")
        a["horizon"] = str(a.get("horizon") or horizon)
        direction = str(a.get("direction") or "MIXED").upper()
        a["direction"] = direction if direction in _ASSUMPTION_DIRECTIONS else "MIXED"
        a["origin"] = str(a.get("origin") or "SYNTHESIZED_FROM_ACCEPTED_INPUTS")
        a["source_reference"] = a.get("source_reference")
        confidence = str(a.get("confidence") or "MEDIUM").upper()
        a["confidence"] = confidence if confidence in {"HIGH", "MEDIUM", "LOW"} else "MEDIUM"
        a["observed_vs_assumed"] = "ASSUMPTION"
        normalized.append(a)

    result["scenario_narrative"] = narrative
    result["assessment_horizon"] = str(result.get("assessment_horizon") or horizon)
    result["assumptions"] = normalized
    result.setdefault("structural_headwinds", [])
    result.setdefault("structural_tailwinds_or_adaptations", [])
    result.setdefault("beneficiary_or_resilient_segments", [])
    result.setdefault("limitations", [])
    return result


def generate_scenario(
    confirmed_step1: Dict[str, Any], horizon: str, typed_context: str = "",
    uploaded_contexts: Optional[List[Dict[str, Any]]] = None,
) -> Dict[str, Any]:
    step1 = _compact_step1(confirmed_step1)
    horizon = str(horizon or "").strip()
    if not horizon:
        raise Step2Error("Assessment horizon is required.")
    context_assessment = assess_optional_context(step1, horizon, typed_context, uploaded_contexts)
    payload = {
        "CONFIRMED_STEP1": step1,
        "ASSESSMENT_HORIZON": horizon,
        "CURATED_OPTIONAL_CONTEXT": context_assessment.get("curated_context") or [],
        "CONTEXT_LIMITATIONS": context_assessment.get("limitations") or [],
    }
    result = _call_json(_load_prompt("step2_scenario.txt"), payload, MODEL_OPUS, max_tokens=6000, role="step2_scenario_generation")
    result = _validate_scenario(result, horizon)
    result["context_assessment"] = context_assessment
    result["model_path"] = MODEL_OPUS
    result["prompt_version"] = "step2_scenario_v1"
    result["state"] = "AI_PROPOSAL"
    return result


def assist_feedback(
    confirmed_step1: Dict[str, Any], horizon: str, current_scenario: Dict[str, Any], feedback: str,
) -> Dict[str, Any]:
    text = str(feedback or "").strip()
    if not text:
        raise Step2Error("Feedback is required.")
    payload = {
        "CONFIRMED_STEP1": _compact_step1(confirmed_step1),
        "ASSESSMENT_HORIZON": str(horizon or "").strip(),
        "CURRENT_SCENARIO": current_scenario,
        "ANALYST_FEEDBACK": text,
    }
    result = _call_json(_load_prompt("step2_feedback_assistant.txt"), payload, MODEL_SONNET, max_tokens=2500, role="step2_feedback_assistant")
    decision = str(result.get("decision") or "NEEDS_REFINEMENT").upper()
    if decision not in {"READY", "NEEDS_REFINEMENT", "OFF_CONTEXT", "CONFLICT_REQUIRES_CLARIFICATION"}:
        decision = "NEEDS_REFINEMENT"
    result["decision"] = decision
    result["preserve_unaffected_content"] = True
    return result


def revise_scenario(
    confirmed_step1: Dict[str, Any], horizon: str, base_scenario: Dict[str, Any],
    confirmed_feedback: str, accepted_context: Optional[List[Dict[str, Any]]] = None,
) -> Dict[str, Any]:
    feedback = str(confirmed_feedback or "").strip()
    if not feedback:
        raise Step2Error("Confirmed feedback is required.")
    payload = {
        "CONFIRMED_STEP1": _compact_step1(confirmed_step1),
        "ASSESSMENT_HORIZON": str(horizon or "").strip(),
        "BASE_SCENARIO": str(base_scenario.get("scenario_narrative") or ""),
        "BASE_ASSUMPTIONS": base_scenario.get("assumptions") or [],
        "ACCEPTED_CONTEXT": accepted_context or ((base_scenario.get("context_assessment") or {}).get("curated_context") or []),
        "CONFIRMED_FEEDBACK": feedback,
    }
    result = _call_json(_load_prompt("step2_scenario_revision.txt"), payload, MODEL_REVISION, max_tokens=5000, role="step2_scenario_revision")
    result = _validate_scenario(result, str(horizon or ""))
    result.setdefault("revision", {})
    result["revision"]["feedback_applied"] = feedback
    result["model_path"] = MODEL_REVISION
    result["prompt_version"] = "step2_scenario_revision_v2_fast"
    result["state"] = "AI_REVISION"
    return result


def finalize_scenario(scenario: Dict[str, Any], analyst_modified_fields: Optional[List[str]] = None) -> Dict[str, Any]:
    """Deterministic confirmation gate: no LLM call."""
    horizon = str(scenario.get("assessment_horizon") or "").strip()
    validated = _validate_scenario(dict(scenario), horizon)
    validated["state"] = "CONFIRMED"
    validated["analyst_modified_fields"] = sorted(set(analyst_modified_fields or []))
    validated["confirmed_for_downstream"] = True
    return validated


def _normalize_metric(metric: Dict[str, Any], band_names: List[str], factor_id: str, kind: str) -> Dict[str, Any]:
    if not isinstance(metric, dict):
        raise Step2Error(f"{factor_id} {kind} metric must be an object.")
    name = str(metric.get("metric") or "").strip()
    if not name:
        raise Step2Error(f"{factor_id} {kind} metric is missing metric name.")
    bands = metric.get("bands")
    if not isinstance(bands, dict):
        raise Step2Error(f"{factor_id} {kind} metric '{name}' is missing bands.")
    missing = [band for band in band_names if not str(bands.get(band) or "").strip()]
    if missing:
        raise Step2Error(f"{factor_id} {kind} metric '{name}' is missing bands: {', '.join(missing)}.")
    status = str(metric.get("calibration_status") or "REQUIRES_METHODOLOGY_REVIEW").upper()
    if status not in {"SUPPORTED", "REQUIRES_METHODOLOGY_REVIEW"}:
        status = "REQUIRES_METHODOLOGY_REVIEW"
    return {
        **metric,
        "metric": name,
        "formula": metric.get("formula"),
        "unit": metric.get("unit"),
        "bands": {band: str(bands.get(band) or "").strip() for band in band_names},
        "calibration_status": status,
    }


def _normalize_event_factors(result: Dict[str, Any]) -> Dict[str, Any]:
    """Deterministic Step 2.3 validation and weighting.

    LLM proposes the methodology content. Python validates structural governance,
    assigns the approved importance score, calculates weights, and owns confirmation.
    """
    factors = result.get("factors")
    if not isinstance(factors, list) or not (4 <= len(factors) <= 6):
        raise Step2Error("Step 2.3 must return 4-6 event-driven factors.")

    factor_ids = set()
    scores: List[int] = []
    calibration_review_items: List[str] = []

    for i, factor in enumerate(factors, start=1):
        if not isinstance(factor, dict):
            raise Step2Error(f"Risk factor {i} is not an object.")

        factor_id = str(factor.get("factor_id") or f"RF{i}").strip()
        if factor_id in factor_ids:
            raise Step2Error(f"Duplicate Step 2.3 factor_id: {factor_id}.")
        factor_ids.add(factor_id)
        factor["factor_id"] = factor_id

        factor["name"] = str(factor.get("name") or "").strip()
        if not factor["name"]:
            raise Step2Error(f"{factor_id} is missing factor name.")
        factor["one_line_rationale"] = str(factor.get("one_line_rationale") or "").strip()
        factor["narrative"] = str(factor.get("narrative") or "").strip()
        if not factor["narrative"]:
            raise Step2Error(f"{factor_id} is missing factor narrative.")

        importance = str(factor.get("importance") or "").upper()
        if importance not in _IMPORTANCE_SCORE:
            raise Step2Error(f"{factor_id} importance must be HIGH or MEDIUM.")
        factor["importance"] = importance
        factor["importance_score"] = _IMPORTANCE_SCORE[importance]
        scores.append(_IMPORTANCE_SCORE[importance])

        vuln = factor.get("vulnerability_metrics")
        if not isinstance(vuln, list) or not (2 <= len(vuln) <= 4):
            raise Step2Error(f"{factor_id} must contain 2-4 vulnerability metrics.")
        factor["vulnerability_metrics"] = [
            _normalize_metric(m, ["VERY_HIGH", "HIGH", "MODERATE", "LOW"], factor_id, "vulnerability")
            for m in vuln
        ]

        buffers = factor.get("buffer_metrics")
        if not isinstance(buffers, list) or not (1 <= len(buffers) <= 3):
            raise Step2Error(f"{factor_id} must contain 1-3 durable buffer metrics.")
        factor["buffer_metrics"] = [
            _normalize_metric(m, ["STRONG", "MODERATE", "WEAK", "NEGLIGIBLE"], factor_id, "buffer")
            for m in buffers
        ]

        for metric in factor["vulnerability_metrics"] + factor["buffer_metrics"]:
            if metric["calibration_status"] == "REQUIRES_METHODOLOGY_REVIEW":
                calibration_review_items.append(f"{factor_id}: {metric['metric']}")

        threshold = factor.get("critical_threshold") or {}
        conditions = threshold.get("conditions") if isinstance(threshold, dict) else None
        if not isinstance(conditions, list) or len(conditions) < 2:
            raise Step2Error(f"{factor_id} critical threshold must use at least two AND conditions.")
        clean_conditions = [str(x).strip() for x in conditions if str(x).strip()]
        if len(clean_conditions) < 2:
            raise Step2Error(f"{factor_id} critical threshold must contain at least two non-empty AND conditions.")
        factor["critical_threshold"] = {"logic": "AND", "conditions": clean_conditions}
        factor["scoring_rationale"] = str(factor.get("scoring_rationale") or "").strip()

    total = sum(scores)
    weights = [round(100.0 * score / total, 2) for score in scores]
    weights[-1] = round(weights[-1] + (100.0 - sum(weights)), 2)
    for factor, weight in zip(factors, weights):
        factor["weight_pct"] = weight

    sensitivity = result.get("industry_sensitivity")
    if not isinstance(sensitivity, list):
        sensitivity = []
    normalized_sensitivity = []
    for item in sensitivity:
        if not isinstance(item, dict):
            continue
        item_type = str(item.get("type") or "").upper()
        if item_type not in {"ADVERSE", "RESILIENT", "BENEFICIARY"}:
            item_type = "ADVERSE"
        refs = [str(x) for x in (item.get("critical_factor_ids") or []) if str(x) in factor_ids]
        normalized_sensitivity.append({
            "segment": str(item.get("segment") or "").strip(),
            "type": item_type,
            "critical_factor_ids": refs,
            "differential_sensitivity": str(item.get("differential_sensitivity") or "").strip(),
        })

    limitations = result.get("methodology_limitations")
    if not isinstance(limitations, list):
        limitations = []
    limitations = [str(x).strip() for x in limitations if str(x).strip()]
    if calibration_review_items:
        limitations.append(
            "Methodology calibration review required for: " + "; ".join(calibration_review_items)
        )

    result["factors"] = factors
    result["industry_sensitivity"] = normalized_sensitivity
    result["methodology_limitations"] = limitations
    result["weight_method"] = "DETERMINISTIC_IMPORTANCE_NORMALIZATION"
    result["importance_mapping"] = {"HIGH": 2, "MEDIUM": 1}
    result["weights_sum_pct"] = round(sum(f["weight_pct"] for f in factors), 2)
    result["validation"] = {
        "factor_count_valid": 4 <= len(factors) <= 6,
        "weights_sum_100": abs(result["weights_sum_pct"] - 100.0) < 0.001,
        "critical_threshold_rule": "AT_LEAST_2_CONDITIONS_AND",
        "calibration_review_count": len(calibration_review_items),
    }
    result["state"] = "AI_PROPOSAL"
    return result


def generate_event_factors(
    confirmed_step1: Dict[str, Any], confirmed_scenario: Dict[str, Any], sector: str,
    portfolio_context: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    if not confirmed_scenario.get("confirmed_for_downstream") and str(confirmed_scenario.get("state") or "").upper() != "CONFIRMED":
        raise Step2Error("Step 2.3 requires a confirmed Step-2.1 scenario.")
    sector = str(sector or "").strip()
    if not sector:
        raise Step2Error("Selected sector is required for Step 2.3.")

    portfolio_context = portfolio_context or {}
    payload = {
        "CONFIRMED_STEP1": _compact_step1(confirmed_step1),
        "CONFIRMED_STEP2_SCENARIO": confirmed_scenario.get("scenario_narrative"),
        "CONFIRMED_STEP2_ASSUMPTIONS": confirmed_scenario.get("assumptions") or [],
        "SELECTED_SECTOR": sector,
        "PORTFOLIO_CONTEXT": portfolio_context,
    }
    result = _call_json(
        _load_prompt("step2_event_factors.txt"),
        payload,
        MODEL_OPUS,
        max_tokens=9000,
        role="step2_event_factor_generation",
    )
    result = _normalize_event_factors(result)
    result["sector"] = sector
    result["portfolio_context"] = portfolio_context
    result["model_path"] = MODEL_OPUS
    result["prompt_version"] = "step2_event_factors_v2"
    return result


def revise_event_factors(
    confirmed_step1: Dict[str, Any],
    confirmed_scenario: Dict[str, Any],
    sector: str,
    base_factors: Dict[str, Any],
    confirmed_feedback: str,
    portfolio_context: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Targeted Opus revision followed by deterministic validation/re-weighting."""
    if not confirmed_scenario.get("confirmed_for_downstream") and str(confirmed_scenario.get("state") or "").upper() != "CONFIRMED":
        raise Step2Error("Step 2.3 revision requires a confirmed Step-2.1 scenario.")
    sector = str(sector or "").strip()
    if not sector:
        raise Step2Error("Selected sector is required for Step 2.3 revision.")
    feedback = str(confirmed_feedback or "").strip()
    if not feedback:
        raise Step2Error("Confirmed feedback is required for Step 2.3 revision.")
    if not isinstance(base_factors, dict) or not isinstance(base_factors.get("factors"), list):
        raise Step2Error("Current event-driven factor framework is required.")
    if str(base_factors.get("state") or "").upper() == "CONFIRMED":
        # Confirmed state is never silently mutated. The caller must explicitly request a revision,
        # which produces a new AI_REVISION proposal that requires re-confirmation.
        base_factors = dict(base_factors)

    payload = {
        "CONFIRMED_STEP1": _compact_step1(confirmed_step1),
        "CONFIRMED_STEP2_SCENARIO": confirmed_scenario.get("scenario_narrative"),
        "CONFIRMED_STEP2_ASSUMPTIONS": confirmed_scenario.get("assumptions") or [],
        "SELECTED_SECTOR": sector,
        "PORTFOLIO_CONTEXT": portfolio_context or {},
        "CURRENT_EVENT_FACTOR_FRAMEWORK": base_factors,
        "CONFIRMED_FEEDBACK": feedback,
    }
    result = _call_json(
        _load_prompt("step2_event_factors_revision.txt"),
        payload,
        MODEL_OPUS,
        max_tokens=8000,
        role="step2_event_factor_revision",
    )
    result = _normalize_event_factors(result)
    result["sector"] = sector
    result["portfolio_context"] = portfolio_context or {}
    result["model_path"] = MODEL_OPUS
    result["prompt_version"] = "step2_event_factors_revision_v2"
    result["state"] = "AI_REVISION"
    result["revision"] = {
        "feedback_applied": feedback,
        "preserve_unaffected_content": True,
        "requires_reconfirmation": True,
    }
    return result


def finalize_event_factors(
    framework: Dict[str, Any],
    analyst_modified_fields: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """Deterministic Step 2.3 confirmation gate. No LLM call."""
    if not isinstance(framework, dict):
        raise Step2Error("Step 2.3 factor framework is required.")
    confirmed = _normalize_event_factors(dict(framework))
    confirmed["state"] = "CONFIRMED"
    confirmed["confirmed_for_downstream"] = True
    confirmed["analyst_modified_fields"] = sorted(set(analyst_modified_fields or []))
    confirmed["confirmation_method"] = "DETERMINISTIC_VALIDATION"
    return confirmed
