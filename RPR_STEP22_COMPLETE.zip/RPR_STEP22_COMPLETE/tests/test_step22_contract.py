import csv,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/"backend"))
import portfolio_selection_service as p

def test_catalog_hierarchy():
    d=p.get_catalog()
    assert d["selection_mode"]=="DETERMINISTIC" and d["llm_membership"] is False
    assert all(x["l2_name"] and x["l3_name"] for x in d["taxonomy"])

def test_l2_filters_children():
    d=p.get_catalog();l2=d["hierarchy"][0]["l2_name"]
    expected={x["sector_id"] for x in d["taxonomy"] if x["l2_name"]==l2}
    assert set(p.preview_selection([], [l2])["selected_sector_ids"])==expected

def test_no_fabricated_company_rows():
    assert p.load_company_master()==[]

def test_upload_template_contract():
    with (ROOT/"backend/data/portfolio_upload_template.csv").open() as f: header=next(csv.reader(f))
    assert p.REQUIRED_UPLOAD_COLUMNS.issubset(set(header))

def test_filter_confirmation_is_deterministic():
    sid=p.get_catalog()["taxonomy"][0]["sector_id"]
    d=p.finalize_portfolio_selection({"selection_mode":"FILTER","selected_sector_ids":[sid]})
    assert d["state"]=="CONFIRMED" and d["confirmed_for_downstream"] is True
    assert d["llm_membership"] is False
