import copy
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "backend"))

# Provide a tiny import stub only for the gateway module so deterministic functions can be imported.
# No model result is mocked and no runtime/demo output is fabricated.
import types
gw_mod = types.ModuleType("llm_gateway")
gw_mod.get_gateway = lambda: None
sys.modules.setdefault("llm_gateway", gw_mod)

from step2_service import _normalize_event_factors, finalize_event_factors, Step2Error


def framework():
    factors = []
    for i in range(4):
        factors.append({
            "factor_id": f"RF{i+1}",
            "name": f"Factor {i+1}",
            "importance": "HIGH" if i < 2 else "MEDIUM",
            "one_line_rationale": "Methodology rationale",
            "narrative": "Structural credit transmission and differentiation.",
            "vulnerability_metrics": [
                {"metric": "Metric A", "formula": None, "unit": "%", "calibration_status": "SUPPORTED",
                 "bands": {"VERY_HIGH": "a", "HIGH": "b", "MODERATE": "c", "LOW": "d"}},
                {"metric": "Metric B", "formula": None, "unit": None, "calibration_status": "REQUIRES_METHODOLOGY_REVIEW",
                 "bands": {"VERY_HIGH": "a", "HIGH": "b", "MODERATE": "c", "LOW": "d"}},
            ],
            "critical_threshold": {"logic": "AND", "conditions": ["cond 1", "cond 2"]},
            "buffer_metrics": [
                {"metric": "Buffer A", "formula": None, "unit": None, "calibration_status": "SUPPORTED",
                 "bands": {"STRONG": "a", "MODERATE": "b", "WEAK": "c", "NEGLIGIBLE": "d"}}
            ],
            "scoring_rationale": "Residual risk after durable mitigation."
        })
    return {"factors": factors, "industry_sensitivity": [], "methodology_limitations": []}


def test_weights_and_validation():
    d = _normalize_event_factors(framework())
    assert len(d["factors"]) == 4
    assert d["weights_sum_pct"] == 100.0
    assert d["validation"]["weights_sum_100"] is True
    assert all(f["critical_threshold"]["logic"] == "AND" for f in d["factors"])


def test_finalize_is_deterministic_confirmation():
    d = finalize_event_factors(framework(), ["RF1.narrative"])
    assert d["state"] == "CONFIRMED"
    assert d["confirmed_for_downstream"] is True
    assert d["confirmation_method"] == "DETERMINISTIC_VALIDATION"
    assert d["analyst_modified_fields"] == ["RF1.narrative"]


def test_rejects_single_condition_threshold():
    d = framework()
    d["factors"][0]["critical_threshold"]["conditions"] = ["only one"]
    try:
        _normalize_event_factors(d)
        assert False, "Expected Step2Error"
    except Step2Error:
        pass
