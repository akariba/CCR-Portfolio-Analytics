# Strict model, prompt, and timeout flow

## Trigger 1

1. Theme gate accepts a clearly STRONG theme locally; all other classifications
   reach Claude Sonnet for review and replacement suggestions.
2. Gemini 3.5 Flash plus `enterprise_web_search` discovers up to three events per
   accepted theme.
3. The parser accepts either flat `event_overview` or the prompt-compatible
   `sections` array and retains the raw sections.
4. Each event is independently enriched by Gemini and refined by Claude Opus.
5. Discovery allows 200 seconds; enrichment/refinement retain their configured
   strict production ceilings.

## Trigger 2 and Step 2.1

1. Gemini enterprise search retrieves evidence for all eight Step-1 sections.
2. Claude Opus refines only retrieved evidence and cannot search or add facts.
3. The browser permits 420 seconds for the two-stage operation; each backend stage
   permits 200 seconds.
4. Step 2.1 rejects any payload not explicitly confirmed by the analyst.
5. Optional context is evaluated by Claude Sonnet and cannot override Step 1.
6. Claude Opus generates the horizon-specific scenario and assumptions.
7. Generation permits 420 seconds and revision 240 seconds in the browser.
8. Step 2.3 remains blocked until Step 2.1 state is `CONFIRMED`.

The exact instructions passed to every model are under `backend/prompts/`.
