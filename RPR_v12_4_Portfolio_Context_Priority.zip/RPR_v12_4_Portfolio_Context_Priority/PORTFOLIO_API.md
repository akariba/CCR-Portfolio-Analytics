# RPR v12.4 portfolio backend

This backend accepts an approved internal portfolio extract and creates the
deterministic portfolio context used by the existing strict Step 2 flow. It does
not call an LLM, a public service, or a fallback data source.

## Accepted columns

Required:

- `rel_naics_ind_sector_l2_name`
- `rel_naics_ind_sector_l3_name`

Optional, but expected for a company exposure extract:

- `CAGID`
- `CAGID_NAME` or `Company Name`
- `Relationship_osuc` or `cre_osuc_amt`

Names are matched case-insensitively and common underscore/space variants are
accepted. CAGID is stored as text so leading zeroes are preserved.

## Endpoints

- `POST /api/v1/rpr/portfolio/upload` — multipart CSV, TSV, TXT, or XLSX upload.
- `POST /api/v1/rpr/portfolio/ingest` — JSON rows from an approved upstream adapter.
- `GET /api/v1/rpr/portfolio/datasets/{dataset_id}` — taxonomy and exposure summary.
- `POST /api/v1/rpr/portfolio/select` — filter by Level-2, Level-3, and/or CAGID.

The selection response contains `portfolio_context`. Pass that object unchanged
to the existing `POST /api/v1/rpr/step2/event-factors/generate` request.

## Audited workstation verification

After starting Uvicorn, open `http://127.0.0.1:8000/docs` and use
`POST /api/v1/rpr/portfolio/upload` with the Citihawk/Impala export.

Reconcile `company_count` and `relationship_osuc` to the source query, then call
`/select` using the returned `dataset_id`. The selection response contains the
chosen hierarchy, companies, exposure total, and ready-to-use portfolio context.

## Scope boundary

The package ingests an export or JSON result supplied by the approved internal
query layer. It does not embed credentials or establish a direct Impala session.
A direct connector requires the approved driver, authentication method, DSN/host,
and governed SQL contract from the audited environment.
