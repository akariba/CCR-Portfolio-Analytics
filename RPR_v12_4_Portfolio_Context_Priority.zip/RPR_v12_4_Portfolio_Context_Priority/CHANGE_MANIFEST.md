# RPR v12.4 portfolio context priority

## Step 2.1 analyst-context priority

- Valid typed context and uploaded assumptions are the highest-priority inputs,
  after consistency checking against confirmed Step 1 and the chosen horizon.
- Input precedence is explicit: accepted analyst context, confirmed Step 1,
  then bounded model inference.
- Accepted structured assumptions are preserved for Opus rather than silently
  rewritten or discarded.
- Added `GET /api/v1/rpr/step2/context/suggestions` for generic context prompts.
- Step 2.1 displays concise context suggestions inside the existing v31 layout.
- CSV and JSON assumption uploads are normalized into an auditable structure.
- Added editable CSV/JSON assumption templates and a context checklist under
  `samples/`. Unedited `Edit:` placeholders are ignored by the parser.
- No Trigger-1 rule, model route, feedback separation, or v31 styling changed.

## Preserved v12.3 portfolio backend

## Portfolio data backend

- Added `backend/portfolio_service.py` and `backend/portfolio_routes.py`.
- Accepts approved JSON, CSV, TSV, TXT, and XLSX portfolio extracts.
- Normalizes CAGID/company, Level-2, Level-3, and relationship OSUC.
- Preserves CAGID as text, including leading zeroes.
- Produces deterministic taxonomy, exposure summaries, selected companies, and
  a Step-2-ready `portfolio_context` without an LLM or fallback data.
- Repeated exposure rows are retained so equal facility amounts are not silently
  undercounted.
- Adds four routes under `/api/v1/rpr/portfolio` and portfolio identity to health.
- Backend version is `1.12.4`; all portfolio behavior remains unchanged.
- No frontend HTML, prompt, model route, Trigger-1 Bible rule, or feedback context
  was changed.

See `PORTFOLIO_API.md` for the endpoint and source-column contract.

## Corrected defects

- Trigger 1 now accepts both supported Gemini discovery shapes: a flat
  `event_overview` field and a `sections` array containing Event Overview.
- The original discovery `sections` array is retained in event metadata for audit
  and downstream inspection.
- Trigger-1 discovery timeout is aligned at 200 seconds in Python and PowerShell.
- Trigger-2 Gemini retrieval and Opus refinement timeouts are 200 seconds each.
- Trigger-2 accepts both timeout naming conventions: `RETRIEVAL/REFINEMENT` and
  the prior audited `SEARCH/OPUS` aliases.
- Browser Trigger-2 enrichment and re-enrichment limits are 420 seconds, preventing
  the UI from aborting before a valid backend completion.
- Step-2.1 generation and revision browser limits are 420 and 240 seconds.
- AI Assist retains the v12.1 correction: only unambiguous STRONG themes bypass
  Sonnet; weak, ambiguous, and off-domain themes reach Sonnet for replacements.

## Preserved strict controls

- Trigger 1 Bible rule: up to three events per accepted theme.
- Gemini 3.5 Flash plus enterprise web search for discovery/evidence.
- Claude Sonnet for quality/relevance gates and Claude Opus for applicable
  refinement, scenario, and factor work.
- Confirmed analyst content is never silently overwritten.
- Separate feedback contexts remain separate.
- v31 frontend visual baseline is preserved.
- No demo data, canned results, public-web fallback, or model downgrade.

## Known architectural limitation

The existing timeout reaper cannot forcibly cancel an underlying model thread.
This release raises the ceiling above observed live latency and does not redesign
that concurrency mechanism.
