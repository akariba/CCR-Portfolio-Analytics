import os
import sys
import unittest
from unittest.mock import patch

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "backend"))
sys.path.insert(0, ROOT)

import narrative_enricher as ne
import rpr_json_runtime as runtime
import step2_service as s2


def sections(prefix):
    return {name: f"{prefix} {name}" for name in ne.FIELDS}


CONFIRMED_STEP1 = {
    **sections("confirmed"),
    "analyst_state": {"confirmed": True},
}


SCENARIO = {
    "scenario_narrative": "A strict adverse scenario linked to the confirmed event.",
    "assessment_horizon": "12 months",
    "assumptions": [{"code": "A1", "quantified_or_bounded_value": "bounded stress", "rationale": "test"}],
}


class StrictPipelineTests(unittest.TestCase):
    def test_approved_gemini_adapter_envelope_is_unwrapped(self):
        async def approved_adapter(*args, **kwargs):
            return {"answer": '{"ok": true}', "model": "gemini-3.5-flash"}
        fake = type(sys)("rpr_search_agent")
        fake.run_web_search = approved_adapter
        with patch.dict(sys.modules, {"rpr_search_agent": fake}):
            result = runtime.call_gemini_search_json(role="evidence", scope="test", prompt="p", payload={}, timeout=5)
        self.assertEqual(result, {"ok": True})

    def test_trigger2_gemini_then_opus(self):
        retrieved = {**sections("gemini"), "search_queries": ["q"], "sources": [{"name": "Primary", "url": "https://approved.invalid/source"}]}
        refined = sections("opus")
        with patch.object(ne, "call_gemini_search_json", return_value=retrieved), patch.object(ne, "call_r2d2_json", return_value=refined):
            result = ne.enrich_narrative("A sufficiently detailed analyst narrative")
        self.assertEqual(result["event_overview"], "opus event_overview")
        self.assertEqual(len(result["models_triggered"]), 2)
        self.assertFalse(result["machine_payload"]["analyst_state"]["confirmed"])

    def test_trigger2_retains_gemini_when_opus_fails(self):
        retrieved = {**sections("gemini"), "search_queries": ["q"], "sources": []}
        with patch.object(ne, "call_gemini_search_json", return_value=retrieved), patch.object(ne, "call_r2d2_json", side_effect=TimeoutError("timeout")):
            result = ne.enrich_narrative("A sufficiently detailed analyst narrative")
        self.assertEqual(result["event_overview"], "gemini event_overview")
        self.assertEqual(result["enhancement_meta"]["refinement_status"], "FAILED_RETAINED_GEMINI")

    def test_step21_requires_explicit_step1_confirmation(self):
        with self.assertRaises(s2.Step2ValidationError):
            s2.generate_scenario({"event_overview": "not confirmed"}, "12 months", "", [])

    def test_step21_sonnet_then_opus(self):
        assessment = {"overall_decision": "ACCEPTED_CONTEXT", "curated_context": [{"source": "typed", "text": "accepted"}], "rejected_context": []}
        calls = [assessment, SCENARIO]
        with patch.object(s2, "call_r2d2_json", side_effect=calls) as mocked:
            result = s2.generate_scenario(CONFIRMED_STEP1, "12 months", "relevant optional context", [])
        self.assertEqual(mocked.call_count, 2)
        self.assertEqual(result["state"], "GENERATED")
        self.assertEqual([m["model"] for m in result["models_triggered"]], [s2.SONNET_MODEL, s2.OPUS_MODEL])

    def test_step21_marks_typed_context_as_highest_priority(self):
        assessment = {"overall_decision": "ACCEPTED_CONTEXT", "curated_context": [{"source": "typed_context", "text": "accepted"}], "rejected_context": []}
        with patch.object(s2, "call_r2d2_json", side_effect=[assessment, SCENARIO]) as mocked:
            result = s2.generate_scenario(CONFIRMED_STEP1, "12 months", "Prioritize named obligors", [])
        quality_payload = mocked.call_args_list[0].kwargs["payload"]
        opus_payload = mocked.call_args_list[1].kwargs["payload"]
        self.assertEqual(quality_payload["optional_context"][0]["priority"], "HIGHEST_ANALYST_INPUT")
        self.assertEqual(opus_payload["input_priority"][0], "ACCEPTED_ANALYST_CONTEXT")
        self.assertEqual(result["input_priority"][0], "ACCEPTED_ANALYST_CONTEXT")

    def test_csv_assumption_upload_is_structured_and_prioritized(self):
        csv_data = b"code,type,value,rationale,direction,confidence\nU1,Spread stress,75-125 bps,Analyst bound,UP,HIGH\n"
        extracted = s2.extract_context_bytes("assumptions.csv", "text/csv", csv_data)
        self.assertEqual(extracted["kind"], "assumption_upload")
        self.assertEqual(extracted["priority"], "HIGHEST_ANALYST_INPUT")
        self.assertEqual(extracted["assumptions"][0]["quantified_or_bounded_value"], "75-125 bps")

    def test_unedited_template_placeholders_are_not_imported_as_assumptions(self):
        json_data = b'{"assumptions":[{"code":"U1","value":"Edit: add a bound"}]}'
        extracted = s2.extract_context_bytes("template.json", "application/json", json_data)
        self.assertEqual(extracted["assumptions"], [])

    def test_accepted_structured_assumptions_are_preserved_for_opus(self):
        upload = s2.extract_context_bytes(
            "assumptions.json", "application/json",
            b'{"assumptions":[{"code":"U1","value":"Top five names lose 20% revenue","rationale":"analyst case"}]}'
        )
        assessment = {"overall_decision": "ACCEPTED_CONTEXT", "curated_context": [{"source": "assumptions.json", "text": "accepted"}], "rejected_context": []}
        with patch.object(s2, "call_r2d2_json", side_effect=[assessment, SCENARIO]) as mocked:
            s2.generate_scenario(CONFIRMED_STEP1, "12 months", "", [upload])
        curated = mocked.call_args_list[1].kwargs["payload"]["context_assessment"]["curated_context"]
        self.assertEqual(curated[0]["assumptions"][0]["code"], "U1")

    def test_step21_without_optional_context_calls_only_opus(self):
        with patch.object(s2, "call_r2d2_json", return_value=SCENARIO) as mocked:
            result = s2.generate_scenario(CONFIRMED_STEP1, "12 months", "", [])
        self.assertEqual(mocked.call_count, 1)
        self.assertEqual(result["context_assessment"]["overall_decision"], "STEP1_HORIZON_ONLY")

    def test_finalize_is_strict_and_sets_confirmed(self):
        result = s2.finalize_scenario(SCENARIO, ["scenario_narrative"])
        self.assertEqual(result["state"], "CONFIRMED")
        self.assertTrue(result["confirmation"]["analyst_confirmed"])
        with self.assertRaises(s2.Step2ValidationError):
            s2.finalize_scenario({**SCENARIO, "assumptions": []}, [])

    def test_event_factors_require_confirmed_step21(self):
        with self.assertRaises(s2.Step2ValidationError):
            s2.generate_event_factors(CONFIRMED_STEP1, {**SCENARIO, "state": "GENERATED"}, "Banks", {})

    def test_event_factor_weights_are_deterministic_and_sum_100(self):
        raw = {"factors": [
            {"name": "One", "importance": "HIGH"},
            {"name": "Two", "importance": "MEDIUM"},
            {"name": "Three", "importance": "LOW"},
        ]}
        with patch.object(s2, "call_r2d2_json", return_value=raw):
            result = s2.generate_event_factors(CONFIRMED_STEP1, {**SCENARIO, "state": "CONFIRMED"}, "Banks", {})
        self.assertEqual(result["weights_sum_pct"], 100)
        self.assertEqual([x["importance_score"] for x in result["factors"]], [3, 2, 1])


if __name__ == "__main__":
    unittest.main()
