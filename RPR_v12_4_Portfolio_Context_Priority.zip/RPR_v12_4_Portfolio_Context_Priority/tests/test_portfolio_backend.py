import csv
import io
import sys
import unittest
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "backend"))

import portfolio_service as service


class PortfolioBackendTests(unittest.TestCase):
    def setUp(self):
        self.rows = [
            {
                "CAGID": "00100",
                "CAGID_NAME": "JP Morgan",
                "REL_NAICS_IND_SECTOR_L2_NAME": "Banks",
                "REL_NAICS_IND_SECTOR_L3_NAME": "Banks - Major",
                "Relationship_osuc": "1,250.50",
            },
            {
                "CAGID": "00200",
                "CAGID_NAME": "Example Energy",
                "REL_NAICS_IND_SECTOR_L2_NAME": "Energy",
                "REL_NAICS_IND_SECTOR_L3_NAME": "Integrated Oil & Gas",
                "Relationship_osuc": "250",
            },
            {
                "CAGID": "00100",
                "CAGID_NAME": "JP Morgan",
                "REL_NAICS_IND_SECTOR_L2_NAME": "Banks",
                "REL_NAICS_IND_SECTOR_L3_NAME": "Banks - Major",
                "Relationship_osuc": "1,250.50",
            },
        ]

    def test_ingest_preserves_cagid_and_sums_all_exposure_rows(self):
        result = service.normalize_rows(self.rows, "impala-export")
        self.assertEqual(result["records"][0]["cagid"], "00100")
        self.assertEqual(result["portfolio_summary"]["relationship_osuc"], 2751.0)
        self.assertEqual(result["validation"]["exposure_rows"], 3)

    def test_select_returns_step2_portfolio_context(self):
        result = service.normalize_rows(self.rows, "impala-export")
        selected = service.select_portfolio(result["dataset_id"], l2_sectors=["Banks"])
        context = selected["portfolio_context"]
        self.assertEqual(context["company_count"], 1)
        self.assertEqual(context["relationship_osuc"], 2501.0)
        self.assertEqual(context["selected_sectors"], ["Banks - Major"])
        self.assertEqual(context["top_company_exposures"][0]["cagid"], "00100")

    def test_taxonomy_only_mapping_is_supported(self):
        rows = [
            {"rel_naics_ind_sector_l2_name": "Banks", "rel_naics_ind_sector_l3_name": "Banks - Intercompany"},
            {"rel_naics_ind_sector_l2_name": "Banks", "rel_naics_ind_sector_l3_name": "Banks - Major"},
        ]
        result = service.normalize_rows(rows, "taxonomy.xlsx")
        self.assertEqual(result["portfolio_summary"]["l2_sector_count"], 1)
        self.assertEqual(result["portfolio_summary"]["l3_sector_count"], 2)
        self.assertEqual(result["portfolio_summary"]["company_count"], 0)

    def test_csv_export_aliases_are_detected(self):
        stream = io.StringIO()
        writer = csv.DictWriter(stream, fieldnames=list(self.rows[0]))
        writer.writeheader()
        writer.writerows(self.rows[:2])
        parsed = service.parse_csv_bytes(stream.getvalue().encode(), "export.csv")
        result = service.normalize_rows(parsed, "export.csv")
        self.assertEqual(result["portfolio_summary"]["company_count"], 2)

    def test_invalid_exposure_fails_strictly(self):
        bad = [dict(self.rows[0], Relationship_osuc="not-a-number")]
        with self.assertRaisesRegex(service.PortfolioValidationError, "Invalid relationship OSUC"):
            service.normalize_rows(bad)

    def test_missing_sector_contract_fails_strictly(self):
        with self.assertRaisesRegex(service.PortfolioValidationError, "Required columns not found"):
            service.normalize_rows([{"CAGID": "1", "CAGID_NAME": "No sector"}])

    def test_minimal_xlsx_is_parsed_without_external_dependency(self):
        shared = ["CAGID", "Company Name", "rel_naics_ind_sector_l2_name", "rel_naics_ind_sector_l3_name", "Relationship_osuc", "0007", "Bank Seven", "Banks", "Banks - Major"]
        shared_xml = '<sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">' + ''.join(f'<si><t>{v}</t></si>' for v in shared) + '</sst>'
        workbook = '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Sheet1" sheetId="1" r:id="rId1"/></sheets></workbook>'
        rels = '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Target="worksheets/sheet1.xml" Type="x"/></Relationships>'
        sheet = '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData><row r="1">' + ''.join(f'<c r="{chr(65+i)}1" t="s"><v>{i}</v></c>' for i in range(5)) + '</row><row r="2"><c r="A2" t="s"><v>5</v></c><c r="B2" t="s"><v>6</v></c><c r="C2" t="s"><v>7</v></c><c r="D2" t="s"><v>8</v></c><c r="E2"><v>99.5</v></c></row></sheetData></worksheet>'
        buffer = io.BytesIO()
        with zipfile.ZipFile(buffer, "w") as zf:
            zf.writestr("xl/sharedStrings.xml", shared_xml)
            zf.writestr("xl/workbook.xml", workbook)
            zf.writestr("xl/_rels/workbook.xml.rels", rels)
            zf.writestr("xl/worksheets/sheet1.xml", sheet)
        rows = service.parse_xlsx_bytes(buffer.getvalue())
        result = service.normalize_rows(rows, "portfolio.xlsx")
        self.assertEqual(result["records"][0]["cagid"], "0007")
        self.assertEqual(result["portfolio_summary"]["relationship_osuc"], 99.5)


if __name__ == "__main__":
    unittest.main()
