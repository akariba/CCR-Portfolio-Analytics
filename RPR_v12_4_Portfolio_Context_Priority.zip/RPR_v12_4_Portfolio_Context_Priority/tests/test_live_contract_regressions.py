import contextlib
import importlib
import os
import sys
import types
import unittest
from pathlib import Path
from unittest.mock import patch


ROOT = Path(__file__).resolve().parents[1]
BACKEND = ROOT / "backend"
sys.path.insert(0, str(BACKEND))


@contextlib.contextmanager
def _span(**kwargs):
    yield types.SimpleNamespace(output_chars=0)


trace_stub = types.ModuleType("rpr_model_trace")
trace_stub.model_span = _span
quality_stub = types.ModuleType("step1_quality")
quality_stub.SECTION_TITLES = (
    "Event Overview",
    "Event History",
    "Direct Impact Geographies",
    "Contagious Impact Geographies",
    "Equity Market Impact",
    "Credit Market Impact",
    "Commodity Market Impact",
    "Assumptions",
)
quality_stub.assess_sections = lambda rows: []
quality_stub.build_machine_payload = lambda **kwargs: kwargs
quality_stub.overall_retrieval_status = lambda rows: "SUCCESS"
quality_stub.parse_sectioned_report = lambda value: {"sections": []}
quality_stub.select_improved_sections = lambda old, new, affected: (new, {})
quality_stub.strip_control_tags = lambda value: str(value or "").strip()
quality_stub.summarize_quality = lambda rows: {}

with patch.dict(sys.modules, {
    "rpr_model_trace": trace_stub,
    "step1_quality": quality_stub,
}):
    scout = importlib.import_module("market_event_scout")
    theme_assistant = importlib.import_module("theme_assistant_batch")

import narrative_enricher


class LiveContractRegressionTests(unittest.TestCase):
    def test_discovery_accepts_flat_event_overview(self):
        row = {"event_overview": "Flat overview", "sections": [{"num": 1, "text": "Section overview"}]}
        self.assertEqual(scout._discovery_overview(row), "Flat overview")

    def test_discovery_accepts_sections_event_overview(self):
        row = {
            "title": "Supported event",
            "sections": [
                {"num": 1, "title": "Event Overview", "text": "Supported section overview"},
                {"num": 2, "title": "Event History", "text": "History"},
            ],
        }
        self.assertEqual(scout._discovery_overview(row), "Supported section overview")

    def test_discover_events_retains_raw_sections(self):
        raw = """{
          "events": [{
            "title": "Supported event",
            "event_date": "2026-08-20",
            "sections": [{"num": 1, "title": "Event Overview", "text": "Supported section overview"}],
            "why_material": "Material",
            "confidence": "HIGH",
            "sources": [],
            "search_queries": []
          }]
        }"""
        instance = scout.MarketEventScout.__new__(scout.MarketEventScout)
        instance.fast_discovery_prompt = "PROMPT REQUESTED_EVENT_COUNT"
        with patch.object(scout, "_adk_search_sync", return_value=raw):
            rows = instance.discover_events_gemini({"theme": "Trade", "description": "Tariffs"}, max_events=3)
        self.assertEqual(rows[0]["event_overview"], "Supported section overview")
        self.assertEqual(rows[0]["raw_discovery_sections"][0]["num"], 1)

    def test_discovery_default_is_live_safe(self):
        self.assertGreaterEqual(scout.DISCOVERY_TIMEOUT, 200)

    def test_trigger2_uses_200_second_backend_timeouts(self):
        retrieved = {name: f"Gemini {name}" for name in narrative_enricher.FIELDS}
        refined = {name: f"Opus {name}" for name in narrative_enricher.FIELDS}
        with patch.object(narrative_enricher, "call_gemini_search_json", return_value=retrieved) as gemini, \
             patch.object(narrative_enricher, "call_r2d2_json", return_value=refined) as opus:
            narrative_enricher.enrich_narrative("A sufficiently detailed analyst narrative")
        self.assertEqual(gemini.call_args.kwargs["timeout"], 200)
        self.assertEqual(opus.call_args.kwargs["timeout"], 200)

    def test_trigger2_accepts_prior_audited_timeout_names(self):
        with patch.dict(os.environ, {
            "RPR_T2_SEARCH_TIMEOUT": "211",
            "RPR_T2_OPUS_TIMEOUT": "212",
        }, clear=True):
            self.assertEqual(narrative_enricher._timeout(
                "RPR_T2_RETRIEVAL_TIMEOUT", "RPR_T2_SEARCH_TIMEOUT"
            ), 211)
            self.assertEqual(narrative_enricher._timeout(
                "RPR_T2_REFINEMENT_TIMEOUT", "RPR_T2_OPUS_TIMEOUT"
            ), 212)

    def test_theme_assist_routes_off_domain_to_sonnet(self):
        response = {"results": [{
            "theme_index": 0,
            "classification": "OFF_DOMAIN",
            "reason": "Needs a credit-risk replacement.",
            "suggestions": ["Seasonal retail credit stress", "Travel-sector liquidity", "Holiday supply-chain pressure"],
        }]}
        with patch.object(theme_assistant, "_call_batch", return_value=response) as call:
            result = theme_assistant.assist_themes_batch([{"theme": "Holiday", "description": ""}])
        self.assertEqual(call.call_count, 1)
        self.assertEqual(result["results"][0]["suggestion_status"], "SUCCESS")
        self.assertEqual(len(result["results"][0]["suggestions"]), 3)

    def test_frontend_timeouts_cover_full_two_stage_calls(self):
        html = (ROOT / "frontend" / "rpr-v8-consolidated-test.html").read_text(encoding="utf-8")
        self.assertIn("ENRICH:420000", html)
        self.assertIn("REENRICH:420000", html)
        self.assertIn("uploaded_contexts:STEP2_UPLOADED_FILES},420000", html)
        self.assertIn("accepted_context:STEP2_SCENARIO.context_assessment?.curated_context||[]},240000", html)


if __name__ == "__main__":
    unittest.main()
