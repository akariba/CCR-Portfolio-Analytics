# RPR v10 progressive-per-theme runtime settings.
# This script does not contain, print or persist a token.

# Works both when dot-sourced and when corporate policy requires
# Get-Content .\RUNTIME_ENV.ps1 -Raw | Invoke-Expression from the project root.
$rprRoot = if ($PSScriptRoot) { $PSScriptRoot } else { (Get-Location).Path }
$pythonExe = Join-Path $rprRoot "portfolio-agent\.venv\Scripts\python.exe"
$backendDir = Join-Path $rprRoot "backend"

# Make project-root execution able to import the existing backend-owned llm_gateway.
# Preserve any corporate PYTHONPATH entries instead of overwriting them.
if (Test-Path $backendDir) {
    $env:PYTHONPATH = if ($env:PYTHONPATH) { "$backendDir;$env:PYTHONPATH" } else { $backendDir }
}

$env:RPR_GEMINI_MODEL = "gemini-3.5-flash"
$env:RPR_GEMINI_DISCOVERY_MODEL = "gemini-3.5-flash"
$env:RPR_GEMINI_EVIDENCE_MODEL = "gemini-3.5-flash"
$env:RPR_GEMINI_THEME_MODEL = "gemini-3.5-flash"
$env:RPR_GEMINI_LOCATION = "us"
$env:RPR_STEP1_REFINEMENT_MODEL = "claude-opus-4-6"
$env:STEP2_SONNET_MODEL = "claude-sonnet-4-6"
$env:STEP2_OPUS_MODEL = "claude-opus-4-6"
$env:RPR_FEEDBACK_MODEL = "claude-sonnet-4-6"
$env:RPR_THEME_GATE_MODEL = "claude-sonnet-4-6"

# Strict Trigger 2 and Step 2.1 model routing. All calls use the existing audited
# Gemini/R2D2 adapters; no direct internet or demo fallback is enabled.
$env:RPR_GEMINI_NARRATIVE_MODEL = "gemini-3.5-flash"
$env:RPR_TRIGGER2_OPUS_MODEL = "claude-opus-4-6"
$env:RPR_STEP2_SONNET_MODEL = "claude-sonnet-4-6"
$env:RPR_STEP2_OPUS_MODEL = "claude-opus-4-6"
$env:RPR_T2_RETRIEVAL_TIMEOUT = "200"
$env:RPR_T2_REFINEMENT_TIMEOUT = "200"
# Compatibility aliases used by the previous audited Trigger-2 implementation.
$env:RPR_T2_SEARCH_TIMEOUT = $env:RPR_T2_RETRIEVAL_TIMEOUT
$env:RPR_T2_OPUS_TIMEOUT = $env:RPR_T2_REFINEMENT_TIMEOUT
$env:RPR_T2_OPUS_MAX_TOKENS = "4200"
$env:RPR_T2_GEMINI_WORKERS = "2"
$env:RPR_T2_CLAUDE_WORKERS = "1"
$env:RPR_STEP2_SONNET_TIMEOUT = "75"
$env:RPR_STEP2_OPUS_TIMEOUT = "180"
$env:RPR_STEP2_OPUS_MAX_TOKENS = "4200"

# v11: each theme runs a fast discovery call that finds up to RPR_T1_MAX_EVENTS_PER_THEME
# distinct events (Bible rule: 3, not reduced for performance). Each discovered event then
# runs its own independent evidence-enrichment -> Opus-refinement pipeline in a dedicated
# background thread, so a theme's events progress at their own pace -- one event reaching
# "refined" never waits for its slower siblings. /market-events/fetch returns almost
# immediately with a job_id; a theme's events appear as soon as ITS OWN discovery call
# finishes, independent of any other theme still running.
$env:RPR_T1_THEME_WORKERS = "3"
$env:RPR_T1_OPUS_WORKERS = "2"
# Bible rule: up to 3 events per accepted theme. Discovery stays fast at this count because
# it only asks for a short overview + a few sources per event, never a full report -- do
# not lower this for performance reasons; see RPR_T1_DISCOVERY_TIMEOUT below instead if
# discovery latency needs tuning.
$env:RPR_T1_MAX_EVENTS_PER_THEME = "3"

# Fast-fail ceiling for the lean candidate-discovery call (title, date and one-sentence
# overview only, up to 3 events -- sources and eight-section evidence are retrieved by
# the later enrichment stage). These are SAFETY
# CEILINGS, not performance targets -- lowering them does not make model calls faster.
# Measured live execution: discovery ~126-174s (sometimes 159s+), enrichment
# ~109-138s/event, refinement ~122-150+s/event. Defaults below carry real
# headroom above that observed range.
$env:RPR_T1_DISCOVERY_TIMEOUT = "200"
$env:RPR_T1_ENRICHMENT_TIMEOUT = "150"
$env:RPR_T1_REFINEMENT_TIMEOUT = "180"
$env:RPR_T1_TARGETED_TIMEOUT = "90"
$env:RPR_T1_THEME_GATE_TIMEOUT = "45"
$env:RPR_T1_OPUS_MAX_TOKENS = "4200"
$env:RPR_T1_GEMINI_MAX_CHARS = "36000"
$env:RPR_T1_CACHE_SECONDS = "900"
$env:RPR_T1_JOB_TTL_SECONDS = "3600"
$env:RPR_HELIX_TOKEN_CACHE_SECONDS = "480"

# Deterministic CAGID/NAICS portfolio ingestion (no LLM and no public fallback).
$env:RPR_PORTFOLIO_MAX_ROWS = "25000"
$env:RPR_PORTFOLIO_TTL_SECONDS = "14400"
$env:RPR_PORTFOLIO_TOP_COMPANIES = "100"

# Canonical adapter names, bridged from the already-approved RPR environment.
$env:VERTEX_LOCATION = "us"
if ($env:VERTEX_PROJECT_ID -and -not $env:VERTEX_PROJECT) {
    $env:VERTEX_PROJECT = $env:VERTEX_PROJECT_ID
}

$candidateUrls = @(
    $env:RPR_VERTEX_BASE_URL,
    $env:R2D2_BASE_URL,
    $env:VERTEX_ENDPOINT,
    $env:BASE_VERTEX_URL,
    $env:R2D2_UAT_URL
)
$rawVertexUrl = $candidateUrls | Where-Object { $_ -and $_.Trim() } | Select-Object -First 1

# Read the existing non-secret gateway defaults through the backend import path. This
# works in a fresh PowerShell started at the project root and avoids the previous red
# ModuleNotFoundError plus endpointReady=False/projectReady=False state.
if (Test-Path $pythonExe) {
    $gatewayDefaults = & $pythonExe -c "from llm_gateway import R2D2LLMGateway; print(R2D2LLMGateway._UAT_URL); print(R2D2LLMGateway._GCP_PROJECT)"
    if ($LASTEXITCODE -eq 0 -and $gatewayDefaults) {
        if (-not $rawVertexUrl -and $gatewayDefaults.Count -ge 1) {
            $rawVertexUrl = ([string]$gatewayDefaults[0]).Trim()
        }
        if (-not $env:VERTEX_PROJECT -and -not $env:VERTEX_PROJECT_ID -and -not $env:R2D2_GCP_PROJECT -and $gatewayDefaults.Count -ge 2) {
            $env:VERTEX_PROJECT = ([string]$gatewayDefaults[1]).Trim()
        }
    }
}

if ($rawVertexUrl) {
    # google-genai appends /v1 itself. Remove an existing API-version suffix exactly once.
    $cleanVertexUrl = $rawVertexUrl.Trim().TrimEnd('/') -replace '/v1(?:alpha\d*|beta\d*)?$', ''
    $env:RPR_VERTEX_BASE_URL = $cleanVertexUrl.TrimEnd('/')
    $env:VERTEX_ENDPOINT = $env:RPR_VERTEX_BASE_URL
}

$endpointReady = [bool]$env:RPR_VERTEX_BASE_URL
$projectReady = [bool]($env:VERTEX_PROJECT -or $env:VERTEX_PROJECT_ID -or $env:R2D2_GCP_PROJECT)
Write-Host "RPR v12.4 strict runtime loaded. endpointReady=$endpointReady projectReady=$projectReady Gemini=$env:RPR_GEMINI_MODEL Sonnet=$env:RPR_STEP2_SONNET_MODEL Opus=$env:RPR_STEP2_OPUS_MODEL discoveryTimeout=$($env:RPR_T1_DISCOVERY_TIMEOUT)s maxEventsPerTheme=$env:RPR_T1_MAX_EVENTS_PER_THEME portfolioMaxRows=$env:RPR_PORTFOLIO_MAX_ROWS"
