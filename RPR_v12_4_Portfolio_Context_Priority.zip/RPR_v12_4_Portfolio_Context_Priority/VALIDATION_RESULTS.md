# RPR v12.4 validation results

Validated locally on 2026-08-20 without contacting public or company endpoints.

## Passed

- Python compile check for packaged backend and tests.
- 28/28 unit and contract tests.
- Frontend JavaScript parse check for every inline script.
- Trigger-1 flat `event_overview` parsing.
- Trigger-1 `sections[Event Overview].text` parsing and raw-section retention.
- Trigger-1 200-second default contract.
- Trigger-2 200-second retrieval/refinement backend contracts.
- Trigger-2 compatibility with the prior `SEARCH/OPUS` timeout names.
- AI Assist `Holiday` routing to Sonnet with three preserved suggestions.
- Existing strict Trigger-2, Step-2.1, finalization, and Step-2.3 gating tests.
- Typed analyst context marked and transmitted as highest priority.
- CSV assumption upload normalization and preservation through Opus payload.
- Unedited sample placeholders excluded from generated assumptions.
- Frontend 420-second enrichment/generation and 240-second revision contracts.
- Taxonomy-only workbook normalization.
- Impala-style CAGID/company/Level-2/Level-3/relationship-OSUC normalization.
- Leading-zero preservation and exposure aggregation without unsafe dedupe.
- CSV aliases, stdlib XLSX parsing, strict invalid-exposure rejection, and
  Step-2-ready portfolio selection context.

## Environment boundary

FastAPI is not installed in this packaging container, so the existing API server
was syntax-compiled but not started here. The new module uses the same FastAPI
router/upload pattern already used by the packaged Step 2 routes. Execute the live
route check in `INSTALL.txt` with the existing `portfolio-agent` environment.

## Live-test boundary

Company Gemini/R2D2 endpoints and the user's Helix session are unavailable in this
container. Model adapter boundaries were mocked; no fake runtime result is included.
Use the exact live sequence in `INSTALL.txt` on the audited workstation.
