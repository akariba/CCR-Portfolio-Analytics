"""Active Step-1 FastAPI backend for the RPR HTML prototype.

v11: Bible rule restored — each accepted theme supports up to
market_event_scout.MAX_EVENTS_PER_THEME (3) events, not 1. Discovery stays a single
fast Gemini call per theme (short overview + sources only, never a full report, so
asking for up to 3 distinct events in one call does not reintroduce v9's latency
problem). Once a theme's discovery call returns its (1-3) events, EACH event gets its
own independent background enrichment -> refinement pipeline thread. This is what
keeps the "first result" fast without capping the theme to fewer than 3 events: the
UI is never blocked waiting for all of a theme's events to finish enriching/refining
before it can show the theme's first discovered event, and a slow event never blocks
a faster sibling event's progress.

/market-events/fetch still returns almost immediately with a job_id. Each theme
discovery, and each individual event's enrichment/refinement, updates the shared job
result under _job_lock as soon as it changes — a poller always sees whatever has
completed so far. Opus and Gemini evidence-enrichment failures never remove or blank
an event a prior successful stage already produced.
"""
from __future__ import annotations

import copy
import hashlib
import json
import logging
import os
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional
import uuid

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

import market_event_scout as mes
from market_event_scout import MarketEventScout, THEME_WORKERS
from narrative_enricher import NarrativeEnrichError, enrich_narrative
from rpr_enhancement_routes import (
    enhancement_router,
    can_rescan,
    register_rescan_result,
)
from step1_quality import assess_sections, build_machine_payload, overall_retrieval_status, summarize_quality
from theme_assistant import assist_theme
from theme_assistant_batch import assist_themes_batch
from step2_routes import step2_router
from portfolio_routes import portfolio_router
from portfolio_service import runtime_info as portfolio_runtime_info
from rpr_feedback_routes import feedback_router

log = logging.getLogger("uvicorn.error")

app = FastAPI(
    title="ICM PM Rapid Portfolio Review — Backend",
    version="1.12.4",
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.include_router(enhancement_router)
app.include_router(step2_router)
app.include_router(portfolio_router)
app.include_router(feedback_router)

_scout = MarketEventScout()
_OPUS_MODEL_NAME = os.environ.get("RPR_STEP1_REFINEMENT_MODEL", "claude-opus-4-6")

_job_lock = threading.RLock()
# Sized comfortably above THEME_WORKERS so that submitting one discovery thread per theme,
# plus up to MAX_EVENTS_PER_THEME independent event-pipeline threads per theme once
# discovery lands, never queues on the pool itself - true API concurrency is still bounded
# by the global Gemini/Opus semaphores inside market_event_scout.py regardless of pool size.
_pipeline_executor = ThreadPoolExecutor(
    max_workers=max(6, THEME_WORKERS * (mes.MAX_EVENTS_PER_THEME + 1)),
    thread_name_prefix="rpr-step1-pipeline",
)
_jobs: Dict[str, Dict[str, Any]] = {}
_scan_cache: Dict[str, Dict[str, Any]] = {}
_cache_ttl_seconds = max(60, int(os.environ.get("RPR_T1_CACHE_SECONDS", "900")))
_job_ttl_seconds = max(900, int(os.environ.get("RPR_T1_JOB_TTL_SECONDS", "3600")))

_TERMINAL_DISCOVERY_STAGES = {"discovery_failed", "discovery_timeout", "discovered"}
_RETRYABLE_DISCOVERY_STAGES = {"discovery_failed", "discovery_timeout"}
# Per-event pipeline "hard" terminal stage - reaching this means nothing further will
# run automatically. "discovered"/"enriched" can ALSO be terminal-for-now if the next
# stage permanently failed/timed out; see _event_is_pending, which is the real source
# of truth for job completion (this set alone is not sufcient to determine that).
_EVENT_HARD_TERMINAL_STAGE = "refined"


class ThemeInput(BaseModel):
    theme: str
    description: str = ""
    # Stable per-theme identifier supplied by the frontend (its own theme row id). Used
    # to match a theme's status/events back to the correct UI row regardless of array
    # position - immune to blank rows being filtered out of the middle of the theme
    # list, which breaks any purely positional (theme_index) matching scheme.
    client_theme_id: str = ""


class FetchRequest(BaseModel):
    # `themes` is retained for backward compatibility with the current HTML/API callers.
    themes: List[str] = Field(default_factory=list)
    theme_inputs: List[ThemeInput] = Field(default_factory=list)
    max_events_per_theme: int = mes.MAX_EVENTS_PER_THEME
    bypass_cache: bool = False


class RefineRequest(BaseModel):
    event: Dict[str, Any]
    feedback: str
    affected_sections: List[str] = Field(default_factory=list)
    analyst_modified_sections: List[str] = Field(default_factory=list)


class EnrichRequest(BaseModel):
    narrative: str


class ThemeAssistRequest(BaseModel):
    theme: str
    description: str = ""


class ThemeAssistBatchRequest(BaseModel):
    themes: List[ThemeInput] = Field(default_factory=list)


class FinalizeStep1Request(BaseModel):
    trigger: str
    event: Dict[str, Any] = Field(default_factory=dict)
    sections: List[Dict[str, Any]] = Field(default_factory=list)
    base_machine_payload: Dict[str, Any] = Field(default_factory=dict)
    analyst_modified_sections: List[str] = Field(default_factory=list)


def _scan_key(theme_specs: List[Dict[str, str]]) -> str:
    payload = {
        "themes": [
            {
                "theme": str(item.get("theme") or "").strip().lower(),
                "description": str(item.get("description") or "").strip().lower(),
            }
            for item in theme_specs
        ],
        "discovery_model": os.environ.get("RPR_GEMINI_DISCOVERY_MODEL", "gemini-3.5-flash"),
        "evidence_model": os.environ.get("RPR_GEMINI_EVIDENCE_MODEL", "gemini-3.5-flash"),
        "opus_model": _OPUS_MODEL_NAME,
        "max_events_per_theme": mes.MAX_EVENTS_PER_THEME,
        "pipeline": "v11_progressive_per_event",
    }
    return hashlib.sha256(json.dumps(payload, sort_keys=True).encode("utf-8")).hexdigest()


def _prune_state() -> None:
    now = time.time()
    with _job_lock:
        for key in [key for key, value in _scan_cache.items() if now - float(value.get("stored_at") or 0) > _cache_ttl_seconds]:
            _scan_cache.pop(key, None)
        for job_id in [job_id for job_id, value in _jobs.items() if now - float(value.get("created_at") or 0) > _job_ttl_seconds]:
            _jobs.pop(job_id, None)


def _job_response(job_id: str) -> Dict[str, Any]:
    with _job_lock:
        job = _jobs.get(job_id)
        if not job:
            raise KeyError(job_id)
        result = copy.deepcopy(job.get("result") or {})
        result.update({
            "job_id": job_id,
            "job_updated_at": job.get("updated_at"),
        })
        return result


# ---------------------------------------------------------------------------
# Job-state mutation helpers - every write to a job's shared result happens
# under _job_lock so a concurrent GET /jobs/{id} always sees a consistent view.
#
# Two independent kinds of "pending" are tracked:
#   - pending_discoveries: theme-level, one fast Gemini call per theme, quick.
#   - pending events: derived by scanning result["events"] for any event whose
#     own enrichment/refinement pipeline hasn't reached a terminal state - not a
#     counter, so it can never drift out of sync with the actual event list.
# ---------------------------------------------------------------------------

def _mutate_job(job_id: str, fn) -> bool:
    with _job_lock:
        job = _jobs.get(job_id)
        if not job:
            return False
        fn(job)
        job["updated_at"] = time.time()
        return True


def _event_is_pending(event: Dict[str, Any]) -> bool:
    stage = str(event.get("stage") or "")
    meta = event.get("enhancement_meta") or {}
    if stage == "refined":
        return False
    if stage == "discovered":
        return str(meta.get("enrichment_status") or "") not in ("failed", "timeout")
    if stage == "enriched":
        return str(meta.get("refinement_status") or "") not in ("failed", "timeout")
    # "enriching" / "refining" - actively in flight.
    return True


def _recompute_job_status(job: Dict[str, Any]) -> None:
    result = job["result"]
    pending_discoveries = int(job.get("pending_discoveries", 0))
    events = result.get("events") or []
    pending_events = sum(1 for e in events if _event_is_pending(e))
    job["pending_events"] = pending_events
    if pending_discoveries > 0 and not events:
        result["job_status"] = "discovering"
    elif pending_discoveries > 0 or pending_events > 0:
        result["job_status"] = "partial"
    else:
        result["job_status"] = "complete" if events else "failed"

    settled = pending_discoveries == 0 and pending_events == 0
    if settled and not job.get("_cache_written"):
        timing = result.get("scan_timing") or {}
        timing["total_seconds"] = round(time.time() - float(job.get("created_at") or time.time()), 3)
        result["scan_timing"] = timing
        # "complete" means the job is terminal and has at least one retained event; it
        # does NOT mean every technical stage succeeded. Cache only an actually clean
        # result so a later scan never silently replays a retained timeout/failure.
        if _job_is_fully_successful(job):
            _write_cache_locked(job)
        job["_cache_written"] = True


def _job_is_fully_successful(job: Dict[str, Any]) -> bool:
    result = job.get("result") or {}
    events = result.get("events") or []
    theme_status = result.get("theme_status") or {}
    return bool(events) and all(
        str(entry.get("stage") or "") == "discovered"
        for entry in theme_status.values()
    ) and all(str(event.get("stage") or "") == "refined" for event in events)


def _write_cache_locked(job: Dict[str, Any]) -> None:
    cache_key = str(job.get("cache_key") or "")
    if cache_key:
        _scan_cache[cache_key] = {
            "stored_at": time.time(),
            "result": copy.deepcopy(job["result"]),
            "job_id": str(job.get("job_id") or ""),
        }


def _finish_theme_discovery_failed(job_id: str, theme_index: int, theme: str, terminal_stage: str, error: str, client_theme_id: str = "") -> None:
    def fn(job: Dict[str, Any]) -> None:
        job["pending_discoveries"] = max(0, int(job.get("pending_discoveries", 0)) - 1)
        prior = job["result"]["theme_status"].get(str(theme_index)) or {}
        job["result"]["theme_status"][str(theme_index)] = {
            "theme": theme, "stage": terminal_stage, "error": error,
            "event_ids": [], "client_theme_id": client_theme_id or prior.get("client_theme_id", ""),
            "updated_at": datetime.now(timezone.utc).isoformat(),
        }
        job["result"].setdefault("warnings", []).append(f"{theme}: {terminal_stage} — {error}")
        _recompute_job_status(job)
    _mutate_job(job_id, fn)


def _add_discovered_events(job_id: str, theme_index: int, spec: Dict[str, Any], items: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    holder: Dict[str, Any] = {}

    def fn(job: Dict[str, Any]) -> None:
        created: List[Dict[str, Any]] = []
        for item in items:
            job["id_counter"] = int(job.get("id_counter", 0)) + 1
            event_id = job["id_counter"]
            event = _scout.build_discovered_event(event_id=event_id, spec=spec, item=item)
            job["result"]["events"].append(event)
            created.append(copy.deepcopy(event))
        job["pending_discoveries"] = max(0, int(job.get("pending_discoveries", 0)) - 1)
        job["result"]["theme_status"][str(theme_index)] = {
            "theme": spec["theme"], "stage": "discovered", "error": None,
            "event_ids": [e["event_id"] for e in created],
            "client_theme_id": str(spec.get("client_theme_id") or ""),
            "updated_at": datetime.now(timezone.utc).isoformat(),
        }
        _recompute_job_status(job)
        holder["events"] = created

    return holder.get("events", []) if _mutate_job(job_id, fn) else []


def _get_event(job_id: str, event_id: int) -> Optional[Dict[str, Any]]:
    with _job_lock:
        job = _jobs.get(job_id)
        if not job:
            return None
        for event in job["result"].get("events") or []:
            if int(event.get("event_id") or 0) == int(event_id):
                return copy.deepcopy(event)
    return None


def _set_event_stage(job_id: str, event_id: int, stage: str, extra: Optional[Dict[str, Any]] = None) -> None:
    def fn(job: Dict[str, Any]) -> None:
        for event in job["result"].get("events") or []:
            if int(event.get("event_id") or 0) == int(event_id):
                event["stage"] = stage
                meta = event.setdefault("enhancement_meta", {})
                meta["stage"] = stage
                if extra:
                    meta.update(extra)
                break
        _recompute_job_status(job)
    _mutate_job(job_id, fn)


def _apply_enrichment(job_id: str, event_id: int, spec: Dict[str, Any], enrichment: Dict[str, Any]) -> None:
    def fn(job: Dict[str, Any]) -> None:
        for event in job["result"].get("events") or []:
            if int(event.get("event_id") or 0) != int(event_id):
                continue
            event["sections"] = enrichment["sections"]
            event["confidence"] = enrichment.get("confidence") or event.get("confidence")
            query_log = enrichment.get("search_queries") or event.get("query_log") or []
            event["query_log"] = query_log
            event["executed_query"] = " | ".join(query_log)
            meta = event.setdefault("enhancement_meta", {})
            sources = enrichment.get("sources") or meta.get("evidence_sources") or []
            meta["evidence_sources"] = sources
            source_names = ", ".join(sorted({s["name"] for s in sources if s.get("name")}))
            if source_names:
                event["source"] = source_names
                event["source_names"] = source_names
            section_meta = assess_sections(event["sections"])
            retrieval_status = overall_retrieval_status(section_meta)
            machine_payload = build_machine_payload(
                trigger="trigger1",
                sections=event["sections"],
                event={
                    "title": event.get("subtitle"), "event_date": event.get("event_date"),
                    "theme": spec["theme"], "why_material": event.get("why_material"),
                },
                query_log=query_log,
                query_log_source="gemini_enrichment_reported_search_formulations",
                model_metadata={"stage": "enriched", "enrichment_status": "complete", "refinement_status": "pending"},
            )
            event["machine_payload"] = machine_payload
            event["stage"] = "enriched"
            meta.update({
                "retrieval_failure": retrieval_status == "TECHNICAL_FAILURE",
                "retrieval_status": retrieval_status,
                "stage": "enriched",
                "enrichment_status": "complete",
                "enrichment_error": "",
                "section_meta": section_meta,
                "quality": summarize_quality(section_meta),
                "machine_payload": machine_payload,
                "query_log_source": "gemini_enrichment_reported_search_formulations",
                "models_triggered": (meta.get("models_triggered") or []) + [{
                    "provider": "gemini",
                    "model": os.environ.get("RPR_GEMINI_EVIDENCE_MODEL", "gemini-3.5-flash"),
                    "role": "trigger1_evidence_enrichment",
                }],
            })
            break
        _recompute_job_status(job)
    _mutate_job(job_id, fn)


def _apply_refinement(job_id: str, refined_event: Dict[str, Any]) -> None:
    def fn(job: Dict[str, Any]) -> None:
        events = job["result"].get("events") or []
        for i, event in enumerate(events):
            if int(event.get("event_id") or 0) == int(refined_event.get("event_id") or -1):
                events[i] = refined_event
                break
        _recompute_job_status(job)
    _mutate_job(job_id, fn)


def _mark_enrichment_failed(job_id: str, event_id: int, status: str, error: str) -> None:
    # Falls back to the last known-good stage ("discovered") - the initial event
    # (title, date, short overview, sources) is never removed or blanked.
    _set_event_stage(job_id, event_id, "discovered", {"enrichment_status": status, "enrichment_error": error})


def _mark_refinement_failed(job_id: str, event_id: int, status: str, error: str) -> None:
    # Falls back to "enriched" - the full eight-section Gemini evidence is never removed.
    _set_event_stage(job_id, event_id, "enriched", {"refinement_status": status, "refinement_error": error})


# ---------------------------------------------------------------------------
# Per-event background pipeline: enrichment -> refinement. One independent
# thread per discovered event, so a theme's 3 events progress at their own
# pace and never block each other or the theme's first result.
# ---------------------------------------------------------------------------

def _run_enrichment_stage(job_id: str, spec: Dict[str, Any], event: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """Returns the refreshed event dict on success, or None on failure/timeout (already recorded)."""
    event_id = int(event["event_id"])
    _set_event_stage(job_id, event_id, "enriching", {"enrichment_status": "in_progress"})
    log.info("[STEP1] GEMINI ENRICHMENT START event=%r", event.get("subtitle"))
    t0 = time.monotonic()
    try:
        enrichment = _scout.enrich_event_gemini(spec, event)
    except TimeoutError as exc:
        dur = int((time.monotonic() - t0) * 1000)
        log.warning("[STEP1] GEMINI ENRICHMENT TIMEOUT event=%r duration_ms=%d — initial event retained", event.get("subtitle"), dur)
        _mark_enrichment_failed(job_id, event_id, "timeout", f"Timed out after {dur}ms")
        return None
    except Exception as exc:
        dur = int((time.monotonic() - t0) * 1000)
        log.warning("[STEP1] GEMINI ENRICHMENT FAILED event=%r duration_ms=%d error=%s: %s — initial event retained", event.get("subtitle"), dur, type(exc).__name__, exc)
        _mark_enrichment_failed(job_id, event_id, "failed", f"{type(exc).__name__}: {exc}")
        return None

    dur = int((time.monotonic() - t0) * 1000)
    log.info("[STEP1] GEMINI ENRICHMENT OK event=%r duration_ms=%d", event.get("subtitle"), dur)
    _apply_enrichment(job_id, event_id, spec, enrichment)
    return _get_event(job_id, event_id)


def _run_refinement_stage(job_id: str, theme: str, event: Dict[str, Any]) -> None:
    event_id = int(event["event_id"])
    _set_event_stage(job_id, event_id, "refining", {"refinement_status": "in_progress"})
    log.info("[STEP1] OPUS REFINEMENT START event=%r model=%s", event.get("subtitle"), _OPUS_MODEL_NAME)
    t0 = time.monotonic()
    try:
        refined = _scout.refine_event_opus(theme, event)
    except TimeoutError as exc:
        dur = int((time.monotonic() - t0) * 1000)
        log.warning("[STEP1] OPUS REFINEMENT TIMEOUT event=%r duration_ms=%d — enriched event retained", event.get("subtitle"), dur)
        _mark_refinement_failed(job_id, event_id, "timeout", f"Timed out after {dur}ms")
        return
    except Exception as exc:
        dur = int((time.monotonic() - t0) * 1000)
        log.warning("[STEP1] OPUS REFINEMENT FAILED event=%r duration_ms=%d error=%s: %s — enriched event retained", event.get("subtitle"), dur, type(exc).__name__, exc)
        _mark_refinement_failed(job_id, event_id, "failed", f"{type(exc).__name__}: {exc}")
        return

    dur = int((time.monotonic() - t0) * 1000)
    log.info("[STEP1] OPUS REFINEMENT OK event=%r duration_ms=%d", event.get("subtitle"), dur)
    _apply_refinement(job_id, refined)


def _run_event_pipeline(job_id: str, spec: Dict[str, Any], event: Dict[str, Any]) -> None:
    """Enrichment -> refinement for exactly one already-discovered event.

    Submitted once per discovered event, independently, so up to 3 events for the
    same theme progress concurrently rather than one after another.
    """
    theme = spec["theme"]
    try:
        already_enriched = any(str(s.get("txt") or "").strip() for s in (event.get("sections") or [])[1:])
        if not already_enriched:
            event = _run_enrichment_stage(job_id, spec, event)
            if event is None:
                return  # failure/timeout already recorded; job status already recomputed
        if str(event.get("stage")) != "refined":
            _run_refinement_stage(job_id, theme, event)
    except Exception as exc:  # genuine, unexpected bug - not an ordinary model timeout/failure
        subtitle = event.get("subtitle") if event else "?"
        log.exception("[STEP1] UNEXPECTED EVENT PIPELINE ERROR event=%r", subtitle)
        event_id = int(event["event_id"]) if event else None
        if event_id is not None:
            fallback_stage = str(event.get("stage") or "discovered")
            extra = (
                {"refinement_status": "failed", "refinement_error": f"Unexpected error: {type(exc).__name__}: {exc}"}
                if fallback_stage == "enriched"
                else {"enrichment_status": "failed", "enrichment_error": f"Unexpected error: {type(exc).__name__}: {exc}"}
            )
            _set_event_stage(job_id, event_id, fallback_stage, extra)


def _run_theme_discovery(job_id: str, spec: Dict[str, Any]) -> None:
    """Discover up to MAX_EVENTS_PER_THEME events for one theme, then fan out an
    independent background pipeline per discovered event."""
    theme_index = int(spec["theme_index"])
    theme = spec["theme"]
    client_theme_id = str(spec.get("client_theme_id") or "")
    log.info("[STEP1] THEME START theme=%r max_events=%d", theme, mes.MAX_EVENTS_PER_THEME)
    t0 = time.monotonic()
    try:
        items = _scout.discover_events_gemini(spec, max_events=mes.MAX_EVENTS_PER_THEME)
    except TimeoutError as exc:
        dur = int((time.monotonic() - t0) * 1000)
        log.warning("[STEP1] GEMINI DISCOVERY TIMEOUT theme=%r duration_ms=%d — continuing other themes", theme, dur)
        _finish_theme_discovery_failed(job_id, theme_index, theme, "discovery_timeout", f"Timed out after {dur}ms", client_theme_id)
        return
    except Exception as exc:
        dur = int((time.monotonic() - t0) * 1000)
        log.warning("[STEP1] GEMINI DISCOVERY FAILED theme=%r duration_ms=%d error=%s: %s", theme, dur, type(exc).__name__, exc)
        _finish_theme_discovery_failed(job_id, theme_index, theme, "discovery_failed", f"{type(exc).__name__}: {exc}", client_theme_id)
        return

    dur = int((time.monotonic() - t0) * 1000)
    log.info("[STEP1] GEMINI DISCOVERY OK theme=%r duration_ms=%d events=%d", theme, dur, len(items))
    events = _add_discovered_events(job_id, theme_index, spec, items)
    if not events:
        return  # job expired/pruned mid-flight

    for event in events:
        log.info("[STEP1] UI RESULT AVAILABLE theme=%r event=%r", theme, event.get("subtitle"))
        _pipeline_executor.submit(_run_event_pipeline, job_id, spec, event)


@app.get("/health")
def health() -> Dict[str, Any]:
    pf = _scout.preflight()
    with _job_lock:
        active = sum(
            1 for job in _jobs.values()
            if int(job.get("pending_discoveries", 0)) > 0 or int(job.get("pending_events", 0)) > 0
        )
    return {
        "status": "ok" if pf.get("ok") else "degraded",
        "version": "1.12.4",
        "step1": pf,
        "step1_jobs": {"active": active},
        "trigger2": {
            "retrieval_model": os.environ.get("RPR_GEMINI_NARRATIVE_MODEL", "gemini-3.5-flash"),
            "refinement_model": os.environ.get("RPR_TRIGGER2_OPUS_MODEL", "claude-opus-4-6"),
        },
        "step2": {
            "context_model": os.environ.get("RPR_STEP2_SONNET_MODEL", "claude-sonnet-4-6"),
            "generation_model": os.environ.get("RPR_STEP2_OPUS_MODEL", "claude-opus-4-6"),
            "strict_confirmation_gate": True,
        },
        "portfolio": portfolio_runtime_info(),
    }


@app.post("/api/v1/rpr/themes/assist")
def theme_assist(req: ThemeAssistRequest) -> Dict[str, Any]:
    theme = str(req.theme or "").strip()
    if not theme:
        raise HTTPException(status_code=400, detail="Theme is required")
    return assist_theme(theme=theme, description=req.description)


@app.post("/api/v1/rpr/themes/assist-batch")
def theme_assist_batch(req: ThemeAssistBatchRequest) -> Dict[str, Any]:
    themes = [
        {"theme": str(item.theme or "").strip(), "description": str(item.description or "").strip()}
        for item in req.themes
        if str(item.theme or "").strip()
    ]
    if not themes:
        raise HTTPException(status_code=400, detail="At least one theme is required")
    return assist_themes_batch(themes)


@app.post("/api/v1/rpr/step1/finalize")
def finalize_step1(req: FinalizeStep1Request) -> Dict[str, Any]:
    """Rebuild the machine payload from the analyst-confirmed Step-1 text."""
    trigger = str(req.trigger or "").strip().lower()
    if trigger not in {"trigger1", "trigger2"}:
        raise HTTPException(status_code=400, detail="trigger must be trigger1 or trigger2")
    if not req.sections:
        raise HTTPException(status_code=400, detail="Confirmed Step-1 sections are required")

    modified = []
    seen = set()
    for item in req.analyst_modified_sections:
        name = str(item or "").strip()
        if name and name not in seen:
            seen.add(name)
            modified.append(name)

    base = req.base_machine_payload or {}
    query_log = base.get("search_queries") if isinstance(base.get("search_queries"), list) else []
    query_log_source = str(base.get("query_log_source") or "unknown")
    base_model_metadata = base.get("model_metadata") if isinstance(base.get("model_metadata"), dict) else {}
    payload = build_machine_payload(
        trigger=trigger,
        sections=req.sections,
        event=req.event,
        query_log=query_log,
        query_log_source=query_log_source,
        model_metadata=base_model_metadata if not modified else {},
    )
    payload["analyst_state"] = {
        "confirmed": True,
        "modified_sections": modified,
        "structured_model_metadata_reused": not bool(modified),
        "note": (
            "Deterministic evidence metadata was rebuilt from confirmed text. "
            "Pre-edit model structured metadata was not reused for analyst-modified sections."
            if modified
            else "Confirmed text matches the current AI-generated section baseline."
        ),
    }
    return {"machine_payload": payload, "quality": payload.get("quality")}


@app.post("/api/v1/rpr/market-events/fetch")
def fetch_market_events(req: FetchRequest) -> Dict[str, Any]:
    _prune_state()
    theme_specs: List[Dict[str, str]] = []
    for item in req.theme_inputs:
        theme = str(item.theme or "").strip()
        if theme:
            theme_specs.append({
                "theme": theme,
                "description": str(item.description or "").strip(),
                "client_theme_id": str(item.client_theme_id or "").strip(),
            })
    if not theme_specs:
        theme_specs = [
            {"theme": str(t).strip(), "description": "", "client_theme_id": ""}
            for t in req.themes
            if str(t).strip()
        ]
    if not theme_specs:
        raise HTTPException(status_code=400, detail="At least one theme is required")

    # Cache key is content-based (theme text + description) only - client_theme_id must
    # never affect it, since two scans of the same theme text should hit the same cache
    # entry even if the frontend assigned a different row id (e.g. after a page reload).
    cache_key = _scan_key(theme_specs)
    if not req.bypass_cache:
        with _job_lock:
            cached = _scan_cache.get(cache_key)
            if cached and time.time() - float(cached.get("stored_at") or 0) <= _cache_ttl_seconds:
                response = copy.deepcopy(cached.get("result") or {})
                cached_job_id = str(cached.get("job_id") or "")
                # Only a fully refined, technically clean result is cached (see
                # _job_is_fully_successful). Return the ORIGINAL job_id when
                # its record still exists (job TTL is longer than cache TTL, so this is
                # normally the case) so retry-refinement still has a valid identity to
                # act on even for a cached result; fall back to None only if that job
                # record has genuinely been pruned already.
                job_still_exists = cached_job_id in _jobs
                response.update({
                    "job_id": cached_job_id if job_still_exists else None,
                    "cache_hit": True,
                })
                response["job_status"] = response.get("job_status") or "complete"
                return response

    specs = MarketEventScout._theme_specs(theme_specs)
    job_id = uuid.uuid4().hex
    now_iso = datetime.now(timezone.utc).isoformat()
    result: Dict[str, Any] = {
        "events": [],
        "themes": [spec["theme"] for spec in specs],
        "theme_inputs": [
            {"theme": spec["theme"], "description": spec["description"], "client_theme_id": spec["client_theme_id"]}
            for spec in specs
        ],
        "theme_status": {
            str(spec["theme_index"]): {
                "theme": spec["theme"], "stage": "discovering", "error": None,
                "event_ids": [], "client_theme_id": spec["client_theme_id"], "updated_at": now_iso,
            }
            for spec in specs
        },
        "source": "ADK Gemini enterprise web search",
        "warnings": [],
        "job_status": "discovering",
        "scanner_mode": "v11_2_lean_discovery_progressive_per_event",
        "max_events_per_theme": mes.MAX_EVENTS_PER_THEME,
        "retrieved_at": now_iso,
        "scan_timing": {"themes_total": len(specs)},
        "cache_hit": False,
        "models_triggered": [
            {"provider": "gemini", "model": os.environ.get("RPR_GEMINI_DISCOVERY_MODEL", "gemini-3.5-flash"), "role": "trigger1_fast_discovery"},
            {"provider": "gemini", "model": os.environ.get("RPR_GEMINI_EVIDENCE_MODEL", "gemini-3.5-flash"), "role": "trigger1_evidence_enrichment"},
            {"provider": "r2d2", "model": _OPUS_MODEL_NAME, "role": "trigger1_opus_batch_refinement"},
        ],
    }
    with _job_lock:
        _jobs[job_id] = {
            "job_id": job_id,
            "created_at": time.time(),
            "updated_at": time.time(),
            "cache_key": cache_key,
            "id_counter": 0,
            "pending_discoveries": len(specs),
            "pending_events": 0,
            "_cache_written": False,
            "result": result,
        }

    for spec in specs:
        _pipeline_executor.submit(_run_theme_discovery, job_id, spec)

    log.info("[STEP1] SCAN STARTED job_id=%s themes=%d max_events_per_theme=%d", job_id, len(specs), mes.MAX_EVENTS_PER_THEME)
    return _job_response(job_id)


@app.get("/api/v1/rpr/market-events/jobs/{job_id}")
def market_event_job(job_id: str) -> Dict[str, Any]:
    _prune_state()
    try:
        return _job_response(job_id)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail="Market scanner job not found or expired") from exc


@app.post("/api/v1/rpr/market-events/jobs/{job_id}/retry-refinement")
def retry_market_event_refinement(job_id: str) -> Dict[str, Any]:
    """Retry every theme/event currently stuck in a failed/timeout state.

    Two independent kinds of retry happen here:
      - A theme whose discovery call itself failed/timed out (no events at all for
        it) is retried from scratch: a fresh discovery call, up to 3 events again.
      - An individual event whose enrichment or refinement failed/timed out is
        retried from its last successful stage - discovery is never repeated for it.
    """
    _prune_state()
    with _job_lock:
        job = _jobs.get(job_id)
        if not job:
            raise HTTPException(status_code=404, detail="Market scanner job not found or expired")
        theme_status = dict(job["result"].get("theme_status") or {})
        theme_inputs = list(job["result"].get("theme_inputs") or [])
        events = list(job["result"].get("events") or [])

        retry_theme_indices = [
            int(key) for key, value in theme_status.items()
            if str(value.get("stage")) in _RETRYABLE_DISCOVERY_STAGES
        ]
        retry_events = [e for e in events if not _event_is_pending(e) and str(e.get("stage")) != "refined"]

        if not retry_theme_indices and not retry_events:
            return _job_response(job_id)

        job["pending_discoveries"] = int(job.get("pending_discoveries", 0)) + len(retry_theme_indices)
        job["_cache_written"] = False
        theme_resubmits: List[Dict[str, Any]] = []
        for index in retry_theme_indices:
            status_entry = theme_status[str(index)]
            theme_name = str(status_entry.get("theme") or (theme_inputs[index]["theme"] if index < len(theme_inputs) else ""))
            description = theme_inputs[index]["description"] if index < len(theme_inputs) else ""
            client_theme_id = str(
                status_entry.get("client_theme_id")
                or (theme_inputs[index].get("client_theme_id") if index < len(theme_inputs) else "")
                or ""
            )
            spec = {"theme": theme_name, "description": description, "theme_index": index, "client_theme_id": client_theme_id}
            job["result"]["theme_status"][str(index)] = {
                "theme": theme_name, "stage": "discovering", "error": None,
                "event_ids": [], "client_theme_id": client_theme_id,
                "updated_at": datetime.now(timezone.utc).isoformat(),
            }
            theme_resubmits.append(spec)

        event_resubmits: List[Dict[str, Any]] = []
        for event in retry_events:
            theme_index = int(event.get("theme_index") or 0)
            theme_name = str(event.get("theme_name") or event.get("theme") or "")
            description = theme_inputs[theme_index]["description"] if theme_index < len(theme_inputs) else ""
            client_theme_id = str(
                event.get("client_theme_id")
                or (theme_inputs[theme_index].get("client_theme_id") if theme_index < len(theme_inputs) else "")
                or ""
            )
            spec = {"theme": theme_name, "description": description, "theme_index": theme_index, "client_theme_id": client_theme_id}
            # Reset the failed stage's status so it re-enters "pending" for job_status purposes.
            meta = event.setdefault("enhancement_meta", {})
            if str(event.get("stage")) == "discovered":
                meta["enrichment_status"] = "pending"
                meta["enrichment_error"] = ""
            elif str(event.get("stage")) == "enriched":
                meta["refinement_status"] = "pending"
                meta["refinement_error"] = ""
            for i, e in enumerate(job["result"]["events"]):
                if int(e.get("event_id") or 0) == int(event.get("event_id") or -1):
                    job["result"]["events"][i] = event
                    break
            event_resubmits.append({"spec": spec, "event": copy.deepcopy(event)})

        _recompute_job_status(job)

    for spec in theme_resubmits:
        _pipeline_executor.submit(_run_theme_discovery, job_id, spec)
    for item in event_resubmits:
        _pipeline_executor.submit(_run_event_pipeline, job_id, item["spec"], item["event"])
    log.info(
        "[STEP1] RETRY SUBMITTED job_id=%s themes=%d events=%d",
        job_id, len(theme_resubmits), len(event_resubmits),
    )
    return _job_response(job_id)


@app.post("/api/v1/rpr/market-events/refine")
def refine_market_event(req: RefineRequest) -> Dict[str, Any]:
    feedback = str(req.feedback or "").strip()
    if not feedback:
        raise HTTPException(status_code=400, detail="Feedback is required")
    theme = str(req.event.get("theme_name") or req.event.get("theme") or "")
    event_id = int(req.event.get("id") or req.event.get("event_id") or 0)
    if not can_rescan("trigger1", theme=theme, event_id=event_id):
        raise HTTPException(status_code=409, detail="Maximum enhancement-assisted rescan count reached for this event")
    try:
        updated = _scout.refine_event(
            event=req.event,
            feedback=feedback,
            affected_sections=req.affected_sections,
            analyst_modified_sections=req.analyst_modified_sections,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"Targeted rescan failed: {exc}") from exc

    outcome = str((updated.get("rescan_result") or {}).get("outcome") or "COMPLETED")
    count = register_rescan_result(
        scope_type="trigger1",
        theme=theme,
        event_id=event_id,
        feedback=feedback,
        outcome=outcome,
    )
    updated.setdefault("rescan_result", {})["attempt_count"] = count
    return {"event": updated, "rescan_result": updated.get("rescan_result")}


@app.post("/api/v1/rpr/step1/enrich")
def step1_enrich(req: EnrichRequest) -> Dict[str, Any]:
    narrative = str(req.narrative or "").strip()
    if not narrative:
        raise HTTPException(status_code=400, detail="Narrative is required")
    try:
        return enrich_narrative(narrative=narrative)
    except NarrativeEnrichError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("server:app", host="127.0.0.1", port=8000, reload=True)
