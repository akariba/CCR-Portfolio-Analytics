"""Portfolio data API for CAGID and Level-2/Level-3 sector selection."""
from __future__ import annotations

from typing import Any, Dict, List

from fastapi import APIRouter, File, HTTPException, UploadFile
from pydantic import BaseModel, Field

from portfolio_service import (
    PortfolioValidationError,
    get_dataset,
    normalize_rows,
    parse_upload,
    public_dataset,
    select_portfolio,
)


portfolio_router = APIRouter(prefix="/api/v1/rpr/portfolio", tags=["RPR Portfolio"])


class PortfolioIngestRequest(BaseModel):
    rows: List[Dict[str, Any]] = Field(default_factory=list)
    source_name: str = "api"


class PortfolioSelectRequest(BaseModel):
    dataset_id: str
    l2_sectors: List[str] = Field(default_factory=list)
    l3_sectors: List[str] = Field(default_factory=list)
    cagids: List[str] = Field(default_factory=list)


def _bad_request(exc: PortfolioValidationError) -> None:
    raise HTTPException(status_code=400, detail=str(exc)) from exc


@portfolio_router.post("/ingest")
def ingest_portfolio(req: PortfolioIngestRequest) -> Dict[str, Any]:
    try:
        result = normalize_rows(req.rows, req.source_name)
        result.pop("records", None)
        return result
    except PortfolioValidationError as exc:
        _bad_request(exc)


@portfolio_router.post("/upload")
async def upload_portfolio(file: UploadFile = File(...)) -> Dict[str, Any]:
    try:
        data = await file.read()
        rows = parse_upload(data, file.filename or "portfolio")
        result = normalize_rows(rows, file.filename or "portfolio")
        result.pop("records", None)
        return result
    except PortfolioValidationError as exc:
        _bad_request(exc)


@portfolio_router.get("/datasets/{dataset_id}")
def portfolio_dataset(dataset_id: str, include_records: bool = False) -> Dict[str, Any]:
    try:
        return public_dataset(get_dataset(dataset_id), include_records=include_records)
    except PortfolioValidationError as exc:
        _bad_request(exc)


@portfolio_router.post("/select")
def portfolio_select(req: PortfolioSelectRequest) -> Dict[str, Any]:
    try:
        return select_portfolio(req.dataset_id, req.l2_sectors, req.l3_sectors, req.cagids)
    except PortfolioValidationError as exc:
        _bad_request(exc)
