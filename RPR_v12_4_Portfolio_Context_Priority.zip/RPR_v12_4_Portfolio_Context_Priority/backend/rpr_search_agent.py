"""Gemini 3.5 enterprise-web runtime for RPR using the installed Google ADK.

This module follows the proven Citi runtime pattern without requiring the unavailable
``citi-adk-adapter`` PyPI distribution.  When the Citi adapter is installed it is used;
otherwise Google ADK's native ``Gemini`` wrapper is used with an explicitly injected
``google.genai.Client`` configured for the existing R2D2/Vertex endpoint.

Nothing that owns an async HTTP/session lifecycle is cached.  Every invocation creates
a fresh token-backed client, model wrapper, LlmAgent, session service and Runner.
"""
from __future__ import annotations

import json
import logging
import os
import re
import ssl
import subprocess
import threading
import time
import uuid
from pathlib import Path
from typing import Any, Dict, Tuple, Type

from google import genai
from google.adk.agents import LlmAgent
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService
from google.adk.tools import enterprise_web_search
from google.genai import types
import google.auth.credentials

try:  # Preferred when the internal adapter is available in the active environment.
    from citi_adk_adapter.models import Vertex as _AdkModel  # type: ignore
    _MODEL_RUNTIME = "citi_adk_adapter.Vertex"
except ModuleNotFoundError:  # Actual RPR workstation: package is not in Citi PyPI.
    try:
        from google.adk.models import Gemini as _AdkModel  # type: ignore
    except ImportError:
        from google.adk.models.google_llm import Gemini as _AdkModel  # type: ignore
    _MODEL_RUNTIME = "google.adk.models.Gemini"

from rpr_model_trace import model_span

log = logging.getLogger("uvicorn.error")

_BASE_MODEL = os.environ.get("RPR_GEMINI_MODEL", "gemini-3.5-flash")
DISCOVERY_MODEL = os.environ.get("RPR_GEMINI_DISCOVERY_MODEL", _BASE_MODEL)
EVIDENCE_MODEL = os.environ.get("RPR_GEMINI_EVIDENCE_MODEL", _BASE_MODEL)
THEME_MODEL = os.environ.get("RPR_GEMINI_THEME_MODEL", _BASE_MODEL)
VERTEX_LOCATION = os.environ.get("RPR_GEMINI_LOCATION", "us")
APP_NAME = os.environ.get("RPR_GEMINI_APP_NAME", "rpr_enterprise_web")
USER_ID = os.environ.get("RPR_GEMINI_USER_ID", "rpr-user")
_TOKEN_TTL_SECONDS = max(60, int(os.environ.get("RPR_HELIX_TOKEN_CACHE_SECONDS", "480")))
_TOKEN_LOCK = threading.RLock()
_TOKEN_CACHE: Dict[str, Any] = {"value": "", "acquired_at": 0.0}
_SSL_LOCK = threading.RLock()
_SSL_CACHE: Dict[str, Any] = {"context": None, "source": ""}

BASE_INSTRUCTION = """You are the enterprise-web retrieval layer for a bank credit-risk application.
Use enterprise_web_search whenever current/public evidence is requested.
Follow the caller's event/theme scope and output contract exactly.
Prefer primary/authoritative sources and reputable financial news.
Never invent facts, numbers, publication dates, URLs, source support, or search execution.
If evidence is unavailable, say so in the requested schema.
Do not replace the requested event with a different event.
Do not perform final credit-risk synthesis when the caller asks for an evidence dossier.
"""


def model_for_role(role: str) -> str:
    role_l = str(role or "evidence").strip().lower()
    if role_l == "theme":
        return THEME_MODEL
    if role_l == "discovery":
        return DISCOVERY_MODEL
    return EVIDENCE_MODEL


def _gateway_class_default(name: str) -> str:
    """Reuse non-secret endpoint/project defaults already owned by llm_gateway.py."""
    try:
        from llm_gateway import R2D2LLMGateway  # type: ignore
        return str(getattr(R2D2LLMGateway, name, "") or "")
    except Exception:
        return ""


def _raw_endpoint() -> str:
    value = (
        os.environ.get("RPR_VERTEX_BASE_URL")
        or os.environ.get("R2D2_BASE_URL")
        or os.environ.get("VERTEX_ENDPOINT")
        or os.environ.get("BASE_VERTEX_URL")
        or os.environ.get("R2D2_UAT_URL")
        or _gateway_class_default("_UAT_URL")
    )
    if not value:
        raise EnvironmentError(
            "No approved R2D2/Vertex endpoint is configured. Set RPR_VERTEX_BASE_URL, "
            "R2D2_BASE_URL, VERTEX_ENDPOINT, BASE_VERTEX_URL, or R2D2_UAT_URL."
        )
    return str(value).strip().rstrip("/")


def _endpoint() -> str:
    """Return the gateway base URL without an SDK-owned API-version suffix."""
    value = _raw_endpoint()
    # google-genai appends HttpOptions.api_version itself.  If the RPR environment
    # already ends in /v1 (or /v1beta1), leaving it in place produces a malformed
    # /v1/v1/... request that the gateway reports only as HTTP 400 invalid request.
    return re.sub(r"/v1(?:alpha\d*|beta\d*)?$", "", value, flags=re.IGNORECASE).rstrip("/")


def _project() -> str:
    value = (
        os.environ.get("VERTEX_PROJECT")
        or os.environ.get("VERTEX_PROJECT_ID")
        or os.environ.get("R2D2_GCP_PROJECT")
        or _gateway_class_default("_GCP_PROJECT")
    )
    if not value:
        raise EnvironmentError(
            "No Vertex project is configured. Set VERTEX_PROJECT, VERTEX_PROJECT_ID, "
            "or R2D2_GCP_PROJECT."
        )
    return str(value)


def _soeid() -> str:
    return str(
        os.environ.get("R2D2_SOEID")
        or os.environ.get("SOEID")
        or os.environ.get("USERNAME")
        or os.environ.get("USER")
        or USER_ID
    )


_CA_FILENAMES = (
    "CitiInternalCAChain_PROD.pem",
    "CitiInternalCAChain.pem",
    "citi-ca-bundle.pem",
)


def _gateway_ca_default() -> str:
    """Read a CA path already configured by the existing RPR gateway, if any."""
    try:
        import llm_gateway  # type: ignore

        owners = (llm_gateway, getattr(llm_gateway, "R2D2LLMGateway", None))
        names = (
            "CITI_CERT_PATH",
            "R2D2_CERT_FILE",
            "CA_BUNDLE_PATH",
            "CA_BUNDLE",
            "CERT_FILE",
            "_CA_BUNDLE_PATH",
            "_CA_BUNDLE",
            "_CERT_FILE",
        )
        for owner in owners:
            if owner is None:
                continue
            for name in names:
                value = str(getattr(owner, name, "") or "").strip()
                if value and Path(value).expanduser().is_file():
                    return str(Path(value).expanduser().resolve())
    except Exception:
        pass
    return ""


def _resolve_ca_bundle() -> str:
    """Find the approved Citi CA bundle without requiring another source edit."""
    for name in (
        "CITI_CERT_PATH",
        "R2D2_CERT_FILE",
        "SSL_CERT_FILE",
        "REQUESTS_CA_BUNDLE",
        "CURL_CA_BUNDLE",
    ):
        value = str(os.environ.get(name, "") or "").strip()
        if value and Path(value).expanduser().is_file():
            return str(Path(value).expanduser().resolve())

    configured = _gateway_ca_default()
    if configured:
        return configured

    backend_dir = Path(__file__).resolve().parent
    project_dir = backend_dir.parent
    roots = (
        backend_dir,
        project_dir,
        project_dir / "portfolio-agent",
        project_dir / "portfolio-agent" / "agents",
        project_dir / "agents",
        Path.cwd(),
    )
    for root in roots:
        for filename in _CA_FILENAMES:
            candidate = root / filename
            if candidate.is_file():
                return str(candidate.resolve())
    return ""


def _build_ssl_context_uncached() -> Tuple[ssl.SSLContext, str]:
    """Build the immutable TLS context used by HTTPX and aiohttp transports."""
    context = ssl.create_default_context()
    cert = _resolve_ca_bundle()
    if cert:
        context.load_verify_locations(cafile=cert)
        return context, cert

    # Corporate Windows roots are not always imported into Python/OpenSSL.
    # Load the signed certificates from the Windows ROOT/CA stores explicitly.
    loaded = 0
    enum_certificates = getattr(ssl, "enum_certificates", None)
    if callable(enum_certificates):
        for store_name in ("ROOT", "CA"):
            try:
                certificates = enum_certificates(store_name)
            except Exception:
                continue
            for cert_bytes, encoding, _trust in certificates:
                if encoding != "x509_asn":
                    continue
                try:
                    pem = ssl.DER_cert_to_PEM_cert(cert_bytes)
                    context.load_verify_locations(cadata=pem)
                    loaded += 1
                except Exception:
                    continue
    return context, (f"windows_certificate_store:{loaded}" if loaded else "python_default_store")


def _build_ssl_context() -> Tuple[ssl.SSLContext, str]:
    """Return one process-wide TLS context instead of rebuilding Windows roots per call."""
    with _SSL_LOCK:
        cached = _SSL_CACHE.get("context")
        if cached is not None:
            return cached, str(_SSL_CACHE.get("source") or "cached")
        context, source = _build_ssl_context_uncached()
        _SSL_CACHE["context"] = context
        _SSL_CACHE["source"] = source
        return context, source


def _configure_ca_bundle() -> str:
    cert = _resolve_ca_bundle()
    if cert:
        os.environ["REQUESTS_CA_BUNDLE"] = cert
        os.environ["SSL_CERT_FILE"] = cert
        os.environ["CURL_CA_BUNDLE"] = cert
    return cert


def _read_token_from_approved_sources() -> str:
    """Read the existing Helix/R2D2 token. The value is never logged or persisted."""
    # The live workstation has already authenticated with Helix.  Read that active
    # session first so the Gemini web agent uses the same user's existing token.
    try:
        result = subprocess.run(
            ["helix", "auth", "access-token", "print", "-a"],
            capture_output=True,
            text=True,
            timeout=15,
            check=False,
        )
    except FileNotFoundError:
        result = None

    if result is not None:
        raw = (result.stdout or "").strip()
        matches = re.findall(r"eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+", raw)
        if result.returncode == 0 and matches:
            return matches[-1]

    # Preserve compatibility with the existing RPR gateway if Helix is not on PATH.
    try:
        from llm_gateway import get_h2m_token  # type: ignore
        token = str(get_h2m_token() or "").strip()
        if token:
            return token
    except Exception as gateway_exc:
        log.warning("[RPR-SEARCH] llm_gateway token helper unavailable: %s", type(gateway_exc).__name__)

    detail = ""
    if result is not None and result.stderr:
        detail = f" Helix reported: {result.stderr.strip()}"
    raise EnvironmentError(
        "No existing H2M token was available from the current Helix session or llm_gateway."
        + detail
    )


def _acquire_token(force_refresh: bool = False) -> str:
    """Return a short-lived in-memory token under a lock to prevent Helix CLI races."""
    now = time.monotonic()
    with _TOKEN_LOCK:
        cached = str(_TOKEN_CACHE.get("value") or "")
        age = now - float(_TOKEN_CACHE.get("acquired_at") or 0.0)
        if cached and not force_refresh and age < _TOKEN_TTL_SECONDS:
            return cached
        token = _read_token_from_approved_sources()
        _TOKEN_CACHE["value"] = token
        _TOKEN_CACHE["acquired_at"] = time.monotonic()
        return token


def invalidate_token_cache() -> None:
    """Invalidate only process memory; no credential or approved environment is changed."""
    with _TOKEN_LOCK:
        _TOKEN_CACHE["value"] = ""
        _TOKEN_CACHE["acquired_at"] = 0.0


class CoinCredentials(google.auth.credentials.Credentials):
    """Google-auth credentials backed by an approved COIN/Helix bearer token."""

    def __init__(self, token: str) -> None:
        super().__init__()
        self.token = token

    @property
    def valid(self) -> bool:
        return bool(self.token)

    @property
    def expired(self) -> bool:
        return False

    def refresh(self, request: Any) -> None:  # noqa: ARG002
        self.token = _acquire_token(force_refresh=True)

    def before_request(self, request: Any, method: str, url: str, headers: Dict[str, str]) -> None:  # noqa: ARG002
        headers["Authorization"] = f"Bearer {self.token}"


def _prepare_environment() -> Dict[str, str]:
    os.environ["VERTEX_LOCATION"] = VERTEX_LOCATION
    project = os.environ.get("VERTEX_PROJECT") or os.environ.get("VERTEX_PROJECT_ID")
    if project:
        os.environ.setdefault("VERTEX_PROJECT", project)
    endpoint = os.environ.get("VERTEX_ENDPOINT") or os.environ.get("BASE_VERTEX_URL")
    if endpoint:
        os.environ.setdefault("VERTEX_ENDPOINT", endpoint.rstrip("/"))
    _configure_ca_bundle()
    return {
        "VERTEX_LOCATION": os.environ.get("VERTEX_LOCATION", ""),
        "VERTEX_PROJECT": os.environ.get("VERTEX_PROJECT", ""),
        "MODEL_RUNTIME": _MODEL_RUNTIME,
    }


def _new_client_and_model(model_name: str, *, force_token_refresh: bool = False) -> Tuple[Any, Any]:
    """Create a fresh token-backed genai client and a fresh ADK model wrapper."""
    _prepare_environment()
    token = _acquire_token(force_refresh=force_token_refresh)
    creds = CoinCredentials(token)
    ssl_context, ca_source = _build_ssl_context()
    http_options = types.HttpOptions(
        api_version="v1",
        base_url=_endpoint(),
        headers={
            "Authorization": f"Bearer {token}",
            "x-r2d2-user": _soeid(),
        },
        client_args={"verify": ssl_context},
        async_client_args={"verify": ssl_context, "ssl": ssl_context},
    )
    client = genai.Client(
        vertexai=True,
        project=_project(),
        location=VERTEX_LOCATION,
        http_options=http_options,
        credentials=creds,
    )
    model = _AdkModel(model=model_name)
    # ``api_client`` is a cached property in Google ADK and the Citi wrapper.  The
    # colleague's proven implementation injects the approved R2D2 client this way.
    model.__dict__["api_client"] = client
    log.info("[RPR-SEARCH] tls ca_source=%s", ca_source)
    return client, model


def runtime_info() -> Dict[str, Any]:
    env = _prepare_environment()
    try:
        _tls_context, ca_source = _build_ssl_context()
        ca_context_ok = True
    except Exception as exc:
        ca_source = f"{type(exc).__name__}: {exc}"
        ca_context_ok = False
    constructor_ok = True
    constructor_error = ""
    try:
        _AdkModel(model=DISCOVERY_MODEL)
    except Exception as exc:
        constructor_ok = False
        constructor_error = f"{type(exc).__name__}: {exc}"
    endpoint_configured = bool(
        os.environ.get("RPR_VERTEX_BASE_URL")
        or os.environ.get("R2D2_BASE_URL")
        or os.environ.get("VERTEX_ENDPOINT")
        or os.environ.get("BASE_VERTEX_URL")
        or os.environ.get("R2D2_UAT_URL")
        or _gateway_class_default("_UAT_URL")
    )
    project_configured = bool(
        os.environ.get("VERTEX_PROJECT")
        or os.environ.get("VERTEX_PROJECT_ID")
        or os.environ.get("R2D2_GCP_PROJECT")
        or _gateway_class_default("_GCP_PROJECT")
    )
    try:
        raw_endpoint = _raw_endpoint()
        normalized_endpoint = _endpoint()
        endpoint_api_suffix_removed = raw_endpoint != normalized_endpoint
    except Exception:
        endpoint_api_suffix_removed = False
    return {
        "provider": _MODEL_RUNTIME,
        "discovery_model": DISCOVERY_MODEL,
        "evidence_model": EVIDENCE_MODEL,
        "theme_model": THEME_MODEL,
        "vertex_location": VERTEX_LOCATION,
        "adapter_vertex_location": env.get("VERTEX_LOCATION"),
        "adapter_constructor": f"{_MODEL_RUNTIME}(model=...) + injected genai.Client",
        "adapter_constructor_ok": constructor_ok,
        "adapter_constructor_error": constructor_error or None,
        "endpoint_configured": endpoint_configured,
        "endpoint_api_suffix_removed": endpoint_api_suffix_removed,
        "project_configured": project_configured,
        "search_tool": "enterprise_web_search",
        "token_source": "current_helix_session (llm_gateway fallback)",
        "token_cache": f"process_memory_lock_ttl_{_TOKEN_TTL_SECONDS}s",
        "ca_context_ok": ca_context_ok,
        "ca_source": ca_source,
        "agent_lifecycle": "fresh_per_call",
        "legacy_search_fallback": False,
        "external_pip_adapter_required": False,
    }


def _to_text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value
    if isinstance(value, (dict, list, tuple)):
        try:
            return json.dumps(value, ensure_ascii=False)
        except Exception:
            return str(value)
    return str(value)


async def _run_once(
    prompt: str,
    role: str,
    trace_label: str,
    model_name: str,
    *,
    force_token_refresh: bool = False,
) -> Tuple[str, Any]:
    session_id = "rprws-" + uuid.uuid4().hex
    _, model = _new_client_and_model(model_name, force_token_refresh=force_token_refresh)
    agent = LlmAgent(
        name=f"rpr_web_{str(role or 'evidence').lower()}_{uuid.uuid4().hex[:10]}",
        model=model,
        instruction=BASE_INSTRUCTION,
        description="RPR Citi enterprise web retrieval agent",
        tools=[enterprise_web_search],
        output_key="results",
    )
    session_service = InMemorySessionService()
    await session_service.create_session(
        app_name=APP_NAME,
        user_id=USER_ID,
        session_id=session_id,
    )
    runner = Runner(agent=agent, app_name=APP_NAME, session_service=session_service)
    message = types.Content(role="user", parts=[types.Part(text=prompt)])

    final_chunks: list[str] = []
    async for event in runner.run_async(
        user_id=USER_ID,
        session_id=session_id,
        new_message=message,
    ):
        is_final = getattr(event, "is_final_response", None)
        try:
            final = bool(is_final()) if callable(is_final) else bool(is_final)
        except Exception:
            final = False
        if not final:
            continue
        content = getattr(event, "content", None)
        for part in getattr(content, "parts", []) or []:
            text = getattr(part, "text", None)
            if text:
                final_chunks.append(str(text))

    answer = "\n".join(x for x in final_chunks if x).strip()
    if not answer:
        session = await session_service.get_session(
            app_name=APP_NAME,
            user_id=USER_ID,
            session_id=session_id,
        )
        state = getattr(session, "state", {}) if session is not None else {}
        if isinstance(state, dict):
            for key in ("results", "web_search_results"):
                candidate = _to_text(state.get(key)).strip()
                if candidate:
                    answer = candidate
                    break
    return answer, model


async def run_web_search(
    query: str,
    role: str = "evidence",
    trace_label: str = "",
    **_: Any,
) -> Dict[str, Any]:
    """Run one isolated Gemini 3.5 + enterprise_web_search invocation."""
    prompt = str(query or "").strip()
    if not prompt:
        raise ValueError("Search query/prompt is required")

    model_name = model_for_role(role)
    with model_span(
        provider="citi-r2d2-vertex",
        model=model_name,
        role=f"enterprise_web_{str(role or 'evidence').lower()}",
        scope=trace_label,
    ) as trace:
        env = _prepare_environment()
        log.info(
            "[RPR-SEARCH] config model=%s location=%s runtime=%s lifecycle=fresh_per_call tool=enterprise_web_search scope=%s",
            model_name,
            env.get("VERTEX_LOCATION") or "-",
            _MODEL_RUNTIME,
            trace_label or "-",
        )
        try:
            answer, _model = await _run_once(prompt, role, trace_label, model_name)
        except Exception as exc:
            status = getattr(exc, "code", None)
            if status == 401 or "401" in str(exc) or "Not Authenticated" in str(exc):
                log.warning("[RPR-SEARCH] 401 received; rebuilding token/client/model and retrying once")
                invalidate_token_cache()
                answer, _model = await _run_once(
                    prompt,
                    role,
                    trace_label,
                    model_name,
                    force_token_refresh=True,
                )
            else:
                raise

        if not answer:
            raise RuntimeError("Gemini enterprise web search completed without a usable result")
        trace.output_chars = len(answer)

    return {
        "answer": answer,
        "raw": answer,
        "role": role,
        "model": model_name,
        "vertex_location": VERTEX_LOCATION,
        "model_runtime": _MODEL_RUNTIME,
        "model_trace": trace.to_dict(),
    }
