"""Strict Step 2.1 and Step 2.3 services using approved Sonnet/Opus adapters."""
from __future__ import annotations

import csv
import json
import os
from io import BytesIO
from io import StringIO
from typing import Any, Dict, List

from rpr_json_runtime import call_r2d2_json, load_prompt, model_record


class Step2ValidationError(ValueError):
    pass


class Step2ModelError(RuntimeError):
    pass


SONNET_MODEL = os.environ.get("RPR_STEP2_SONNET_MODEL", os.environ.get("STEP2_SONNET_MODEL", "claude-sonnet-4-6"))
OPUS_MODEL = os.environ.get("RPR_STEP2_OPUS_MODEL", os.environ.get("STEP2_OPUS_MODEL", "claude-opus-4-6"))


def _confirmed_step1(value: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(value, dict) or not value:
        raise Step2ValidationError("Confirmed Step 1 is required")
    analyst_state = value.get("analyst_state")
    if not isinstance(analyst_state, dict) or analyst_state.get("confirmed") is not True:
        raise Step2ValidationError("Step 1 must be explicitly analyst-confirmed before Step 2.1")
    return value


def _confirmed_scenario(value: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(value, dict) or str(value.get("state") or "").upper() != "CONFIRMED":
        raise Step2ValidationError("A CONFIRMED Step 2.1 scenario is required")
    return value


def _scenario_contract(value: Dict[str, Any], horizon: str) -> Dict[str, Any]:
    narrative = str(value.get("scenario_narrative") or "").strip()
    if not narrative:
        raise Step2ValidationError("Scenario narrative is required")
    items = value.get("assumptions")
    if not isinstance(items, list):
        items = []
    assumptions: List[Dict[str, Any]] = []
    for index, item in enumerate(items):
        if not isinstance(item, dict):
            continue
        bounded = str(item.get("quantified_or_bounded_value") or item.get("value") or "").strip()
        if not bounded:
            continue
        assumptions.append({
            "code": str(item.get("code") or f"A{index + 1}"),
            "type": str(item.get("type") or "Scenario assumption"),
            "quantified_or_bounded_value": bounded,
            "rationale": str(item.get("rationale") or ""),
            "horizon": horizon,
            "direction": str(item.get("direction") or "MIXED").upper(),
            "origin": str(item.get("origin") or "ANALYST_ASSUMPTION").upper(),
            "source_reference": item.get("source_reference"),
            "confidence": str(item.get("confidence") or "MEDIUM").upper(),
            "observed_vs_assumed": str(item.get("observed_vs_assumed") or "ASSUMPTION").upper(),
        })
    if not assumptions:
        raise Step2ValidationError("At least one non-empty assumption is required")
    return {
        **value,
        "scenario_narrative": narrative,
        "assessment_horizon": horizon,
        "assumptions": assumptions,
        "state": "GENERATED",
    }


def default_context_suggestions() -> List[str]:
    """Return questions, never fabricated facts, that help an analyst enrich Step 2.1."""
    return [
        "Portfolio scope or concentration to prioritize (CAGIDs, sectors, regions, or material exposures)",
        "Stress variables and bounds to apply (rates, spreads, FX, commodity prices, demand, or liquidity)",
        "Transmission channels or second-order effects that must be included or excluded",
        "Known mitigants, management actions, hedges, policy responses, or scenario constraints",
        "Explicit assumptions, thresholds, trigger levels, and confidence or evidence limitations",
    ]


def _optional_context(typed_context: str, uploads: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    context: List[Dict[str, Any]] = []
    typed = str(typed_context or "").strip()
    if typed:
        context.append({
            "source": "typed_context",
            "kind": "analyst_context",
            "priority": "HIGHEST_ANALYST_INPUT",
            "text": typed[:20000],
        })
    for item in uploads or []:
        if not isinstance(item, dict):
            continue
        text = str(item.get("text") or item.get("extracted_text") or "").strip()
        if text:
            context.append({
                "source": str(item.get("file_name") or "uploaded_context"),
                "kind": str(item.get("kind") or "uploaded_context"),
                "priority": "HIGHEST_ANALYST_INPUT",
                "text": text[:20000],
                "assumptions": item.get("assumptions") if isinstance(item.get("assumptions"), list) else [],
            })
    return context


def _preserve_accepted_analyst_assumptions(
    assessment: Dict[str, Any], optional: List[Dict[str, Any]]
) -> Dict[str, Any]:
    """Keep accepted structured assumptions byte-for-byte from the analyst upload."""
    if not isinstance(assessment, dict):
        raise Step2ValidationError("Sonnet returned an invalid context assessment")
    curated = assessment.get("curated_context")
    if not isinstance(curated, list):
        curated = []
    rejected_sources = {
        str(item.get("source") or "")
        for item in (assessment.get("rejected_context") or [])
        if isinstance(item, dict)
    }
    accepted_sources = {
        str(item.get("source") or "")
        for item in curated
        if isinstance(item, dict)
    }
    decision = str(assessment.get("overall_decision") or "").upper()
    for item in optional:
        assumptions = item.get("assumptions")
        source = str(item.get("source") or "uploaded_context")
        if not assumptions or source in rejected_sources or decision == "STEP1_HORIZON_ONLY":
            continue
        target = next((entry for entry in curated if isinstance(entry, dict) and str(entry.get("source") or "") == source), None)
        if target is None:
            target = {
                "source": source,
                "kind": "assumption_upload",
                "priority": "HIGHEST_ANALYST_INPUT",
                "text": "Structured analyst assumptions accepted by the context-quality gate.",
                "reason": "Analyst-supplied assumptions for Step 2.1 generation.",
            }
            curated.append(target)
            accepted_sources.add(source)
        target["assumptions"] = [dict(value) for value in assumptions if isinstance(value, dict)]
        target["priority"] = "HIGHEST_ANALYST_INPUT"
    assessment["curated_context"] = curated
    return assessment


def generate_scenario(confirmed_step1: Dict[str, Any], horizon: str, typed_context: str, uploaded_contexts: List[Dict[str, Any]]) -> Dict[str, Any]:
    step1 = _confirmed_step1(confirmed_step1)
    horizon = str(horizon or "").strip()
    if not horizon:
        raise Step2ValidationError("Assessment horizon is required")
    models: List[Dict[str, str]] = []
    optional = _optional_context(typed_context, uploaded_contexts)
    if optional:
        try:
            assessment = call_r2d2_json(
                model=SONNET_MODEL, role="step2_context_quality_gate", scope="step2.1",
                system_prompt=load_prompt("step2_context_assessor.txt"),
                payload={
                    "confirmed_step1": step1,
                    "horizon": horizon,
                    "optional_context": optional,
                    "priority_rule": "After consistency and safety validation, analyst-supplied context and assumptions have highest generation priority.",
                },
                max_tokens=1600, timeout=max(30, int(os.environ.get("RPR_STEP2_SONNET_TIMEOUT", "75"))),
            )
            models.append(model_record("r2d2", SONNET_MODEL, "step2_context_quality_gate"))
            assessment = _preserve_accepted_analyst_assumptions(assessment, optional)
        except Exception as exc:
            raise Step2ModelError(f"Sonnet context-quality assessment failed: {type(exc).__name__}: {exc}") from exc
    else:
        assessment = {"overall_decision": "STEP1_HORIZON_ONLY", "curated_context": [], "rejected_context": [], "quality_note": "No optional context supplied."}
    try:
        value = call_r2d2_json(
            model=OPUS_MODEL, role="step2_1_scenario_generation", scope="step2.1",
            system_prompt=load_prompt("step2_scenario.txt"),
            payload={
                "confirmed_step1": step1,
                "horizon": horizon,
                "context_assessment": assessment,
                "input_priority": ["ACCEPTED_ANALYST_CONTEXT", "CONFIRMED_STEP1", "MODEL_INFERENCE"],
            },
            max_tokens=max(1800, int(os.environ.get("RPR_STEP2_OPUS_MAX_TOKENS", "4200"))),
            timeout=max(45, int(os.environ.get("RPR_STEP2_OPUS_TIMEOUT", "180"))),
        )
        models.append(model_record("r2d2", OPUS_MODEL, "step2_1_scenario_generation"))
    except Exception as exc:
        raise Step2ModelError(f"Opus Step 2.1 generation failed: {type(exc).__name__}: {exc}") from exc
    result = _scenario_contract(value, horizon)
    result["context_assessment"] = assessment
    result["additional_context_suggestions"] = default_context_suggestions()
    result["input_priority"] = ["ACCEPTED_ANALYST_CONTEXT", "CONFIRMED_STEP1", "MODEL_INFERENCE"]
    result["models_triggered"] = models
    return result


def finalize_scenario(scenario: Dict[str, Any], analyst_modified_fields: List[str]) -> Dict[str, Any]:
    horizon = str((scenario or {}).get("assessment_horizon") or "").strip()
    if not horizon:
        raise Step2ValidationError("Assessment horizon is required")
    result = _scenario_contract(dict(scenario or {}), horizon)
    result["state"] = "CONFIRMED"
    result["confirmation"] = {"analyst_confirmed": True, "analyst_modified_fields": [str(x) for x in analyst_modified_fields if str(x).strip()]}
    return result


def revise_scenario(confirmed_step1: Dict[str, Any], horizon: str, base_scenario: Dict[str, Any], feedback: str, accepted_context: List[Dict[str, Any]]) -> Dict[str, Any]:
    step1 = _confirmed_step1(confirmed_step1)
    horizon = str(horizon or "").strip()
    feedback = str(feedback or "").strip()
    if not horizon or not feedback:
        raise Step2ValidationError("Horizon and confirmed feedback are required")
    try:
        value = call_r2d2_json(
            model=OPUS_MODEL, role="step2_1_scenario_revision", scope="step2.1",
            system_prompt=load_prompt("step2_scenario_revision.txt"),
            payload={"confirmed_step1": step1, "horizon": horizon, "base_scenario": base_scenario, "accepted_context": accepted_context, "confirmed_feedback": feedback},
            max_tokens=4200, timeout=max(45, int(os.environ.get("RPR_STEP2_OPUS_TIMEOUT", "180"))),
        )
    except Exception as exc:
        raise Step2ModelError(f"Opus Step 2.1 revision failed: {type(exc).__name__}: {exc}") from exc
    result = _scenario_contract(value, horizon)
    result["context_assessment"] = (base_scenario or {}).get("context_assessment") or {"curated_context": accepted_context}
    result["models_triggered"] = [model_record("r2d2", OPUS_MODEL, "step2_1_scenario_revision")]
    return result


def _normalize_factors(value: Dict[str, Any]) -> Dict[str, Any]:
    raw = value.get("factors") if isinstance(value.get("factors"), list) else []
    factors = [dict(x) for x in raw if isinstance(x, dict)][:6]
    if not factors:
        raise Step2ValidationError("Opus returned no usable event-driven risk factors")
    scores = {"HIGH": 3, "MEDIUM": 2, "LOW": 1}
    total = 0
    for index, factor in enumerate(factors):
        importance = str(factor.get("importance") or "MEDIUM").upper()
        score = scores.get(importance, 2)
        factor["factor_id"] = str(factor.get("factor_id") or f"RF{index + 1}")
        factor["importance"] = importance if importance in scores else "MEDIUM"
        factor["importance_score"] = score
        total += score
    allocated = 0
    for index, factor in enumerate(factors):
        weight = 100 - allocated if index == len(factors) - 1 else round(100 * factor["importance_score"] / total)
        factor["weight_pct"] = weight
        allocated += weight
    return {"factors": factors, "weights_sum_pct": sum(int(x["weight_pct"]) for x in factors)}


def _factor_call(prompt: str, role: str, payload: Dict[str, Any]) -> Dict[str, Any]:
    try:
        value = call_r2d2_json(model=OPUS_MODEL, role=role, scope="step2.3", system_prompt=load_prompt(prompt), payload=payload, max_tokens=5200, timeout=max(60, int(os.environ.get("RPR_STEP2_OPUS_TIMEOUT", "180"))))
    except Exception as exc:
        raise Step2ModelError(f"Opus Step 2.3 call failed: {type(exc).__name__}: {exc}") from exc
    result = _normalize_factors(value)
    result["state"] = "GENERATED"
    result["models_triggered"] = [model_record("r2d2", OPUS_MODEL, role)]
    return result


def generate_event_factors(confirmed_step1: Dict[str, Any], confirmed_scenario: Dict[str, Any], sector: str, portfolio_context: Dict[str, Any]) -> Dict[str, Any]:
    sector = str(sector or "").strip()
    if not sector:
        raise Step2ValidationError("A confirmed portfolio sector is required")
    return _factor_call("step2_event_factors.txt", "step2_3_event_factor_generation", {"confirmed_step1": _confirmed_step1(confirmed_step1), "confirmed_scenario": _confirmed_scenario(confirmed_scenario), "sector": sector, "portfolio_context": portfolio_context})


def revise_event_factors(confirmed_step1: Dict[str, Any], confirmed_scenario: Dict[str, Any], sector: str, base_factors: Dict[str, Any], feedback: str, portfolio_context: Dict[str, Any]) -> Dict[str, Any]:
    if not str(feedback or "").strip():
        raise Step2ValidationError("Confirmed feedback is required")
    return _factor_call("step2_event_factors_revision.txt", "step2_3_event_factor_revision", {"confirmed_step1": _confirmed_step1(confirmed_step1), "confirmed_scenario": _confirmed_scenario(confirmed_scenario), "sector": str(sector or "").strip(), "base_factors": base_factors, "confirmed_feedback": feedback, "portfolio_context": portfolio_context})


def assist_feedback(message: str, context: Dict[str, Any], history: List[Dict[str, Any]], step_key: str) -> Dict[str, Any]:
    message = str(message or "").strip()
    if not message:
        raise Step2ValidationError("Feedback message is required")
    try:
        value = call_r2d2_json(model=SONNET_MODEL, role="step_feedback_assistant", scope=step_key, system_prompt=load_prompt("step2_feedback_assistant.txt"), payload={"step": step_key, "message": message, "context": context, "history": history[-8:]}, max_tokens=1000, timeout=max(30, int(os.environ.get("RPR_STEP2_SONNET_TIMEOUT", "75"))))
    except Exception as exc:
        raise Step2ModelError(f"Sonnet feedback assistant failed: {type(exc).__name__}: {exc}") from exc
    value["apply_supported"] = bool(value.get("apply_supported")) and step_key in {"step2-1", "step2-3"}
    value["models_triggered"] = [model_record("r2d2", SONNET_MODEL, "step_feedback_assistant")]
    return value


def extract_context_bytes(file_name: str, content_type: str, data: bytes) -> Dict[str, Any]:
    if len(data) > 20 * 1024 * 1024:
        raise Step2ValidationError("Uploaded context exceeds 20 MB")
    suffix = os.path.splitext(file_name or "")[1].lower()
    text = ""
    parsed_assumptions: List[Dict[str, Any]] = []
    if suffix in {".txt", ".md", ".csv", ".json", ".yaml", ".yml"} or str(content_type).startswith("text/"):
        text = data.decode("utf-8", errors="replace")
        if suffix == ".json":
            try:
                parsed = json.loads(text)
                rows = parsed.get("assumptions", []) if isinstance(parsed, dict) else parsed
                if isinstance(rows, list):
                    parsed_assumptions = [dict(row) for row in rows if isinstance(row, dict)]
            except json.JSONDecodeError as exc:
                raise Step2ValidationError(f"Invalid JSON context file: {exc}") from exc
        elif suffix == ".csv":
            try:
                parsed_assumptions = [dict(row) for row in csv.DictReader(StringIO(text))]
            except csv.Error as exc:
                raise Step2ValidationError(f"Invalid CSV context file: {exc}") from exc
    elif suffix == ".pdf":
        try:
            from pypdf import PdfReader
            text = "\n".join(page.extract_text() or "" for page in PdfReader(BytesIO(data)).pages)
        except Exception as exc:
            raise Step2ValidationError(f"PDF extraction failed: {exc}") from exc
    elif suffix == ".docx":
        try:
            from docx import Document
            text = "\n".join(p.text for p in Document(BytesIO(data)).paragraphs)
        except Exception as exc:
            raise Step2ValidationError(f"DOCX extraction failed: {exc}") from exc
    else:
        raise Step2ValidationError("Supported context files: TXT, MD, CSV, JSON, YAML, PDF, DOCX")
    text = text.strip()
    if not text:
        raise Step2ValidationError("Uploaded context contained no extractable text")
    normalized_assumptions: List[Dict[str, Any]] = []
    for index, item in enumerate(parsed_assumptions):
        value = str(item.get("quantified_or_bounded_value") or item.get("value") or item.get("assumption") or "").strip()
        if not value or value.lower().startswith("edit:"):
            continue
        normalized_assumptions.append({
            "code": str(item.get("code") or f"U{index + 1}"),
            "type": str(item.get("type") or "Analyst supplied assumption"),
            "quantified_or_bounded_value": value,
            "rationale": str(item.get("rationale") or ""),
            "direction": str(item.get("direction") or "MIXED").upper(),
            "source_reference": str(item.get("source_reference") or file_name),
            "confidence": str(item.get("confidence") or "MEDIUM").upper(),
            "observed_vs_assumed": "ASSUMPTION",
            "origin": "ACCEPTED_CONTEXT",
        })
    return {
        "file_name": file_name,
        "content_type": content_type,
        "kind": "assumption_upload" if normalized_assumptions else "uploaded_context",
        "priority": "HIGHEST_ANALYST_INPUT",
        "text": text[:60000],
        "assumptions": normalized_assumptions,
        "characters_extracted": min(len(text), 60000),
    }
