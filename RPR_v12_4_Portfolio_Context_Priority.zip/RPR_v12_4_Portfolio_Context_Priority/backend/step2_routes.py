"""FastAPI routes for strict Step 2.1 and Step 2.3 orchestration."""
from __future__ import annotations

from typing import Any, Dict, List

from fastapi import APIRouter, File, HTTPException, UploadFile
from pydantic import BaseModel, Field

from step2_service import (
    Step2ModelError,
    Step2ValidationError,
    assist_feedback,
    extract_context_bytes,
    default_context_suggestions,
    finalize_scenario,
    generate_event_factors,
    generate_scenario,
    revise_event_factors,
    revise_scenario,
)

step2_router = APIRouter(prefix="/api/v1/rpr/step2", tags=["RPR Step 2"])


class ScenarioGenerateRequest(BaseModel):
    confirmed_step1: Dict[str, Any]
    horizon: str
    typed_context: str = ""
    uploaded_contexts: List[Dict[str, Any]] = Field(default_factory=list)


class ScenarioFinalizeRequest(BaseModel):
    scenario: Dict[str, Any]
    analyst_modified_fields: List[str] = Field(default_factory=list)


class ScenarioReviseRequest(BaseModel):
    confirmed_step1: Dict[str, Any]
    horizon: str
    base_scenario: Dict[str, Any]
    confirmed_feedback: str
    accepted_context: List[Dict[str, Any]] = Field(default_factory=list)


class EventFactorsGenerateRequest(BaseModel):
    confirmed_step1: Dict[str, Any]
    confirmed_scenario: Dict[str, Any]
    sector: str
    portfolio_context: Dict[str, Any] = Field(default_factory=dict)


class EventFactorsReviseRequest(EventFactorsGenerateRequest):
    base_factors: Dict[str, Any]
    confirmed_feedback: str


class FeedbackAssistRequest(BaseModel):
    confirmed_step1: Dict[str, Any]
    horizon: str = ""
    current_scenario: Dict[str, Any] = Field(default_factory=dict)
    feedback: str


def _raise(exc: Exception) -> None:
    if isinstance(exc, Step2ValidationError):
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    raise HTTPException(status_code=502, detail=str(exc)) from exc


@step2_router.post("/context/extract")
async def context_extract(file: UploadFile = File(...)) -> Dict[str, Any]:
    try:
        return extract_context_bytes(file.filename or "context", file.content_type or "application/octet-stream", await file.read())
    except (Step2ValidationError, Step2ModelError) as exc:
        _raise(exc)


@step2_router.get("/context/suggestions")
def context_suggestions() -> Dict[str, Any]:
    return {
        "priority_rule": "Validated analyst context and uploaded assumptions are prioritized in Step 2.1 generation.",
        "suggestions": default_context_suggestions(),
    }


@step2_router.post("/scenario/generate")
def scenario_generate(req: ScenarioGenerateRequest) -> Dict[str, Any]:
    try:
        return generate_scenario(req.confirmed_step1, req.horizon, req.typed_context, req.uploaded_contexts)
    except (Step2ValidationError, Step2ModelError) as exc:
        _raise(exc)


@step2_router.post("/scenario/finalize")
def scenario_finalize(req: ScenarioFinalizeRequest) -> Dict[str, Any]:
    try:
        return finalize_scenario(req.scenario, req.analyst_modified_fields)
    except (Step2ValidationError, Step2ModelError) as exc:
        _raise(exc)


@step2_router.post("/scenario/revise")
def scenario_revise(req: ScenarioReviseRequest) -> Dict[str, Any]:
    try:
        return revise_scenario(req.confirmed_step1, req.horizon, req.base_scenario, req.confirmed_feedback, req.accepted_context)
    except (Step2ValidationError, Step2ModelError) as exc:
        _raise(exc)


@step2_router.post("/event-factors/generate")
def event_factors_generate(req: EventFactorsGenerateRequest) -> Dict[str, Any]:
    try:
        return generate_event_factors(req.confirmed_step1, req.confirmed_scenario, req.sector, req.portfolio_context)
    except (Step2ValidationError, Step2ModelError) as exc:
        _raise(exc)


@step2_router.post("/event-factors/revise")
def event_factors_revise(req: EventFactorsReviseRequest) -> Dict[str, Any]:
    try:
        return revise_event_factors(req.confirmed_step1, req.confirmed_scenario, req.sector, req.base_factors, req.confirmed_feedback, req.portfolio_context)
    except (Step2ValidationError, Step2ModelError) as exc:
        _raise(exc)


@step2_router.post("/feedback/assist")
def feedback_assist(req: FeedbackAssistRequest) -> Dict[str, Any]:
    try:
        return assist_feedback(req.feedback, {"confirmed_step1": req.confirmed_step1, "horizon": req.horizon, "current_scenario": req.current_scenario}, [], "step2-1")
    except (Step2ValidationError, Step2ModelError) as exc:
        _raise(exc)
