"""Fast deterministic-first, single-call batch theme-quality gate for RPR Step 1.

Only a clearly STRONG theme is resolved deterministically. Every other outcome —
OFF_DOMAIN, AMBIGUOUS, LOW_CREDIT_RELEVANCE, or a theme too short/broad to classify
locally — is routed to the approved Sonnet batch adapter for replacement-theme
suggestions. If that adapter fails, the original theme is retained, the safe local
classification is returned, and suggestion_status is TECHNICAL_FAILURE.
"""
from __future__ import annotations

import json
import os
import re
import threading
from pathlib import Path
from typing import Any, Dict, List, Sequence

from rpr_model_trace import model_span

_PROMPT_PATH = Path(__file__).resolve().parent / "prompts" / "trigger1_theme_gate_batch.txt"
_MODEL = os.environ.get("RPR_THEME_GATE_MODEL", "claude-sonnet-4-6")
_TIMEOUT = max(15, int(os.environ.get("RPR_T1_THEME_GATE_TIMEOUT", "45")))

_CREDIT_TERMS = {
    "credit", "spread", "spreads", "default", "defaults", "debt", "bond", "bonds",
    "sovereign", "bank", "banks", "liquidity", "refinancing", "rates", "yield", "yields",
    "tariff", "tariffs", "trade", "inflation", "monetary", "fiscal", "currency", "fx",
    "commodity", "commodities", "equity", "equities", "recession", "geopolitical",
    "sanctions", "supply", "chain", "market", "markets", "counterparty", "funding",
}
_OFF_DOMAIN_TERMS = {
    "holiday", "recipe", "cooking", "football", "movie", "music", "weather", "birthday",
    "vacation", "restaurant", "perfume", "fashion", "gaming",
}


def _tokens(text: str) -> set[str]:
    return set(re.findall(r"[a-z0-9]+", str(text or "").lower()))


def _deterministic(item: Dict[str, Any]) -> Dict[str, Any] | None:
    theme = str(item.get("theme") or "").strip()
    description = str(item.get("description") or "").strip()
    words = _tokens(theme + " " + description)
    credit_hits = words & _CREDIT_TERMS
    off_hits = words & _OFF_DOMAIN_TERMS
    # A non-credit/off-domain input must still go through the AI gate.  The previous
    # deterministic return suppressed the established AI Assist behaviour by
    # returning OFF_DOMAIN with an empty suggestion list and NOT_REQUESTED status.
    # Keeping the deterministic classification as a fallback is useful, but the
    # normal path must ask the approved Sonnet adapter for replacement themes.
    if off_hits and not credit_hits:
        return None
    if len(theme) >= 8 and len(credit_hits) >= 2:
        return {
            "classification": "STRONG",
            "assessment": "STRONG",
            "reason": "The theme contains a clear market or credit-risk transmission channel.",
            "suggestions": [],
            "suggestion_status": "NOT_REQUIRED",
            "gate_source": "deterministic",
        }
    # Short/ambiguous inputs also need the AI suggestion path instead of a local
    # warning-only result.
    if len(theme) < 4:
        return None
    return None


def _call_batch(payload: Dict[str, Any]) -> Dict[str, Any]:
    try:
        from llm_gateway import get_gateway  # type: ignore
        gateway = get_gateway()
    except Exception as exc:
        raise RuntimeError(f"R2D2 gateway unavailable: {exc}") from exc
    if hasattr(gateway, "_model"):
        gateway._model = _MODEL
    prompt = _PROMPT_PATH.read_text(encoding="utf-8")
    result: Dict[str, Any] = {}
    error: Dict[str, BaseException] = {}

    def runner() -> None:
        try:
            result["value"] = gateway.call_text(
                system_prompt=prompt,
                user_prompt=json.dumps(payload, ensure_ascii=False),
                max_tokens=1800,
            )
        except BaseException as exc:  # noqa: BLE001
            error["error"] = exc

    with model_span(provider="r2d2", model=_MODEL, role="theme_quality_gate_batch", scope="themes") as trace:
        thread = threading.Thread(target=runner, daemon=True)
        thread.start()
        thread.join(_TIMEOUT)
        if thread.is_alive():
            raise TimeoutError(f"Theme quality batch exceeded {_TIMEOUT}s")
        if "error" in error:
            raise error["error"]
        raw = str(result.get("value") or "").strip()
        trace.output_chars = len(raw)
    raw = re.sub(r"^```(?:json)?\s*|\s*```$", "", raw, flags=re.I)
    parsed = json.loads(raw)
    if not isinstance(parsed, dict) or not isinstance(parsed.get("results"), list):
        raise ValueError("Theme quality batch returned an invalid JSON contract")
    return parsed


def assist_themes_batch(themes: Sequence[Dict[str, Any]]) -> Dict[str, Any]:
    items = [
        {"theme": str(item.get("theme") or "").strip(), "description": str(item.get("description") or "").strip()}
        for item in themes
        if str(item.get("theme") or "").strip()
    ]
    results: List[Dict[str, Any] | None] = [None] * len(items)
    uncertain: List[Dict[str, Any]] = []
    for index, item in enumerate(items):
        decided = _deterministic(item)
        if decided is not None:
            results[index] = {"theme_index": index, "theme": item["theme"], **decided}
        else:
            uncertain.append({"theme_index": index, **item})
    if uncertain:
        try:
            response = _call_batch({"themes": uncertain})
            by_index = {
                int(row.get("theme_index")): row
                for row in response.get("results") or []
                if isinstance(row, dict) and str(row.get("theme_index", "")).isdigit()
            }
            for item in uncertain:
                index = int(item["theme_index"])
                row = by_index.get(index) or {}
                classification = str(row.get("classification") or "AMBIGUOUS").upper()
                if classification not in {"STRONG", "RELEVANT_BUT_BROAD", "AMBIGUOUS", "LOW_CREDIT_RELEVANCE", "OFF_DOMAIN"}:
                    classification = "AMBIGUOUS"
                results[index] = {
                    "theme_index": index,
                    "theme": item["theme"],
                    "classification": classification,
                    "assessment": classification,
                    "reason": str(row.get("reason") or "The theme requires analyst clarification."),
                    "suggestions": list(row.get("suggestions") or [])[:3],
                    "suggestion_status": "SUCCESS",
                    "gate_source": "sonnet_batch",
                }
        except Exception as exc:
            for item in uncertain:
                index = int(item["theme_index"])
                words = _tokens(item["theme"] + " " + item.get("description", ""))
                is_off_domain = bool(words & _OFF_DOMAIN_TERMS) and not bool(words & _CREDIT_TERMS)
                results[index] = {
                    "theme_index": index,
                    "theme": item["theme"],
                    "classification": "OFF_DOMAIN" if is_off_domain else "AMBIGUOUS",
                    "assessment": "OFF_DOMAIN" if is_off_domain else "AMBIGUOUS",
                    "reason": f"Theme quality assessment could not complete: {type(exc).__name__}: {exc}",
                    "suggestions": [],
                    "suggestion_status": "TECHNICAL_FAILURE",
                    "gate_source": "sonnet_batch_failed",
                }
    return {
        "results": [row for row in results if row is not None],
        "model": _MODEL if uncertain else None,
        "model_calls": 1 if uncertain else 0,
        "deterministic_count": len(items) - len(uncertain),
    }
