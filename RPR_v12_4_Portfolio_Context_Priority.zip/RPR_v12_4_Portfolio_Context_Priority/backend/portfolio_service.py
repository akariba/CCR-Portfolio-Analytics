"""Deterministic portfolio ingestion and selection for RPR.

This module deliberately contains no LLM calls.  It converts approved internal
portfolio extracts (JSON, CSV/TSV, or XLSX) into a stable CAGID/NAICS hierarchy
that can be passed to the existing strict Step 2 model pipeline.
"""
from __future__ import annotations

import csv
import io
import math
import os
import re
import threading
import time
import uuid
import zipfile
from collections import defaultdict
from decimal import Decimal, InvalidOperation
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple
from xml.etree import ElementTree as ET


class PortfolioValidationError(ValueError):
    """Raised when an uploaded portfolio cannot be normalized safely."""


_MAX_ROWS = max(1, int(os.environ.get("RPR_PORTFOLIO_MAX_ROWS", "25000")))
_DATASET_TTL_SECONDS = max(900, int(os.environ.get("RPR_PORTFOLIO_TTL_SECONDS", "14400")))
_MAX_TOP_COMPANIES = max(1, int(os.environ.get("RPR_PORTFOLIO_TOP_COMPANIES", "100")))


def _header_key(value: Any) -> str:
    return re.sub(r"[^a-z0-9]+", "_", str(value or "").strip().lower()).strip("_")


_ALIASES: Dict[str, Tuple[str, ...]] = {
    "cagid": ("cagid", "customer_cagid", "customer_id", "obligor_cagid"),
    "company_name": ("company_name", "cagid_name", "customer_name", "obligor_name"),
    "sector_l2": (
        "rel_naics_ind_sector_l2_name",
        "rel_naics_sector_l2_name",
        "naics_ind_sector_l2_name",
        "sector_l2",
        "l2_sector",
    ),
    "sector_l3": (
        "rel_naics_ind_sector_l3_name",
        "rel_naics_sector_l3_name",
        "naics_ind_sector_l3_name",
        "sector_l3",
        "l3_sector",
    ),
    "relationship_osuc": (
        "relationship_osuc",
        "relationship_osuc_amt",
        "cre_osuc_amt",
        "osuc_amt",
        "osuc",
        "exposure",
        "exposure_amt",
    ),
}


def _clean_text(value: Any) -> str:
    if value is None:
        return ""
    text = str(value).strip()
    return "" if text.lower() in {"nan", "none", "null"} else text


def _cagid(value: Any) -> str:
    text = _clean_text(value)
    # Excel often renders identifier cells as 100.0. Preserve all other forms.
    return text[:-2] if re.fullmatch(r"[0-9]+\.0", text) else text


def _decimal(value: Any) -> Optional[Decimal]:
    text = _clean_text(value)
    if not text:
        return None
    normalized = text.replace(",", "").replace("$", "").replace("€", "").replace("£", "")
    if normalized.startswith("(") and normalized.endswith(")"):
        normalized = "-" + normalized[1:-1]
    try:
        number = Decimal(normalized)
    except InvalidOperation as exc:
        raise PortfolioValidationError(f"Invalid relationship OSUC amount: {text!r}") from exc
    if not number.is_finite():
        raise PortfolioValidationError(f"Non-finite relationship OSUC amount: {text!r}")
    return number


def _decimal_json(value: Optional[Decimal]) -> Optional[float]:
    return None if value is None else float(value)


def _column_map(rows: Sequence[Mapping[str, Any]]) -> Dict[str, Optional[str]]:
    available: Dict[str, str] = {}
    for row in rows[:100]:
        for key in row.keys():
            available.setdefault(_header_key(key), str(key))
    resolved: Dict[str, Optional[str]] = {}
    for canonical, aliases in _ALIASES.items():
        resolved[canonical] = next((available[a] for a in aliases if a in available), None)
    if not resolved["sector_l2"] or not resolved["sector_l3"]:
        raise PortfolioValidationError(
            "Required columns not found. Expected rel_naics_ind_sector_l2_name and "
            "rel_naics_ind_sector_l3_name (case-insensitive aliases are accepted)."
        )
    return resolved


def normalize_rows(rows: Sequence[Mapping[str, Any]], source_name: str = "portfolio") -> Dict[str, Any]:
    if not rows:
        raise PortfolioValidationError("Portfolio contains no rows")
    if len(rows) > _MAX_ROWS:
        raise PortfolioValidationError(f"Portfolio exceeds the {_MAX_ROWS}-row safety limit")
    if any(not isinstance(row, Mapping) for row in rows):
        raise PortfolioValidationError("Every portfolio row must be an object/mapping")

    columns = _column_map(rows)
    normalized: List[Dict[str, Any]] = []
    skipped_blank = 0
    errors: List[Dict[str, Any]] = []
    seen_taxonomy_rows: set[Tuple[str, str]] = set()
    for position, row in enumerate(rows, start=2):
        l2 = _clean_text(row.get(columns["sector_l2"]))
        l3 = _clean_text(row.get(columns["sector_l3"]))
        cagid = _cagid(row.get(columns["cagid"])) if columns["cagid"] else ""
        company = _clean_text(row.get(columns["company_name"])) if columns["company_name"] else ""
        raw_exposure = row.get(columns["relationship_osuc"]) if columns["relationship_osuc"] else None
        if not any((l2, l3, cagid, company, _clean_text(raw_exposure))):
            skipped_blank += 1
            continue
        if not l2 or not l3:
            errors.append({"row": position, "error": "Both Level-2 and Level-3 sector names are required"})
            continue
        try:
            exposure = _decimal(raw_exposure)
        except PortfolioValidationError as exc:
            errors.append({"row": position, "error": str(exc)})
            continue
        # Exact duplicate taxonomy-only rows are harmless and can be collapsed.
        # Exposure-bearing rows are NEVER deduplicated: two equal facility rows are
        # still two real exposures and silently dropping one would understate risk.
        taxonomy_key = (l2.casefold(), l3.casefold())
        if not cagid and not company and exposure is None:
            if taxonomy_key in seen_taxonomy_rows:
                continue
            seen_taxonomy_rows.add(taxonomy_key)
        normalized.append(
            {
                "cagid": cagid,
                "company_name": company,
                "sector_l2": l2,
                "sector_l3": l3,
                "relationship_osuc": _decimal_json(exposure),
                "source_row": position,
            }
        )
    if errors:
        preview = "; ".join(f"row {e['row']}: {e['error']}" for e in errors[:5])
        suffix = f"; plus {len(errors) - 5} more" if len(errors) > 5 else ""
        raise PortfolioValidationError(f"Portfolio validation failed: {preview}{suffix}")
    if not normalized:
        raise PortfolioValidationError("Portfolio contains no usable sector rows")

    dataset_id = uuid.uuid4().hex
    result = {
        "dataset_id": dataset_id,
        "source_name": _clean_text(source_name) or "portfolio",
        "created_at_epoch": time.time(),
        "columns": columns,
        "records": normalized,
        "validation": {
            "input_rows": len(rows),
            "accepted_rows": len(normalized),
            "blank_rows_skipped": skipped_blank,
            "company_rows": sum(1 for row in normalized if row["cagid"] or row["company_name"]),
            "exposure_rows": sum(1 for row in normalized if row["relationship_osuc"] is not None),
            "strict": True,
        },
    }
    result.update(_summaries(normalized))
    _store_dataset(result)
    return public_dataset(result, include_records=True)


def _summaries(records: Sequence[Mapping[str, Any]]) -> Dict[str, Any]:
    l2: Dict[str, Dict[str, Any]] = {}
    l3: Dict[Tuple[str, str], Dict[str, Any]] = {}
    total = Decimal("0")
    exposure_rows = 0
    companies: set[str] = set()
    for row in records:
        l2_name, l3_name = str(row["sector_l2"]), str(row["sector_l3"])
        amount = _decimal(row.get("relationship_osuc"))
        company_key = str(row.get("cagid") or row.get("company_name") or "").casefold()
        if company_key:
            companies.add(company_key)
        l2_item = l2.setdefault(l2_name, {"name": l2_name, "company_keys": set(), "relationship_osuc": Decimal("0"), "l3_count": set()})
        l3_item = l3.setdefault((l2_name, l3_name), {"l2": l2_name, "name": l3_name, "company_keys": set(), "relationship_osuc": Decimal("0")})
        l2_item["l3_count"].add(l3_name)
        if company_key:
            l2_item["company_keys"].add(company_key)
            l3_item["company_keys"].add(company_key)
        if amount is not None:
            total += amount
            exposure_rows += 1
            l2_item["relationship_osuc"] += amount
            l3_item["relationship_osuc"] += amount
    l2_summary = [
        {"name": value["name"], "l3_count": len(value["l3_count"]), "company_count": len(value["company_keys"]), "relationship_osuc": float(value["relationship_osuc"])}
        for value in l2.values()
    ]
    l3_summary = [
        {"l2": value["l2"], "name": value["name"], "company_count": len(value["company_keys"]), "relationship_osuc": float(value["relationship_osuc"])}
        for value in l3.values()
    ]
    l2_summary.sort(key=lambda x: x["name"].casefold())
    l3_summary.sort(key=lambda x: (x["l2"].casefold(), x["name"].casefold()))
    return {
        "portfolio_summary": {
            "company_count": len(companies),
            "l2_sector_count": len(l2_summary),
            "l3_sector_count": len(l3_summary),
            "exposure_row_count": exposure_rows,
            "relationship_osuc": float(total),
        },
        "l2_sectors": l2_summary,
        "l3_sectors": l3_summary,
    }


_datasets: Dict[str, Dict[str, Any]] = {}
_dataset_lock = threading.RLock()


def _prune_locked(now: float) -> None:
    for dataset_id, item in list(_datasets.items()):
        if now - float(item.get("created_at_epoch", now)) > _DATASET_TTL_SECONDS:
            _datasets.pop(dataset_id, None)


def _store_dataset(dataset: Dict[str, Any]) -> None:
    with _dataset_lock:
        _prune_locked(time.time())
        _datasets[str(dataset["dataset_id"])] = dataset


def get_dataset(dataset_id: str) -> Dict[str, Any]:
    with _dataset_lock:
        _prune_locked(time.time())
        item = _datasets.get(str(dataset_id))
        if not item:
            raise PortfolioValidationError("Portfolio dataset was not found or has expired")
        return item


def public_dataset(dataset: Mapping[str, Any], include_records: bool = False) -> Dict[str, Any]:
    payload = {
        "dataset_id": dataset["dataset_id"],
        "source_name": dataset["source_name"],
        "validation": dataset["validation"],
        "portfolio_summary": dataset["portfolio_summary"],
        "l2_sectors": dataset["l2_sectors"],
        "l3_sectors": dataset["l3_sectors"],
    }
    if include_records:
        payload["records"] = dataset["records"]
    return payload


def select_portfolio(
    dataset_id: str,
    l2_sectors: Sequence[str] = (),
    l3_sectors: Sequence[str] = (),
    cagids: Sequence[str] = (),
) -> Dict[str, Any]:
    dataset = get_dataset(dataset_id)
    l2_filter = {str(v).strip().casefold() for v in l2_sectors if str(v).strip()}
    l3_filter = {str(v).strip().casefold() for v in l3_sectors if str(v).strip()}
    cagid_filter = {_cagid(v).casefold() for v in cagids if _cagid(v)}
    if not any((l2_filter, l3_filter, cagid_filter)):
        raise PortfolioValidationError("Select at least one Level-2 sector, Level-3 sector, or CAGID")
    selected = [
        row for row in dataset["records"]
        if (not l2_filter or str(row["sector_l2"]).casefold() in l2_filter)
        and (not l3_filter or str(row["sector_l3"]).casefold() in l3_filter)
        and (not cagid_filter or str(row.get("cagid", "")).casefold() in cagid_filter)
    ]
    if not selected:
        raise PortfolioValidationError("The selected filters matched no portfolio rows")
    summary = _summaries(selected)
    company_groups: Dict[Tuple[str, str], Dict[str, Any]] = {}
    for row in selected:
        cagid, name = str(row.get("cagid") or ""), str(row.get("company_name") or "")
        if not cagid and not name:
            continue
        key = (cagid.casefold(), name.casefold())
        item = company_groups.setdefault(key, {
            "cagid": cagid,
            "company_name": name,
            "relationship_osuc": 0.0,
            "sector_l2": set(),
            "sector_l3": set(),
            "exposure_row_count": 0,
        })
        item["sector_l2"].add(str(row["sector_l2"]))
        item["sector_l3"].add(str(row["sector_l3"]))
        if row.get("relationship_osuc") is not None:
            item["relationship_osuc"] += float(row["relationship_osuc"])
            item["exposure_row_count"] += 1
    companies = [
        {**item, "sector_l2": sorted(item["sector_l2"], key=str.casefold), "sector_l3": sorted(item["sector_l3"], key=str.casefold)}
        for item in company_groups.values()
    ]
    companies.sort(key=lambda row: (-row["relationship_osuc"], row["company_name"].casefold(), row["cagid"]))
    top = companies[:_MAX_TOP_COMPANIES]
    selected_l3 = sorted({str(row["sector_l3"]) for row in selected}, key=str.casefold)
    context = {
        "portfolio_dataset_id": dataset_id,
        "selected_sectors": selected_l3,
        "selected_l2_sectors": sorted({str(row["sector_l2"]) for row in selected}, key=str.casefold),
        "company_count": summary["portfolio_summary"]["company_count"],
        "relationship_osuc": summary["portfolio_summary"]["relationship_osuc"],
        "sector_hierarchy": summary["l3_sectors"],
        "top_company_exposures": top,
        "strict_source": True,
    }
    return {
        "dataset_id": dataset_id,
        "filters": {"l2_sectors": list(l2_sectors), "l3_sectors": list(l3_sectors), "cagids": list(cagids)},
        **summary,
        "companies": top,
        "portfolio_context": context,
    }


def parse_csv_bytes(data: bytes, filename: str) -> List[Dict[str, Any]]:
    if not data:
        raise PortfolioValidationError("Uploaded file is empty")
    try:
        text = data.decode("utf-8-sig")
    except UnicodeDecodeError:
        text = data.decode("cp1252")
    sample = text[:8192]
    try:
        dialect = csv.Sniffer().sniff(sample, delimiters=",\t;|")
    except csv.Error:
        dialect = csv.excel_tab if filename.lower().endswith(".tsv") else csv.excel
    return [dict(row) for row in csv.DictReader(io.StringIO(text), dialect=dialect)]


def parse_xlsx_bytes(data: bytes) -> List[Dict[str, Any]]:
    """Read the first worksheet from a non-encrypted XLSX using stdlib only."""
    try:
        archive = zipfile.ZipFile(io.BytesIO(data))
    except (zipfile.BadZipFile, OSError) as exc:
        raise PortfolioValidationError("Invalid or encrypted XLSX file") from exc
    ns = {"m": "http://schemas.openxmlformats.org/spreadsheetml/2006/main", "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships"}
    try:
        shared: List[str] = []
        if "xl/sharedStrings.xml" in archive.namelist():
            root = ET.fromstring(archive.read("xl/sharedStrings.xml"))
            shared = ["".join(node.text or "" for node in item.findall(".//m:t", ns)) for item in root.findall("m:si", ns)]
        workbook = ET.fromstring(archive.read("xl/workbook.xml"))
        rels = ET.fromstring(archive.read("xl/_rels/workbook.xml.rels"))
        rel_map = {rel.attrib["Id"]: rel.attrib["Target"] for rel in rels}
        sheet = workbook.find("m:sheets/m:sheet", ns)
        if sheet is None:
            raise PortfolioValidationError("XLSX contains no worksheet")
        target = rel_map[sheet.attrib[f"{{{ns['r']}}}id"]].lstrip("/")
        sheet_path = target if target.startswith("xl/") else "xl/" + target
        sheet_root = ET.fromstring(archive.read(sheet_path))
    except (KeyError, ET.ParseError, IndexError) as exc:
        raise PortfolioValidationError("Unsupported or damaged XLSX workbook") from exc

    matrix: List[List[str]] = []
    for row_node in sheet_root.findall(".//m:sheetData/m:row", ns):
        values: Dict[int, str] = {}
        for cell in row_node.findall("m:c", ns):
            ref = cell.attrib.get("r", "A1")
            letters = re.match(r"[A-Z]+", ref)
            if not letters:
                continue
            index = 0
            for char in letters.group(0):
                index = index * 26 + ord(char) - 64
            index -= 1
            cell_type = cell.attrib.get("t", "")
            value_node = cell.find("m:v", ns)
            if cell_type == "inlineStr":
                value = "".join(node.text or "" for node in cell.findall(".//m:t", ns))
            elif value_node is None:
                value = ""
            elif cell_type == "s":
                value = shared[int(value_node.text or "0")]
            else:
                value = value_node.text or ""
            values[index] = value
        if values:
            matrix.append([values.get(i, "") for i in range(max(values) + 1)])
    if not matrix:
        return []
    headers = [_clean_text(value) for value in matrix[0]]
    return [{headers[i]: row[i] if i < len(row) else "" for i in range(len(headers)) if headers[i]} for row in matrix[1:]]


def parse_upload(data: bytes, filename: str) -> List[Dict[str, Any]]:
    lower = filename.lower()
    if lower.endswith((".csv", ".tsv", ".txt")):
        return parse_csv_bytes(data, filename)
    if lower.endswith(".xlsx"):
        return parse_xlsx_bytes(data)
    raise PortfolioValidationError("Supported portfolio files are .csv, .tsv, .txt, and .xlsx")


def runtime_info() -> Dict[str, Any]:
    with _dataset_lock:
        _prune_locked(time.time())
        active = len(_datasets)
    return {
        "strict_deterministic": True,
        "supported_formats": ["json", "csv", "tsv", "xlsx"],
        "max_rows": _MAX_ROWS,
        "active_datasets": active,
        "dataset_ttl_seconds": _DATASET_TTL_SECONDS,
    }
