"""Strict Trigger-2 pipeline: audited Gemini retrieval, then Claude Opus refinement."""
from __future__ import annotations

import copy
import os
from typing import Any, Dict, List

from rpr_json_runtime import (
    call_gemini_search_json,
    call_r2d2_json,
    load_prompt,
    model_record,
)


class NarrativeEnrichError(RuntimeError):
    pass


FIELDS = (
    "event_overview",
    "event_history",
    "direct_impact_geographies",
    "contagion_impact_geographies",
    "equity_market_impact",
    "credit_market_impact",
    "commodity_market_impact",
    "assumptions",
)


def _timeout(primary: str, compatibility_name: str, default: str = "200") -> int:
    """Read the current timeout name, while accepting the prior audited name."""
    return max(30, int(os.environ.get(primary) or os.environ.get(compatibility_name) or default))


def _sections(value: Dict[str, Any]) -> Dict[str, str]:
    out: Dict[str, str] = {}
    for name in FIELDS:
        text = str(value.get(name) or "").strip()
        if not text:
            text = "Evidence gap: the approved retrieval stage returned no supported content for this section."
        out[name] = text
    return out


def enrich_narrative(narrative: str) -> Dict[str, Any]:
    narrative = str(narrative or "").strip()
    if len(narrative) < 12:
        raise NarrativeEnrichError("Narrative must contain enough detail for evidence retrieval")

    gemini_model = os.environ.get("RPR_GEMINI_NARRATIVE_MODEL", os.environ.get("RPR_GEMINI_MODEL", "gemini-3.5-flash"))
    opus_model = os.environ.get("RPR_TRIGGER2_OPUS_MODEL", "claude-opus-4-6")
    models: List[Dict[str, str]] = []
    try:
        retrieved = call_gemini_search_json(
            role="trigger2_enterprise_web_retrieval",
            scope="narrative",
            prompt=load_prompt("trigger2_web_retrieval.txt"),
            payload={"narrative": narrative, "required_sections": list(FIELDS)},
            timeout=_timeout("RPR_T2_RETRIEVAL_TIMEOUT", "RPR_T2_SEARCH_TIMEOUT"),
        )
        models.append(model_record("citi-r2d2-vertex", gemini_model, "trigger2_enterprise_web_retrieval"))
    except Exception as exc:
        raise NarrativeEnrichError(f"Gemini Trigger-2 retrieval failed: {type(exc).__name__}: {exc}") from exc

    retrieved_sections = _sections(retrieved)
    final_sections = copy.deepcopy(retrieved_sections)
    refinement_status = "SUCCESS"
    refinement_error = ""
    try:
        refined = call_r2d2_json(
            model=opus_model,
            role="trigger2_opus_refinement",
            scope="narrative",
            system_prompt=load_prompt("trigger2_opus_refinement.txt"),
            payload={
                "original_narrative": narrative,
                "gemini_sections": retrieved_sections,
                "sources": retrieved.get("sources") or [],
                "search_queries": retrieved.get("search_queries") or [],
            },
            max_tokens=max(1200, int(os.environ.get("RPR_T2_OPUS_MAX_TOKENS", "4200"))),
            timeout=_timeout("RPR_T2_REFINEMENT_TIMEOUT", "RPR_T2_OPUS_TIMEOUT"),
        )
        final_sections = _sections(refined)
        models.append(model_record("r2d2", opus_model, "trigger2_opus_refinement"))
    except Exception as exc:
        # Never discard a successful evidence retrieval because refinement failed.
        refinement_status = "FAILED_RETAINED_GEMINI"
        refinement_error = f"{type(exc).__name__}: {exc}"
        models.append(model_record("r2d2", opus_model, "trigger2_opus_refinement", "FAILED"))

    sources = retrieved.get("sources") if isinstance(retrieved.get("sources"), list) else []
    queries = retrieved.get("search_queries") if isinstance(retrieved.get("search_queries"), list) else []
    machine_payload: Dict[str, Any] = {
        **final_sections,
        "trigger": "trigger2",
        "original_narrative": narrative,
        "sources": sources,
        "search_queries": queries,
        "query_log_source": "gemini_enterprise_web_search",
        "model_metadata": {"gemini_model": gemini_model, "opus_model": opus_model},
        "analyst_state": {"confirmed": False},
    }
    return {
        **final_sections,
        "machine_payload": machine_payload,
        "models_triggered": models,
        "enhancement_meta": {
            "retrieval_status": "SUCCESS",
            "refinement_status": refinement_status,
            "refinement_error": refinement_error,
            "executed_query": narrative,
            "query_log": queries,
            "query_log_source": "gemini_enterprise_web_search",
            "sources": sources,
            "fallback_used": refinement_status != "SUCCESS",
            "machine_payload": machine_payload,
        },
    }
