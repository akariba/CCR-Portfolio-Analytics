"""Shared, bounded JSON model runtime for RPR Trigger 2 and Step 2.

The audited environment exposes two approved model paths:

* Gemini through ``rpr_search_agent.run_web_search`` with enterprise web search.
* Claude through ``llm_gateway.get_gateway().call_text`` (R2D2).

This module adds strict JSON parsing, model tracing and process-wide concurrency
ownership.  A caller-facing timeout never releases model capacity while the
underlying call is still running.
"""
from __future__ import annotations

import asyncio
import inspect
import json
import logging
import os
import re
import threading
from contextlib import nullcontext
from pathlib import Path
from typing import Any, Callable, Dict

log = logging.getLogger("uvicorn.error")

try:
    from rpr_model_trace import model_span
except Exception:  # pragma: no cover - only used by isolated package tests
    model_span = None  # type: ignore

_GEMINI_SLOTS = max(1, min(3, int(os.environ.get("RPR_T2_GEMINI_WORKERS", "2"))))
_CLAUDE_SLOTS = max(1, min(2, int(os.environ.get("RPR_T2_CLAUDE_WORKERS", "1"))))
_REAPER_CAP = max(300, int(os.environ.get("RPR_T2_REAPER_HARD_CAP_SECONDS", "600")))
_GEMINI_SEMAPHORE = threading.BoundedSemaphore(_GEMINI_SLOTS)
_CLAUDE_SEMAPHORE = threading.BoundedSemaphore(_CLAUDE_SLOTS)

# ``get_gateway`` may return a shared object whose ``_model`` field is mutable.
# Keep model selection and the call in one critical section to prevent Sonnet/Opus
# cross-talk.  Capacity is still configurable, but the lock is deliberately strict.
_GATEWAY_MODEL_LOCK = threading.RLock()


def load_prompt(name: str) -> str:
    path = Path(__file__).resolve().parent / "prompts" / name
    try:
        text = path.read_text(encoding="utf-8").strip()
    except Exception as exc:
        raise RuntimeError(f"Required RPR prompt is unavailable: {path}") from exc
    if not text:
        raise RuntimeError(f"Required RPR prompt is empty: {path}")
    return text


def extract_json(value: Any) -> Dict[str, Any]:
    if isinstance(value, dict):
        return value
    text = str(value or "").strip()
    if not text:
        raise ValueError("Model returned an empty response")
    text = re.sub(r"^```(?:json)?\s*|\s*```$", "", text, flags=re.I | re.S).strip()
    try:
        parsed = json.loads(text)
    except json.JSONDecodeError:
        start = text.find("{")
        end = text.rfind("}")
        if start < 0 or end <= start:
            raise ValueError("Model response did not contain a JSON object")
        parsed = json.loads(text[start : end + 1])
    if not isinstance(parsed, dict):
        raise ValueError("Model JSON root must be an object")
    return parsed


def _owned_timeout(
    semaphore: threading.BoundedSemaphore,
    work: Callable[[], Any],
    timeout: int,
    label: str,
) -> Any:
    semaphore.acquire()
    done = threading.Event()
    result: Dict[str, Any] = {}
    error: Dict[str, BaseException] = {}

    def runner() -> None:
        try:
            result["value"] = work()
        except BaseException as exc:  # noqa: BLE001
            error["error"] = exc
        finally:
            done.set()

    thread = threading.Thread(target=runner, daemon=True, name=f"rpr-{label}")
    thread.start()
    if done.wait(timeout):
        semaphore.release()
        if "error" in error:
            raise error["error"]
        return result.get("value")

    def reclaim() -> None:
        settled = done.wait(_REAPER_CAP)
        semaphore.release()
        if settled:
            log.info("[RPR-MODEL] capacity reclaimed after timeout label=%s", label)
        else:
            log.error("[RPR-MODEL] hard-cap release label=%s cap_s=%s", label, _REAPER_CAP)

    threading.Thread(target=reclaim, daemon=True, name=f"rpr-reaper-{label}").start()
    raise TimeoutError(f"{label} exceeded {timeout}s")


def _trace(provider: str, model: str, role: str, scope: str):
    if model_span is None:
        return nullcontext(type("Trace", (), {"output_chars": 0})())
    return model_span(provider=provider, model=model, role=role, scope=scope)


def call_r2d2_json(
    *,
    model: str,
    role: str,
    scope: str,
    system_prompt: str,
    payload: Dict[str, Any],
    max_tokens: int,
    timeout: int,
) -> Dict[str, Any]:
    def work() -> Dict[str, Any]:
        from llm_gateway import get_gateway  # type: ignore

        with _GATEWAY_MODEL_LOCK:
            gateway = get_gateway()
            if not hasattr(gateway, "call_text"):
                raise RuntimeError("R2D2 gateway does not expose call_text()")
            if hasattr(gateway, "_model"):
                gateway._model = model
            with _trace("r2d2", model, role, scope) as trace:
                raw = gateway.call_text(
                    system_prompt=system_prompt,
                    user_prompt=json.dumps(payload, ensure_ascii=False),
                    max_tokens=max_tokens,
                )
                trace.output_chars = len(str(raw or ""))
            return extract_json(raw)

    return _owned_timeout(_CLAUDE_SEMAPHORE, work, timeout, f"{role}:{scope}")


def call_gemini_search_json(
    *,
    role: str,
    scope: str,
    prompt: str,
    payload: Dict[str, Any],
    timeout: int,
) -> Dict[str, Any]:
    def work() -> Dict[str, Any]:
        from rpr_search_agent import run_web_search  # type: ignore

        request = prompt + "\n\nUSER PAYLOAD:\n" + json.dumps(payload, ensure_ascii=False)
        try:
            value = run_web_search(request, role=role, trace_label=scope)
        except TypeError:
            value = run_web_search(request, role=role)
        if inspect.isawaitable(value):
            value = asyncio.run(value)
        # The approved RPR search adapter returns an execution envelope whose
        # ``answer``/``raw`` member contains the model's JSON text.
        if isinstance(value, dict) and ("answer" in value or "raw" in value):
            value = value.get("answer") or value.get("raw")
        return extract_json(value)

    return _owned_timeout(_GEMINI_SEMAPHORE, work, timeout, f"{role}:{scope}")


def model_record(provider: str, model: str, role: str, status: str = "SUCCESS") -> Dict[str, str]:
    return {"provider": provider, "model": model, "role": role, "status": status}
