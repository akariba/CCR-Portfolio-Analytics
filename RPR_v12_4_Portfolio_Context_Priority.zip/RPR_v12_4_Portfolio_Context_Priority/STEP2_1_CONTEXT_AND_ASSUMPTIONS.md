# Step 2.1 additional context and assumptions

## Priority rule

Generation uses inputs in this order:

1. Valid analyst-entered context and uploaded assumptions.
2. Confirmed Step-1 event evidence and the selected horizon.
3. Bounded model inference used only to close material gaps.

Analyst input is checked for consistency, relevance, and prompt injection. Valid
input is preserved in meaning and cannot be silently downgraded. Confirmed Step-1
event identity and the selected horizon remain immutable.

## Suggested additional context

- Portfolio scope, affected CAGIDs, sectors, products, regions, or concentrations.
- Stress variables and explicit bounds, dates, thresholds, or sensitivities.
- Expected transmission channels from the confirmed event into credit risk.
- Existing mitigants, collateral, hedges, covenants, management actions, and limits.
- Evidence limitations and explicit assumptions the analyst wants tested.

## Uploadable assumption fields

- `code`: stable analyst identifier.
- `type`: market variable, credit transmission, portfolio sensitivity, mitigant,
  management action, or another clear case-specific category.
- `quantified_or_bounded_value`: an explicit value, range, threshold, or condition.
- `rationale`: why the assumption is relevant to this scenario.
- `direction`: upside, downside, neutral, increase, decrease, or case-specific text.
- `source_reference`: approved evidence, analyst source, or policy reference.
- `confidence`: HIGH, MEDIUM, or LOW.

Use the templates under `samples/`. Replace `Edit:` placeholders before upload;
the backend ignores untouched placeholders so examples never become live facts.
