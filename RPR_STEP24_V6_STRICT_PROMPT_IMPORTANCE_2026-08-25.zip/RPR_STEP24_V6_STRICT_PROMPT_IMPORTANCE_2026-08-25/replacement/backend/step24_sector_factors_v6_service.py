"""Strict Step 2.4 V6 implementation.

This file replaces ONLY the additive V6 service. The legacy V5.2 service/routes/data
remain untouched.

Strict-source rule:
- The business prompt is NOT copied/paraphrased here.
- At runtime the service locates the actual approved V6.0 Step-2b prompt under the
  project Prompt/ tree and loads that exact local source.
- DOCX is read with Python stdlib only (zip/XML); TXT/MD are read verbatim.
- A V6.0 marker contract is validated. If the approved prompt cannot be found
  unambiguously, generation fails rather than falling back to a paraphrased prompt.

Research rule:
- V6 generation performs one approved Gemini enterprise_web_search research pass
  before Opus synthesis.
- No public-web fallback, mock data, demo factors, or ungrounded Opus-only fallback.
"""
from __future__ import annotations

import asyncio
import hashlib
import json
import threading
import zipfile
from datetime import date
from pathlib import Path
from typing import Any, Dict, List, Mapping, Tuple
import xml.etree.ElementTree as ET

from step24_sector_factors_service import (
    BUFFER_REDUCTION,
    IMPORTANCE_SCORE,
    VULN_BANDS,
    BUFFER_BANDS,
    VULN_DIR,
    BUFFER_DIR,
    Step24DataError,
    Step24ModelError,
    _gateway_call,
    _metric,
    _parse_json,
    _scoring,
    _text,
    _REASONING_MODEL,
    _REASONING_TIMEOUT,
    _REVISION_MODEL,
    _REVISION_TIMEOUT,
    _REPAIR_MODEL,
)

BASE_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = BASE_DIR.parent
PROMPT_ROOT = PROJECT_ROOT / "Prompt"

_MIN_FACTORS = 4
_MAX_FACTORS = 5

# These markers identify the approved V6.0 business prompt without depending on its filename.
_V6_REQUIRED_MARKERS = (
    "V6.0",
    "Structural Persistence Test",
    "Sector L1",
    "Sector L2",
    "Sector L3",
    "Risk Factor Name",
    "Risk Factor Details",
    "Source Basis",
)


def _extract_docx_text(path: Path) -> str:
    """Extract ordered paragraph/table text from the main DOCX body using stdlib only."""
    try:
        with zipfile.ZipFile(path) as zf:
            xml = zf.read("word/document.xml")
    except Exception as exc:
        raise Step24DataError(f"Unable to read approved Step 2.4 V6 prompt DOCX: {path}") from exc

    try:
        root = ET.fromstring(xml)
    except Exception as exc:
        raise Step24DataError(f"Unable to parse approved Step 2.4 V6 prompt DOCX XML: {path}") from exc

    ns = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}
    body = root.find("w:body", ns)
    if body is None:
        raise Step24DataError(f"Approved Step 2.4 V6 prompt has no document body: {path}")

    def paragraph_text(node: ET.Element) -> str:
        parts: List[str] = []
        for el in node.iter():
            tag = el.tag.rsplit("}", 1)[-1]
            if tag == "t" and el.text:
                parts.append(el.text)
            elif tag == "tab":
                parts.append("\t")
            elif tag in {"br", "cr"}:
                parts.append("\n")
        return "".join(parts).strip()

    blocks: List[str] = []
    for child in list(body):
        tag = child.tag.rsplit("}", 1)[-1]
        if tag == "p":
            txt = paragraph_text(child)
            if txt:
                blocks.append(txt)
        elif tag == "tbl":
            for tr in child.findall(".//w:tr", ns):
                cells: List[str] = []
                for tc in tr.findall("./w:tc", ns):
                    cell_parts = []
                    for p in tc.findall(".//w:p", ns):
                        t = paragraph_text(p)
                        if t:
                            cell_parts.append(t)
                    cells.append(" ".join(cell_parts).strip())
                if any(cells):
                    blocks.append(" | ".join(cells))
    return "\n".join(blocks).strip()


def _read_prompt_candidate(path: Path) -> str:
    suffix = path.suffix.lower()
    if suffix == ".docx":
        return _extract_docx_text(path)
    if suffix in {".txt", ".md"}:
        try:
            return path.read_text(encoding="utf-8-sig")
        except Exception as exc:
            raise Step24DataError(f"Unable to read approved Step 2.4 V6 prompt: {path}") from exc
    return ""


def _looks_like_v6(text: str) -> bool:
    if not text:
        return False
    return all(marker.casefold() in text.casefold() for marker in _V6_REQUIRED_MARKERS)


def _load_exact_v6_prompt() -> Tuple[str, Dict[str, str]]:
    if not PROMPT_ROOT.exists():
        raise Step24DataError(
            f"Approved prompt root not found: {PROMPT_ROOT}. "
            "V6 refuses to use a paraphrased/fallback business prompt."
        )

    candidates: List[Tuple[Path, str]] = []
    for ext in ("*.docx", "*.txt", "*.md"):
        for p in PROMPT_ROOT.rglob(ext):
            # Bias toward Step 2b/Sector files but validate by content, never filename alone.
            name = p.name.casefold()
            if not any(tok in name for tok in ("step 2b", "step2b", "sector", "inherent")):
                continue
            try:
                text = _read_prompt_candidate(p)
            except Step24DataError:
                continue
            if _looks_like_v6(text):
                candidates.append((p, text))

    # If filename filtering missed a renamed approved prompt, make one broader validated pass.
    if not candidates:
        for ext in ("*.docx", "*.txt", "*.md"):
            for p in PROMPT_ROOT.rglob(ext):
                try:
                    text = _read_prompt_candidate(p)
                except Step24DataError:
                    continue
                if _looks_like_v6(text):
                    candidates.append((p, text))

    if not candidates:
        raise Step24DataError(
            "No approved Step 2.4 V6.0 prompt was found under the project Prompt folder. "
            "V6 refuses to fall back to V5.2 or a reconstructed prompt."
        )

    # Allow duplicate copies only when their extracted business text is identical.
    grouped: Dict[str, List[Tuple[Path, str]]] = {}
    for p, text in candidates:
        digest = hashlib.sha256(text.encode("utf-8")).hexdigest()
        grouped.setdefault(digest, []).append((p, text))
    if len(grouped) > 1:
        names = [str(p.relative_to(PROJECT_ROOT)) for p, _ in candidates]
        raise Step24DataError(
            "Multiple non-identical V6.0 prompt sources were found; prompt source is ambiguous. "
            "Resolve locally before generation. Candidates: " + " | ".join(names)
        )

    selected = sorted(candidates, key=lambda x: str(x[0]).casefold())[0]
    p, text = selected
    return text, {
        "prompt_source": str(p.relative_to(PROJECT_ROOT)),
        "prompt_sha256": hashlib.sha256(text.encode("utf-8")).hexdigest(),
        "prompt_version": "V6.0",
    }


def _sector_ref(sector: Mapping[str, Any] | str) -> Dict[str, str]:
    if isinstance(sector, str):
        l1 = ""
        l2 = ""
        l3 = _text(sector)
        sid = ""
        label = l3
    else:
        l1 = _text(sector.get("l1"))
        l2 = _text(sector.get("l2"))
        l3 = _text(sector.get("l3") or sector.get("name") or sector.get("sector_label"))
        sid = _text(sector.get("id"))
        label = _text(sector.get("sector_label") or sector.get("name") or l3)
    if not l3:
        raise Step24DataError("Step 2.4 V6 requires a confirmed L3 sector")
    return {"id": sid, "l1": l1, "l2": l2, "l3": l3, "name": l3, "sector_label": label, "version": "V6.0"}


def _await_in_thread(awaitable: Any, timeout: int) -> Any:
    result: Dict[str, Any] = {}
    error: Dict[str, BaseException] = {}

    def runner() -> None:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            result["value"] = loop.run_until_complete(asyncio.wait_for(awaitable, timeout=timeout))
        except BaseException as exc:  # noqa: BLE001
            error["error"] = exc
        finally:
            loop.close()

    th = threading.Thread(target=runner, daemon=True)
    th.start()
    th.join(timeout + 5)
    if th.is_alive():
        raise TimeoutError(f"Step 2.4 V6 enterprise research exceeded {timeout}s")
    if "error" in error:
        raise error["error"]
    return result.get("value")


def _enterprise_research_sync(sector: Mapping[str, Any] | str, as_of_date: str = "", timeout: int = 150) -> Dict[str, Any]:
    """One approved Gemini enterprise-web retrieval pass. No fallback."""
    sec = _sector_ref(sector)
    as_of = _text(as_of_date) or date.today().isoformat()
    query = f"""
RPR STEP 2.4 V6 — SECTOR-INHERENT RESEARCH ONLY

SECTOR:
L1: {sec['l1']}
L2: {sec['l2']}
L3: {sec['l3']}
REFERENCE / AS-OF DATE: {as_of}

Use enterprise_web_search and research the CURRENT structural credit-risk characteristics of this sector.
This is NOT an event-driven scan.

Research standard:
- Prefer material from the last 12 months to establish current relevance.
- Prioritize rating-agency sector/industry outlooks and methodologies, regulatory publications,
  industry/trade association publications and benchmarking, aggregated sector financial/disclosure evidence,
  and reputable financial/industry sources covering structural trends.
- Identify evidence for persistent/recurring sector credit drivers only.
- Apply this test to every candidate: would it plausibly have applied approximately one year ago and
  still plausibly apply one year from now independently of a single dated event?
- Explicitly exclude one-off M&A, a specific pending law, a single geopolitical shock,
  current-quarter macro releases, or other discrete event-driven risks.
- Do not invent facts, numbers, sources, dates or support.

Return a concise research brief in JSON with:
{{
  "sector_overview_evidence": [
    {{"finding":"...", "source_name":"...", "source_date":"...", "source_type":"..."}}
  ],
  "candidate_structural_drivers": [
    {{
      "driver":"...",
      "why_persistent":"...",
      "source_basis":"concise source-type label",
      "evidence":[{{"finding":"...", "source_name":"...", "source_date":"..."}}]
    }}
  ],
  "excluded_event_driven": [
    {{"candidate":"...", "why_excluded":"..."}}
  ],
  "limitations":["..."]
}}

Do not choose final factor weights or calculate credit scores. Research/evidence only.
""".strip()

    try:
        from rpr_search_agent import run_web_search
        value = run_web_search(query, role="evidence", trace_label=f"step24_v6:{sec['l3']}")
        try:
            asyncio.get_running_loop()
        except RuntimeError:
            out = asyncio.run(asyncio.wait_for(value, timeout=timeout))
        else:
            out = _await_in_thread(value, timeout)
    except Exception as exc:
        raise Step24ModelError(
            "Step 2.4 V6 enterprise research failed. "
            "Strict V6 does not fall back to ungrounded Opus-only factor generation. "
            f"{type(exc).__name__}: {exc}"
        ) from exc

    answer = _text((out or {}).get("answer") or (out or {}).get("raw"))
    if len(answer) < 200:
        raise Step24ModelError(
            "Step 2.4 V6 enterprise research returned insufficient evidence. "
            "Strict V6 does not fall back to ungrounded factor generation."
        )
    return {
        "answer": answer,
        "model": _text((out or {}).get("model")),
        "model_trace": (out or {}).get("model_trace") or {},
    }


def _factor_identity(f: Mapping[str, Any], idx: int) -> Dict[str, str]:
    name = _text(f.get("name"))
    details = _text(f.get("details") or f.get("structural_rationale") or f.get("rationale"))
    structural = _text(f.get("structural_rationale") or details)
    source_basis = _text(f.get("source_basis"))
    persistence = _text(f.get("persistence_test")).upper()
    if not name:
        raise Step24ModelError(f"Step 2.4 V6 factor {idx} is missing name")
    if not details:
        raise Step24ModelError(f"Step 2.4 V6 factor '{name}' is missing details/structural rationale")
    if not structural:
        raise Step24ModelError(f"Step 2.4 V6 factor '{name}' is missing structural_rationale")
    if not source_basis:
        raise Step24ModelError(f"Step 2.4 V6 factor '{name}' is missing source_basis")
    if persistence != "PASS":
        raise Step24ModelError(f"Step 2.4 V6 factor '{name}' did not pass the Structural Persistence Test")
    # V6 Source Basis is a concise source-type label, not a URL.
    if "http://" in source_basis.casefold() or "https://" in source_basis.casefold():
        raise Step24ModelError(f"Factor '{name}' Source Basis must be a concise source-type label, not a URL")
    return {
        "name": name,
        "details": details,
        "structural_rationale": structural,
        "source_basis": source_basis,
        "persistence_test": "PASS",
    }


def _validate_v6(obj: Mapping[str, Any], sector: Mapping[str, Any] | str) -> Dict[str, Any]:
    sec = _sector_ref(sector)
    raw_factors = obj.get("factors")
    if not isinstance(raw_factors, list):
        raise Step24ModelError("Step 2.4 V6 output must contain factors[]")
    if not (_MIN_FACTORS <= len(raw_factors) <= _MAX_FACTORS):
        raise Step24ModelError(
            f"Step 2.4 V6 requires {_MIN_FACTORS}-{_MAX_FACTORS} sector-inherent factors; model returned {len(raw_factors)}"
        )

    seen_names = set()
    factors: List[Dict[str, Any]] = []
    for idx, raw in enumerate(raw_factors, 1):
        if not isinstance(raw, dict):
            raise Step24ModelError(f"Step 2.4 V6 factor {idx} must be an object")
        ident = _factor_identity(raw, idx)
        norm_name = " ".join(ident["name"].casefold().split())
        if norm_name in seen_names:
            raise Step24ModelError(f"Step 2.4 V6 returned duplicate factor '{ident['name']}'")
        seen_names.add(norm_name)

        importance = _text(raw.get("importance")).upper()
        if importance not in IMPORTANCE_SCORE:
            raise Step24ModelError(f"Factor '{ident['name']}' importance must be HIGH or MEDIUM")

        vuln = [_metric(m, VULN_BANDS, VULN_DIR, "Vulnerability") for m in (raw.get("vulnerability_metrics") or [])]
        buf = [_metric(m, BUFFER_BANDS, BUFFER_DIR, "Buffer") for m in (raw.get("buffer_metrics") or [])]
        if len(vuln) < 3 or len(buf) < 3:
            raise Step24ModelError(f"Factor '{ident['name']}' requires at least 3 vulnerability and 3 buffer metrics")
        if len(vuln) != len(buf):
            raise Step24ModelError(f"Factor '{ident['name']}' Set 1 and Set 2 metric counts must match")

        critical_obj = raw.get("critical_threshold") or {}
        operator = _text(critical_obj.get("operator") or critical_obj.get("logic") or "AND").upper()
        critical = [_text(x) for x in (critical_obj.get("conditions") or []) if _text(x)]
        if operator != "AND":
            raise Step24ModelError(f"Factor '{ident['name']}' critical threshold operator must be AND")
        if len(critical) < 3:
            raise Step24ModelError(
                f"Factor '{ident['name']}' critical threshold requires at least 3 simultaneous AND conditions"
            )

        scoring = _scoring(raw.get("scoring") or [])
        scores = [int(x.get("score")) for x in scoring]
        if scores != [5, 4, 3, 2, 1]:
            raise Step24ModelError(f"Factor '{ident['name']}' scoring must contain exactly rows 5,4,3,2,1")

        try:
            raw_score = int(raw.get("reference_raw_score"))
        except Exception as exc:
            raise Step24ModelError(f"Factor '{ident['name']}' reference_raw_score must be an integer") from exc
        raw_score = max(1, min(4, raw_score))

        strength = _text(raw.get("reference_buffer_strength")).upper()
        if strength not in BUFFER_REDUCTION:
            raise Step24ModelError(f"Factor '{ident['name']}' has invalid reference_buffer_strength")
        reduction = BUFFER_REDUCTION[strength]
        net = max(1, min(5, raw_score - reduction))

        factors.append({
            "factor_id": f"RF{idx}",
            "factor_order": idx,
            **ident,
            "rationale": _text(raw.get("rationale")) or ident["structural_rationale"],
            "narrative": _text(raw.get("rationale")) or ident["structural_rationale"],
            "importance": importance,
            "importance_score": IMPORTANCE_SCORE[importance],
            "importance_justification": _text(raw.get("importance_justification")),
            "vulnerability_metrics": vuln,
            "critical_threshold": {"operator": "AND", "logic": "AND", "conditions": critical},
            "buffer_metrics": buf,
            "key_principle": _text(raw.get("key_principle")),
            "scoring": scoring,
            "reference_raw_score": raw_score,
            "reference_buffer_strength": strength,
            "buffer_credit_points": reduction,
            "buffer_adjustment": -reduction,
            "net_reference_score": net,
            "credit_implication": _text(raw.get("credit_implication")),
        })

    total_imp = sum(f["importance_score"] for f in factors)
    if total_imp <= 0:
        raise Step24ModelError("Step 2.4 V6 importance total must be positive")

    running = 0.0
    for i, f in enumerate(factors):
        if i == len(factors) - 1:
            weight = round(100.0 - running, 2)
        else:
            weight = round(f["importance_score"] / total_imp * 100.0, 2)
            running += weight
        f["weight_pct"] = weight

    weight_sum = round(sum(f["weight_pct"] for f in factors), 2)
    composite = round(sum((f["weight_pct"] / 100.0) * f["net_reference_score"] for f in factors), 3)
    overview = _text(obj.get("sector_overview") or obj.get("sector_preamble"))

    if not overview:
        raise Step24ModelError("Step 2.4 V6 output is missing the sector overview")

    return {
        "state": "GENERATED",
        "framework_version": "V6.0",
        "factor_source": "MODEL_GENERATED_SECTOR_INHERENT",
        "sector": sec,
        "sector_overview": overview,
        "sector_preamble": _text(obj.get("sector_preamble")) or overview,
        "factors": factors,
        "weights_sum_pct": weight_sum,
        "composite_reference_score": composite,
        "scoring_formula": "net=max(1, raw-buffer_credit_points); composite=sum(weight*net)",
        "methodology_note": (
            "V6.0 independently identifies 4-5 structural sector-inherent factors from L1/L2/L3 "
            "using approved enterprise research, then applies deterministic importance, weighting "
            "and buffer-credit arithmetic. Issuer scoring remains downstream."
        ),
    }


def _technical_json_contract() -> str:
    # Technical serialization only. The approved business prompt remains untouched.
    return """
APPLICATION SERIALIZATION CONTRACT
Return JSON only; no markdown fences and no prose outside JSON.
The existing Step 2.4 renderer requires this machine shape:

{
  "sector_overview": "<2-3 concise sentences>",
  "sector_preamble": "<same purpose; <=3 sentences>",
  "factors": [
    {
      "factor_order": 1,
      "name": "...",
      "details": "...",
      "structural_rationale": "...",
      "source_basis": "concise source-type label only; no URL",
      "persistence_test": "PASS",
      "rationale": "<=2 sentences",
      "importance": "HIGH|MEDIUM",
      "importance_justification": "<=1 sentence",
      "vulnerability_metrics": [
        {
          "metric": "...",
          "source": "...",
          "formula": "...",
          "direction": "HIGHER_WORSE|LOWER_WORSE",
          "bands": {"VERY_HIGH":"...","HIGH":"...","MODERATE":"...","LOW":"..."}
        }
      ],
      "critical_threshold": {"operator":"AND","conditions":["...","...","..."]},
      "buffer_metrics": [
        {
          "metric": "...",
          "source": "...",
          "formula": "...",
          "direction": "HIGHER_STRONGER|LOWER_STRONGER",
          "bands": {"STRONG":"...","MODERATE":"...","WEAK":"...","NEGLIGIBLE":"..."}
        }
      ],
      "key_principle": "<=2 sentences",
      "scoring": [
        {"score":5,"vulnerability_profile":"...","buffer_profile":"..."},
        {"score":4,"vulnerability_profile":"...","buffer_profile":"..."},
        {"score":3,"vulnerability_profile":"...","buffer_profile":"..."},
        {"score":2,"vulnerability_profile":"...","buffer_profile":"..."},
        {"score":1,"vulnerability_profile":"...","buffer_profile":"..."}
      ],
      "reference_raw_score": 3,
      "reference_buffer_strength": "STRONG|MODERATE|WEAK|NEGLIGIBLE",
      "credit_implication": "<=2 sentences"
    }
  ]
}

Do NOT return importance_score, weight_pct, buffer_credit_points, net_reference_score,
or composite_reference_score. Python owns those calculations.
""".strip()


def _generation_user(
    sector: Mapping[str, Any] | str,
    research: str,
    as_of_date: str = "",
) -> str:
    sec = _sector_ref(sector)
    as_of = _text(as_of_date) or date.today().isoformat()
    return (
        "STEP 2.4 V6 INPUT\n"
        f"Sector L1 Name: {sec['l1']}\n"
        f"Sector L2 Name: {sec['l2']}\n"
        f"Sector L3 Name: {sec['l3']}\n"
        f"Reference / As-of Date: {as_of}\n\n"
        "APPROVED ENTERPRISE RESEARCH EVIDENCE\n"
        + research
        + "\n\n"
        + _technical_json_contract()
    )


def _repair_v6(raw: str, error_message: str, sector: Mapping[str, Any] | str, system_prompt: str) -> Dict[str, Any]:
    if not _REPAIR_MODEL:
        raise Step24ModelError(error_message)
    system = (
        system_prompt
        + "\n\nSTRUCTURAL JSON REPAIR MODE\n"
        + "Repair only contract/JSON validation defects. Preserve the substantive V6 sector analysis, "
          "4-5 structural factors, persistence boundary and research grounding. Return JSON only."
    )
    user = (
        "VALIDATION ERROR:\n" + error_message
        + "\n\nRAW OUTPUT:\n" + raw
        + "\n\n" + _technical_json_contract()
    )
    repaired_raw = _gateway_call(_REPAIR_MODEL, system, user, _REVISION_TIMEOUT, "step24_v6_structural_repair")
    return _parse_json(repaired_raw)


def generate_v6(
    sector: Mapping[str, Any] | str,
    confirmed_portfolio: Mapping[str, Any] | None = None,
    as_of_date: str = "",
) -> Dict[str, Any]:
    # Portfolio is accepted for chain provenance only; the V6 business input is L1/L2/L3 (+ date).
    _ = confirmed_portfolio

    exact_prompt, prompt_meta = _load_exact_v6_prompt()
    research = _enterprise_research_sync(sector, as_of_date)
    user = _generation_user(sector, research["answer"], as_of_date)

    raw = _gateway_call(
        _REASONING_MODEL,
        exact_prompt,
        user,
        _REASONING_TIMEOUT,
        "step24_v6_sector_inherent_reasoning",
    )
    try:
        parsed = _parse_json(raw)
        out = _validate_v6(parsed, sector)
    except (Step24ModelError, ValueError) as first_error:
        repaired = _repair_v6(raw, str(first_error), sector, exact_prompt)
        out = _validate_v6(repaired, sector)
        out["repaired"] = True

    out.update(prompt_meta)
    out["research_context"] = research["answer"][:16000]
    out["research_model"] = research["model"]
    out["model_path"] = (
        f"Gemini {research['model']} enterprise research -> "
        f"R2D2 {_REASONING_MODEL} exact approved Step2.4 V6 prompt -> "
        "deterministic validation/weighting"
    )
    out["models_triggered"] = [
        {"provider": "gemini", "model": research["model"], "role": "step24_v6_enterprise_research"},
        {"provider": "r2d2", "model": _REASONING_MODEL, "role": "step24_v6_sector_inherent_reasoning"},
    ]
    return out


def revise_v6(
    sector: Mapping[str, Any] | str,
    base_framework: Mapping[str, Any],
    confirmed_feedback: str,
) -> Dict[str, Any]:
    instruction = _text(confirmed_feedback)
    if not instruction:
        raise Step24DataError("Confirmed Step 2.4 feedback is required")
    if not _REVISION_MODEL:
        raise Step24ModelError("No approved Sonnet 5 model configured for Step 2.4 V6 revision")

    exact_prompt, prompt_meta = _load_exact_v6_prompt()
    research_context = _text(base_framework.get("research_context"))
    if not research_context:
        research_context = _enterprise_research_sync(sector, "")["answer"]

    system = (
        exact_prompt
        + "\n\nTARGETED REVISION MODE\n"
        + "Apply only the confirmed analyst instruction to the current V6 framework. "
          "Remain inside the exact V6 business methodology, Structural Persistence Test, "
          "4-5 factor rule, metric/scoring requirements and deterministic weighting contract."
    )
    user = json.dumps(
        {
            "sector": _sector_ref(sector),
            "base_framework": base_framework,
            "approved_enterprise_research_evidence": research_context,
            "confirmed_analyst_feedback": instruction,
            "serialization_contract": _technical_json_contract(),
        },
        ensure_ascii=False,
        indent=2,
    )
    raw = _gateway_call(_REVISION_MODEL, system, user, _REVISION_TIMEOUT, "step24_v6_targeted_revision")
    try:
        parsed = _parse_json(raw)
        out = _validate_v6(parsed, sector)
    except (Step24ModelError, ValueError) as first_error:
        repaired = _repair_v6(raw, str(first_error), sector, exact_prompt)
        out = _validate_v6(repaired, sector)
        out["repaired"] = True

    out["state"] = "REVISED"
    out.update(prompt_meta)
    out["research_context"] = research_context[:16000]
    out["model_path"] = f"R2D2 {_REVISION_MODEL} exact Step2.4 V6 targeted revision -> deterministic validation/weighting"
    out["models_triggered"] = [
        {"provider": "r2d2", "model": _REVISION_MODEL, "role": "step24_v6_targeted_revision"}
    ]
    return out


def finalize_v6(sector: Mapping[str, Any] | str, framework: Mapping[str, Any]) -> Dict[str, Any]:
    # Analyst importance changes are authoritative inputs to deterministic finalization.
    factors = []
    for f in framework.get("factors") or []:
        factors.append({
            "factor_order": f.get("factor_order"),
            "name": f.get("name"),
            "details": f.get("details"),
            "structural_rationale": f.get("structural_rationale") or f.get("details") or f.get("rationale"),
            "source_basis": f.get("source_basis") or "Analyst-confirmed V6 framework",
            "persistence_test": f.get("persistence_test") or "PASS",
            "rationale": f.get("rationale") or f.get("narrative"),
            "importance": f.get("importance"),
            "importance_justification": f.get("importance_justification"),
            "vulnerability_metrics": f.get("vulnerability_metrics"),
            "critical_threshold": f.get("critical_threshold"),
            "buffer_metrics": f.get("buffer_metrics"),
            "key_principle": f.get("key_principle"),
            "scoring": f.get("scoring"),
            "reference_raw_score": f.get("reference_raw_score"),
            "reference_buffer_strength": f.get("reference_buffer_strength"),
            "credit_implication": f.get("credit_implication"),
        })

    out = _validate_v6(
        {
            "sector_overview": framework.get("sector_overview") or framework.get("sector_preamble"),
            "sector_preamble": framework.get("sector_preamble"),
            "factors": factors,
        },
        sector,
    )
    out["state"] = "CONFIRMED"
    out["model_path"] = "deterministic Step 2.4 V6 finalization"
    out["models_triggered"] = []
    for key in ("prompt_source", "prompt_sha256", "prompt_version", "research_context", "research_model"):
        if framework.get(key) is not None:
            out[key] = framework.get(key)
    return out
