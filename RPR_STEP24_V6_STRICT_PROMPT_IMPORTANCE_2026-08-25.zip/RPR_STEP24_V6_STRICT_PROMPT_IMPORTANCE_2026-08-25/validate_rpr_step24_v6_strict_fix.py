#!/usr/bin/env python3
from pathlib import Path
import py_compile, sys
ROOT=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path.cwd().resolve()
svc=ROOT/"backend"/"step24_sector_factors_v6_service.py"
js=ROOT/"UI Design"/"rpr_step24_append.js"
py_compile.compile(str(svc),doraise=True)
s=svc.read_text(encoding="utf-8-sig")
j=js.read_text(encoding="utf-8-sig")
checks=[
 ("exact local prompt loader","_load_exact_v6_prompt" in s and "PROMPT_ROOT" in s),
 ("enterprise research","_enterprise_research_sync" in s and "rpr_search_agent" in s),
 ("no V6 governed_sector call","governed_sector(" not in s),
 ("V6 routes frontend",all(x in j for x in ("/generate-v6","/revise-v6","/finalize-v6"))),
 ("v31 importance classes",all(x in j for x in ("importance-toggle","imp-opt","active-high","active-med"))),
 ("analyst importance handler","setStep24Importance" in j and "recomputeStep24Derived" in j),
]
bad=[name for name,ok in checks if not ok]
if bad: raise SystemExit("VALIDATION FAIL — "+", ".join(bad))
print("VALIDATION PASS")
for name,_ in checks: print(" PASS:",name)
print("Prompt text is loaded from the actual local approved V6 source at runtime; no reconstructed prompt fallback.")
