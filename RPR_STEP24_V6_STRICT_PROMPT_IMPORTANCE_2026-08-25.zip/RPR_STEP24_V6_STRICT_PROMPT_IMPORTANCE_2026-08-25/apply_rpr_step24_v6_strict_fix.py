#!/usr/bin/env python3
from pathlib import Path
from datetime import datetime
import shutil, sys

HERE=Path(__file__).resolve().parent
STAMP=datetime.now().strftime("%Y%m%d_%H%M%S")

def fail(msg): raise SystemExit("ABORTED — "+msg)

def find_root():
    if len(sys.argv)>1:
        p=Path(sys.argv[1]).expanduser().resolve()
        if (p/"backend").is_dir() and (p/"UI Design").is_dir(): return p
        fail(f"Provided root invalid: {p}")
    p=Path.cwd().resolve()
    for c in [p,*p.parents]:
        if (c/"backend").is_dir() and (c/"UI Design").is_dir(): return c
    fail("Project root not found. Pass the already-verified $root as argument.")

root=find_root()
targets={
    root/"backend"/"step24_sector_factors_v6_service.py": HERE/"replacement"/"backend"/"step24_sector_factors_v6_service.py",
    root/"UI Design"/"rpr_step24_append.js": HERE/"replacement"/"UI Design"/"rpr_step24_append.js",
}
for t in targets:
    if not t.exists(): fail(f"Required installed V6 file missing: {t}")

js=(root/"UI Design"/"rpr_step24_append.js").read_text(encoding="utf-8-sig")
required=["/generate-v6","/revise-v6","/finalize-v6","function factorCard(f,first)","function renderStep24(d)"]
missing=[x for x in required if x not in js]
if missing: fail("Current V6 frontend does not match the installed bone: "+", ".join(missing))

svc=(root/"backend"/"step24_sector_factors_v6_service.py").read_text(encoding="utf-8-sig")
if "def generate_v6(" not in svc or "def finalize_v6(" not in svc:
    fail("Current V6 service does not match the installed bone.")

backups=[]
for t,src in targets.items():
    b=t.with_name(t.name+f".bone-backup-{STAMP}")
    shutil.copy2(t,b);backups.append(b)
    shutil.copy2(src,t)

print("PASS — Step 2.4 V6 strict prompt + importance control installed.")
print("CHANGED ONLY:")
for t in targets: print(" ",t)
print("BACKUPS:")
for b in backups: print(" ",b)
print("UNTOUCHED: V5.2 service/routes/data, server.py, Steps 1/2.1/2.2/2.3, HTML/CSS.")
print("NEXT: restart the already-working backend and hard-refresh the same RPR HTML.")
