RPR STEP 2.4 V6 STRICT PROMPT + V31 IMPORTANCE CONTROL
========================================================

WHY THIS PACKAGE
The first V6 branch proved the new architecture can generate factors, but two gaps remained:
1) the v31 High/Medium analyst control was not rendered;
2) the V6 business prompt had been represented in a machine adaptation and the research requirement
   was not enforced as a separate enterprise-retrieval stage.

THIS FIX IS STRICTER.

CHANGED ONLY
REPLACE EXISTING:
- backend\step24_sector_factors_v6_service.py
- UI Design\rpr_step24_append.js

DO NOT TOUCH:
- V5.2 service/routes/data/CSV
- backend\server.py
- Step 1
- Step 2.1
- Step 2.2
- Step 2.3
- HTML
- CSS
- model IDs

PROMPT SOURCE
The replacement V6 service does NOT contain a rewritten/paraphrased business prompt.
At runtime it searches the existing project Prompt folder for the actual approved V6.0 Step-2b source,
extracts DOCX/TXT/MD text, validates V6 markers, hashes it, and uses that exact local text as the Opus
business/system prompt.

If no unambiguous V6.0 prompt is found, generation FAILS. There is no V5.2 or reconstructed-prompt fallback.

RESEARCH
Before Opus synthesis, V6 performs one Gemini enterprise_web_search retrieval pass using the existing
approved rpr_search_agent. No public-web fallback. If enterprise research fails or is insufficient,
V6 fails rather than generating ungrounded factors.

IMPORTANCE CONTROL
The exact existing v31 class language is restored:
- importance-toggle
- imp-opt
- active-high
- active-med

The model-generated HIGH/MEDIUM value is preselected.
Analyst changes:
HIGH = 2
MEDIUM = 1
Weights are recalculated immediately and kept at exactly 100%.
The V6 Importance Justification remains separately visible.
finalize-v6 deterministically validates/recomputes the analyst-selected importance and weights.

INSTALL
Use the already-verified project-root PowerShell variable if still available:

python .\apply_rpr_step24_v6_strict_fix.py "$root"

If $root is not present, use the same verified project root method you already used; do not guess/type a new path.

Then optionally:
python .\validate_rpr_step24_v6_strict_fix.py "$root"

RESTART
Use the SAME backend start method/approved venv that is already working.
Do not change execution policy or install packages.

EXPECTED LOG PATH
Gemini enterprise research -> Opus exact local V6.0 prompt -> deterministic validation/weighting.

EXPECTED UI
Each factor now contains:
FACTOR IMPORTANCE
[ High ] [ Medium ]

followed separately by:
IMPORTANCE JUSTIFICATION
...
