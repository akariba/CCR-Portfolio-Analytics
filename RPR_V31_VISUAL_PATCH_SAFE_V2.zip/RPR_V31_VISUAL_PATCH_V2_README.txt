RPR V31 VISUAL PATCH V2

The first run safely ABORTED before writing any files because its exact
"Scoring Logic (1-5)" text check did not match the live dash variant.

V2 changes only that detector:
- searches inside buildRFCard()
- accepts hyphen, en dash, or em dash
- still aborts rather than guessing
- still leaves rpr_step24_append.js untouched

Run from the Rapid Portfolio Review_AI root:

python .\apply_rpr_v31_visual_patch_v2.py

If it prints PASS, use Ctrl+F5.
If it prints ABORTED, stop and send the exact message.
