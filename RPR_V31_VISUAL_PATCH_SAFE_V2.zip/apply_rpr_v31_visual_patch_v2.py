#!/usr/bin/env python3
from pathlib import Path
from datetime import datetime
import hashlib
import shutil
import sys

ROOT = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path.cwd().resolve()
UI = ROOT / "UI Design"

JS = UI / "rpr_step22_step23_append.js"
CSS = UI / "rpr_step22_step23_append.css"
STEP24_JS = UI / "rpr_step24_append.js"

STAMP = datetime.now().strftime("%Y%m%d_%H%M%S")

def fail(msg):
    raise SystemExit("ABORTED — " + msg)

def sha(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def read_text(path):
    if not path.exists():
        fail(f"Required file not found: {path}")
    return path.read_text(encoding="utf-8-sig")

def backup(path):
    dst = path.with_name(path.name + f".bone-backup-{STAMP}")
    shutil.copy2(path, dst)
    return dst

def function_span(src, function_name):
    needle = f"function {function_name}("
    start = src.find(needle)
    if start < 0:
        fail(f"Function not found: {function_name}")
    brace = src.find("{", start)
    if brace < 0:
        fail(f"Opening brace not found for {function_name}")

    depth = 0
    i = brace
    state = "code"
    quote = None
    while i < len(src):
        ch = src[i]
        nxt = src[i + 1] if i + 1 < len(src) else ""

        if state == "code":
            if ch in ("'", '"', "`"):
                quote = ch
                state = "string"
            elif ch == "/" and nxt == "/":
                state = "line_comment"
                i += 1
            elif ch == "/" and nxt == "*":
                state = "block_comment"
                i += 1
            elif ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    return start, i + 1
        elif state == "string":
            if ch == "\\":
                i += 1
            elif ch == quote:
                state = "code"
                quote = None
        elif state == "line_comment":
            if ch == "\n":
                state = "code"
        elif state == "block_comment":
            if ch == "*" and nxt == "/":
                state = "code"
                i += 1
        i += 1

    fail(f"Could not find end of function {function_name}")

js = read_text(JS)
css = read_text(CSS)

required_js_markers = [
    "const STEP22_TEMPLATE",
    "const STEP23_TEMPLATE",
    "let STEP22_CONFIRMED_PORTFOLIO=null;",
    "function buildPortfolioSelectionUI()",
    "function runStep22Search()",
    "function confirmPortfolioSelection()",
    "function renderEventFactors()",
    "function buildRFCard(",
    "generate-event-factors-btn",
    "confirm-event-factors-btn",
    "/api/v1/rpr/step2/portfolio/catalog",
    "/api/v1/rpr/step2/portfolio/search",
    "/api/v1/rpr/step2/portfolio/finalize",
]
missing = [m for m in required_js_markers if m not in js]
if missing:
    fail("Current JS does not match the expected working bone. Missing: " + ", ".join(missing))

if "step22SelectAllByL2" in js:
    fail("A newer per-L2 Select-All implementation is already present. This patch intentionally does not introduce or overwrite it.")

step24_hash_before = sha(STEP24_JS) if STEP24_JS.exists() else None

new_build_portfolio = r'''function buildPortfolioSelectionUI(){
 const c=$('ps-sector-grid');if(!c)return;
 if(!STEP22_CATALOG_OK){c.innerHTML='<div class="pla-placeholder" style="grid-column:1/-1"><div class="pla-placeholder-title">Portfolio catalog unavailable</div></div>';refreshSelectionUI();return}
 if(!ALL_SECTORS.length){c.innerHTML='<div class="pla-placeholder" style="grid-column:1/-1"><div class="pla-placeholder-title">No L3 sectors match the current filters</div><div class="pla-placeholder-sub">Change Geography, Country, MLE or L2 selection.</div></div>';refreshSelectionUI();return}

 const l1Groups={};
 ALL_SECTORS.forEach(s=>{
   const l1=s.l1||'Other',l2=s.l2||'Other';
   (l1Groups[l1]||(l1Groups[l1]={}));
   (l1Groups[l1][l2]||(l1Groups[l1][l2]=[])).push(s);
 });

 c.innerHTML=Object.entries(l1Groups).map(([l1,l2Groups])=>`
   <div class="ps-group">
     <div class="ps-group-label"><span class="ps-group-label-dot"></span>${esc(l1)}</div>
     ${Object.entries(l2Groups).map(([l2,sectors])=>`
       <div class="ps-l2-group">
         <div class="ps-l2-header">
           <span class="ps-l2-label">${esc(l2)}</span>
           <span class="ps-l2-count">${sectors.length} sectors</span>
         </div>
         <div class="ps-sector-grid">
           ${sectors.map(s=>`<div class="ps-sector-card ${STEP2_SELECTED_SECTORS.has(s.id)?'selected':''}" onclick="toggleSector('${esc(s.id)}')"><div class="ps-check">${STEP2_SELECTED_SECTORS.has(s.id)?'✓':''}</div><div><div class="ps-sector-name">${esc(s.name)}</div><div class="ps-sector-path">${esc(s.path)}</div></div></div>`).join('')}
         </div>
       </div>`).join('')}
   </div>`).join('');
 refreshSelectionUI();
}'''

s, e = function_span(js, "buildPortfolioSelectionUI")
js = js[:s] + new_build_portfolio + js[e:]

new_render_event = r'''function renderEventFactors(){
 const fs=STEP2_EVENT_FACTORS?.factors||[];
 $('ed-factor-count').textContent=fs.length;
 const totalWeight=fs.reduce((sum,f)=>sum+(Number(f.weight_pct)||0),0);
 $('ed-summary-body').innerHTML=fs.length
   ?fs.map((f,i)=>`<tr><td>${esc(f.factor_id||('RF'+(i+1)))}</td><td>${esc(f.name||'')}</td><td>${esc(f.importance||'')}</td><td>${esc(f.importance_score??'')}</td><td>${esc(f.weight_pct??'')}%</td></tr>`).join('')
    +`<tr class="ed-total-row"><td colspan="4" style="text-align:right;padding-right:12px;font-weight:700">Total Weight</td><td style="font-weight:700">${totalWeight.toFixed(1)}%</td></tr>`
   :`<tr><td colspan="5" style="color:var(--text_disabled)">Generate the event-driven framework after confirming Step 2.1 and Step 2.2.</td></tr>`;
 $('ed-rf-cards').innerHTML=fs.map((f,i)=>buildRFCard(f,i===0)).join('');
}'''

s, e = function_span(js, "renderEventFactors")
js = js[:s] + new_render_event + js[e:]

if 'class="net-score-note"' not in js:
    import re
    bs, be = function_span(js, "buildRFCard")
    segment = js[bs:be]
    m = re.search(r"Scoring\\s+Logic\\s*\\(1\\s*[-–—]\\s*5\\)", segment)
    if not m:
        fail("Step 2.3 Scoring Logic label not found inside buildRFCard. No files were changed.")
    pos = bs + m.start()
    table_close = js.find("</table>", pos)
    if table_close < 0 or table_close > be:
        fail("Could not locate the Step 2.3 scoring table end inside buildRFCard. No files were changed.")
    insert_at = table_close + len("</table>")
    caption = '<div class="net-score-note">Net Score = Raw Vulnerability Score − Buffer Credit (Strong: −2 / Moderate: −1 / Weak: 0). Floor: 1.</div>'
    js = js[:insert_at] + caption + js[insert_at:]

gen_marker = 'id=\\"generate-event-factors-btn\\"'
g = js.find(gen_marker)
if g < 0:
    fail("Generate Event Factors button marker not found.")
row_start = js.rfind('<div class=\\"action-row\\">', 0, g)
confirm_marker = 'id=\\"confirm-event-factors-btn\\"'
cpos = js.find(confirm_marker, g)
if row_start < 0 or cpos < 0:
    fail("Could not isolate the Step 2.3 action row.")
row_end = js.find("</div>", cpos)
if row_end < 0:
    fail("Could not find the end of the Step 2.3 action row.")
row_end += len("</div>")

new_action_row = (
    '<div class=\\"action-row\\">'
    '<button class=\\"btn btn-p btn-sm\\" id=\\"generate-event-factors-btn\\" onclick=\\"generateEventFactors()\\">\\u2301 Generate Event Factors</button>'
    '<button class=\\"btn btn-g btn-sm\\" onclick=\\"addBlankEventFactor()\\">\\uFF0b Add Factor</button>'
    '<button class=\\"btn btn-g btn-sm\\" id=\\"save-event-factors-btn\\" onclick=\\"saveEventFactorChanges()\\">Save All Changes</button>'
    '<button class=\\"btn btn-p btn-sm\\" id=\\"confirm-event-factors-btn\\" onclick=\\"confirmEventFactors()\\">Confirm All Risk Factors \\u2192</button>'
    '</div>'
)
js = js[:row_start] + new_action_row + js[row_end:]

css_marker = "/* RPR SAFE V31 VISUAL RESTORATION — STEP 2.2 / 2.3 */"
css_append = r'''

/* RPR SAFE V31 VISUAL RESTORATION — STEP 2.2 / 2.3 */
/* Additive only. Scoped to the runtime-rendered Step 2.2 / 2.3 DOM. */

#ps-sector-grid > .ps-group{
  grid-column:1/-1;
  margin-bottom:20px;
}
#ps-sector-grid > .ps-group:last-child{margin-bottom:0}
#ps-sector-grid .ps-group-label{
  display:flex;
  align-items:center;
  gap:7px;
  margin:2px 0 10px;
  font-size:10px;
  font-weight:700;
  text-transform:uppercase;
  letter-spacing:.1em;
  color:var(--text_weak);
}
#ps-sector-grid .ps-group-label-dot{
  width:8px;
  height:8px;
  border-radius:50%;
  flex-shrink:0;
  background:var(--primary);
}
#ps-sector-grid .ps-l2-group{margin-bottom:14px}
#ps-sector-grid .ps-l2-group:last-child{margin-bottom:0}
#ps-sector-grid .ps-l2-header{
  display:flex;
  align-items:center;
  gap:8px;
  padding:6px 0 8px;
  margin-bottom:8px;
  border-bottom:1px solid var(--border_weak);
}
#ps-sector-grid .ps-l2-label{
  font-size:11px;
  font-weight:700;
  color:var(--text_strong);
}
#ps-sector-grid .ps-l2-count{
  margin-left:auto;
  font-size:10px;
  color:var(--text_disabled);
}
#ps-sector-grid .ps-l2-group > .ps-sector-grid{margin-top:0}

#ed-summary-body .ed-total-row td{
  border-top:1px solid var(--border_weak);
  background:var(--layer_secondary);
}
#ed-rf-cards .net-score-note{
  background:var(--layer_secondary);
  border:1px solid var(--border_weak);
  border-radius:4px;
  padding:5px 7px;
  margin-top:6px;
  font-size:10px;
  font-style:italic;
  color:var(--text_weak);
}
'''

if css_marker not in css:
    css = css.rstrip() + css_append + "\n"

must_still_exist = [
    "let STEP22_CONFIRMED_PORTFOLIO=null;",
    "function runStep22Search()",
    "function confirmPortfolioSelection()",
    "function generateEventFactors(",
    "function saveEventFactorChanges(",
    "function confirmEventFactors(",
    "/api/v1/rpr/step2/portfolio/catalog",
    "/api/v1/rpr/step2/portfolio/search",
    "/api/v1/rpr/step2/portfolio/finalize",
    "generate-event-factors-btn",
    "save-event-factors-btn",
    "confirm-event-factors-btn",
]
missing_after = [m for m in must_still_exist if m not in js]
if missing_after:
    fail("Post-patch contract check failed. Missing: " + ", ".join(missing_after))

if "step22SelectAllByL2" in js:
    fail("Safety check failed: per-L2 Select-All functionality was introduced.")

for fname in ("buildPortfolioSelectionUI", "renderEventFactors"):
    count = js.count(f"function {fname}(")
    if count != 1:
        fail(f"Safety check failed: {fname} occurs {count} times.")

js_backup = backup(JS)
css_backup = backup(CSS)

JS.write_text(js, encoding="utf-8")
CSS.write_text(css, encoding="utf-8")

step24_hash_after = sha(STEP24_JS) if STEP24_JS.exists() else None
if step24_hash_before != step24_hash_after:
    shutil.copy2(js_backup, JS)
    shutil.copy2(css_backup, CSS)
    fail("Step 2.4 JS hash changed unexpectedly. Working files restored.")

print("PASS — RPR v31 visual patch applied safely.")
print(f"Changed: {JS}")
print(f"Changed: {CSS}")
print(f"Untouched: {STEP24_JS}")
print(f"JS backup: {js_backup}")
print(f"CSS backup: {css_backup}")
print("")
print("FUNCTIONAL CONTRACTS PRESERVED")
