"""RPR Trigger-1 v11 progressive-per-event market scanner.

Each theme runs a fast discovery call that finds up to MAX_EVENTS_PER_THEME (3, per the
Bible-rule requirement) distinct events - title, date, short overview, sources only, no
full report at this stage, which is what keeps a 3-event discovery call comparable in
latency to a 1-event one. Each discovered event then runs its own independent two-stage
pipeline:

  1. Gemini EVIDENCE ENRICHMENT - draft the full eight sections for that one event.
  2. Opus REFINEMENT - polish/tighten the enriched sections.

Unlike v9 (and unlike the intermediate one-event-per-theme v10 build), this module lets
a theme's up to 3 events progress fully independently of each other: event 1 can reach
"refined" while event 2 is still enriching and event 3 is still discovering-adjacent
retry state. Nothing here waits for every theme, or every event within a theme, before
returning anything - each public method does exactly one stage for exactly one
theme/event and is meant to be called from server.py's per-theme discovery function
(`_run_theme_discovery`) and per-event pipeline function (`_run_event_pipeline`), both
of which update shared job state under lock after every stage.

A failure or timeout at ENRICHMENT or REFINEMENT never removes or blanks the event that
an earlier, successful stage already produced - the caller (server.py) is responsible for
retaining the last-known-good version of the event and only upgrading it on success.
"""
from __future__ import annotations

import asyncio
import copy
import inspect
import json
import logging
import os
import re
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

from rpr_model_trace import model_span
from step1_quality import (
    SECTION_TITLES,
    assess_sections,
    build_machine_payload,
    overall_retrieval_status,
    parse_sectioned_report,
    select_improved_sections,
    strip_control_tags,
    summarize_quality,
)

try:
    from rpr_search_agent import run_web_search as _adk_run_web_search  # type: ignore
    _ADK_IMPORT_ERROR = ""
except Exception as exc:  # pragma: no cover
    _adk_run_web_search = None
    _ADK_IMPORT_ERROR = f"{type(exc).__name__}: {exc}"

log = logging.getLogger("uvicorn.error")

PROMPT_DIR = Path(__file__).resolve().parent / "prompts"
# Same filename as v9; content replaced with the fast, single-event discovery prompt.
FAST_DISCOVERY_PROMPT_PATH = PROMPT_DIR / "trigger1_batch_discovery_evidence.txt"
EVIDENCE_ENRICHMENT_PROMPT_PATH = PROMPT_DIR / "trigger1_evidence_enrichment.txt"
BATCH_OPUS_PROMPT_PATH = PROMPT_DIR / "trigger1_batch_opus_refinement.txt"
TARGETED_RETRIEVAL_PROMPT_PATH = PROMPT_DIR / "trigger1_refinement.txt"
TARGETED_OPUS_PROMPT_PATH = PROMPT_DIR / "trigger1_opus_refinement.txt"

# These are safety ceilings, not performance targets - lowering a ceiling does not make
# the underlying model call any faster. Measured live execution against the real Citi
# R2D2/Vertex/enterprise-web path (not the mocked test harness) showed:
#   discovery:  ~36-41s on successful calls
#   enrichment: ~109-138s per event on successful calls
#   refinement: ~122-150+s per event on successful calls
# The previous defaults (32s / 90s / 120s) were sized from an earlier, smaller sample and
# were cutting off calls that were still succeeding. These are now set with real headroom
# above the observed live range, not derived from a target latency.
_DISCOVERY_TIMEOUT = max(15, int(os.environ.get("RPR_T1_DISCOVERY_TIMEOUT", "50")))
_ENRICHMENT_TIMEOUT = max(
    30,
    int(os.environ.get("RPR_T1_ENRICHMENT_TIMEOUT", os.environ.get("RPR_T1_INITIAL_RESULT_TIMEOUT", "150"))),
)
_OPUS_TIMEOUT = max(30, int(os.environ.get("RPR_T1_REFINEMENT_TIMEOUT", "180")))
_TARGETED_TIMEOUT = max(30, int(os.environ.get("RPR_T1_TARGETED_TIMEOUT", "90")))
THEME_WORKERS = max(1, min(3, int(os.environ.get("RPR_T1_THEME_WORKERS", "3"))))
_OPUS_WORKERS = max(1, min(2, int(os.environ.get("RPR_T1_OPUS_WORKERS", "2"))))
# Bible rule: Trigger 1 supports up to 3 events per accepted theme. This ceiling is not
# reduced for performance reasons - discovery stays fast because it only asks for a short
# overview + a few sources per event, never a full report, regardless of event count.
MAX_EVENTS_PER_THEME = max(1, min(3, int(os.environ.get("RPR_T1_MAX_EVENTS_PER_THEME", "3"))))
_GEMINI_MAX_CHARS = max(12000, int(os.environ.get("RPR_T1_GEMINI_MAX_CHARS", "36000")))
_OPUS_MAX_TOKENS = max(1600, min(6000, int(os.environ.get("RPR_T1_OPUS_MAX_TOKENS", "4200"))))
_OPUS_MODEL = os.environ.get("RPR_STEP1_REFINEMENT_MODEL", "claude-opus-4-6")
_INLINE_SOURCE_RE = re.compile(r"\(Source:\s*\[[^\]]+\]\((https?://[^)]+)\)\)", re.IGNORECASE)
# Global, process-wide - correctly bounds total concurrent calls regardless of how many
# per-theme pipeline threads exist (see server.py's pipeline executor sizing).
_GEMINI_SEMAPHORE = threading.BoundedSemaphore(THEME_WORKERS)
_OPUS_SEMAPHORE = threading.BoundedSemaphore(_OPUS_WORKERS)
# Absolute safety net for the semaphore-owned-timeout pattern below: a call that is still
# running long after its normal timeout eventually gets its capacity reclaimed anyway, so
# a single truly stuck call can never permanently starve the whole scanner. This is a last
# resort, not a normal-path value - normal timeouts fire at _DISCOVERY_TIMEOUT /
# _ENRICHMENT_TIMEOUT / _OPUS_TIMEOUT, well before this ever matters.
_REAPER_HARD_CAP_SECONDS = max(300, int(os.environ.get("RPR_T1_REAPER_HARD_CAP_SECONDS", "600")))
OPUS_WORKERS = _OPUS_WORKERS
DISCOVERY_TIMEOUT = _DISCOVERY_TIMEOUT
ENRICHMENT_TIMEOUT = _ENRICHMENT_TIMEOUT
OPUS_TIMEOUT = _OPUS_TIMEOUT


def _load_prompt(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8")
    except Exception as exc:
        raise RuntimeError(f"Required Trigger-1 prompt not found: {path}") from exc


def _normalise_search_output(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value
    if isinstance(value, dict):
        for key in ("answer", "text", "output", "response", "content", "raw"):
            if isinstance(value.get(key), str):
                return str(value[key])
        return json.dumps(value, ensure_ascii=False)
    if isinstance(value, (list, tuple)):
        return "\n".join(_normalise_search_output(x) for x in value)
    return str(value)


def _run_with_semaphore_owned_timeout(
    semaphore: threading.BoundedSemaphore,
    work_fn: Any,
    timeout: int,
    *,
    on_timeout_label: str = "",
) -> Any:
    """Acquire ``semaphore`` for the true duration of ``work_fn()``, not just until the
    caller stops waiting.

    If ``work_fn`` has not finished within ``timeout`` seconds, this raises TimeoutError
    to the caller immediately, so the pipeline can move on - but the semaphore permit is
    only released once ``work_fn`` genuinely finishes, bounded by
    ``_REAPER_HARD_CAP_SECONDS`` as an absolute safety net so one truly stuck call can
    never hold a permit forever and starve the whole scanner.

    This is what prevents a timed-out call from silently exceeding the advertised
    concurrency limit: the permit tracks real in-flight work, not caller patience. We
    cannot force Python to kill a running thread, and we do not control whether the
    underlying SDK call actually honors cancellation - so instead of pretending the work
    stopped, we keep the capacity reserved until it demonstrably has.
    """
    semaphore.acquire()
    result: Dict[str, Any] = {}
    error: Dict[str, BaseException] = {}
    done_event = threading.Event()

    def runner() -> None:
        try:
            result["value"] = work_fn()
        except BaseException as exc:  # noqa: BLE001
            error["error"] = exc
        finally:
            done_event.set()

    thread = threading.Thread(target=runner, daemon=True)
    thread.start()
    finished_in_time = done_event.wait(timeout)

    if finished_in_time:
        semaphore.release()
        if "error" in error:
            raise error["error"]
        return result.get("value")

    def reaper() -> None:
        settled = done_event.wait(_REAPER_HARD_CAP_SECONDS)
        semaphore.release()
        if not settled:
            log.error(
                "[STEP1] REAPER HARD CAP HIT label=%s — releasing capacity after %ds "
                "without the underlying call finishing; it may still be running.",
                on_timeout_label, _REAPER_HARD_CAP_SECONDS,
            )
        else:
            log.info("[STEP1] REAPER RECLAIMED CAPACITY label=%s — underlying call finished after the reported timeout", on_timeout_label)

    threading.Thread(target=reaper, daemon=True).start()
    raise TimeoutError(f"{on_timeout_label} exceeded {timeout}s")


def _adk_search_sync(prompt: str, *, timeout: int, role: str, trace_label: str) -> str:
    if _adk_run_web_search is None:
        raise RuntimeError(
            "ADK web search is unavailable because rpr_search_agent could not be imported"
            + (f": {_ADK_IMPORT_ERROR}" if _ADK_IMPORT_ERROR else "")
        )

    def work() -> str:
        try:
            value = _adk_run_web_search(prompt, role=role, trace_label=trace_label)
        except TypeError:
            value = _adk_run_web_search(prompt, role=role)
        if inspect.isawaitable(value):
            # Runs to completion in THIS worker thread's own fresh event loop - always
            # safe (a brand-new thread never has a running loop already). No internal
            # asyncio.wait_for here: the outer semaphore-owned-timeout wrapper is the
            # single source of truth for both the caller-facing timeout and for when
            # capacity is actually released, so there is exactly one timeout mechanism,
            # not two overlapping ones.
            value = asyncio.run(value)
        text = _normalise_search_output(value).strip()
        if not text:
            raise RuntimeError("Gemini enterprise web search returned an empty response")
        return text

    return _run_with_semaphore_owned_timeout(
        _GEMINI_SEMAPHORE, work, timeout,
        on_timeout_label=f"Gemini enterprise search ({trace_label or role})",
    )


def _call_opus_refinement(*, system_prompt: str, user_prompt: str, trace_label: str) -> str:
    try:
        from llm_gateway import get_gateway  # type: ignore
        gateway = get_gateway()
    except Exception as exc:
        raise RuntimeError(f"R2D2 gateway unavailable: {exc}") from exc
    if not hasattr(gateway, "call_text"):
        raise RuntimeError("Trigger-1 refinement requires an R2D2 gateway with call_text().")
    if hasattr(gateway, "_model"):
        gateway._model = _OPUS_MODEL

    def work() -> str:
        with model_span(
            provider="r2d2",
            model=_OPUS_MODEL,
            role="trigger1_opus_batch_refinement",
            scope=trace_label,
        ) as trace:
            text = str(gateway.call_text(
                system_prompt=system_prompt,
                user_prompt=user_prompt,
                max_tokens=_OPUS_MAX_TOKENS,
            ) or "").strip()
            trace.output_chars = len(text)
        if not text:
            raise RuntimeError("Trigger-1 Opus refinement returned an empty response")
        return text

    return _run_with_semaphore_owned_timeout(
        _OPUS_SEMAPHORE, work, _OPUS_TIMEOUT,
        on_timeout_label=f"R2D2 Opus refinement ({trace_label or 'trigger1'})",
    )


def _strip_fences(text: str) -> str:
    cleaned = str(text or "").strip()
    cleaned = re.sub(r"^```(?:json)?\s*", "", cleaned, flags=re.I)
    cleaned = re.sub(r"\s*```$", "", cleaned)
    return cleaned.strip()


def _parse_json_object(text: str, *, required_key: str = "") -> Dict[str, Any]:
    """Parse the model's JSON object.

    When ``required_key`` is supplied, a syntactically valid dict that lacks that key is
    treated as a false match (e.g. an example/schema fragment the model echoed before the
    real answer) and parsing continues to the next candidate ``{`` rather than silently
    returning the wrong object.
    """
    cleaned = _strip_fences(text)
    candidates: List[Dict[str, Any]] = []

    try:
        value = json.loads(cleaned)
        if isinstance(value, dict):
            if not required_key or required_key in value:
                return value
            candidates.append(value)
    except Exception:
        pass

    decoder = json.JSONDecoder()
    for match in re.finditer(r"\{", cleaned):
        try:
            value, _ = decoder.raw_decode(cleaned[match.start():])
        except Exception:
            continue
        if not isinstance(value, dict):
            continue
        if not required_key or required_key in value:
            return value
        candidates.append(value)

    if candidates:
        return candidates[0]
    raise ValueError("Model response did not contain a valid JSON object")


def _normalise_sources(value: Any) -> List[Dict[str, Any]]:
    sources: List[Dict[str, Any]] = []
    for item in value if isinstance(value, list) else []:
        if not isinstance(item, dict):
            continue
        url = str(item.get("url") or item.get("link") or "").strip()
        name = str(item.get("name") or item.get("source") or item.get("publisher") or "").strip()
        if not url and not name:
            continue
        sources.append({
            "name": name or url,
            "url": url,
            "published_at": str(item.get("published_at") or item.get("date") or "").strip(),
            "supports": list(item.get("supports") or []) if isinstance(item.get("supports"), list) else [],
        })
    return sources[:8]


def _normalise_sections(value: Any, *, retrieval_status: str = "SUCCESS") -> List[Dict[str, Any]]:
    if isinstance(value, list):
        rows: List[Any] = value
    elif isinstance(value, dict):
        rows = [value.get(str(i + 1), value.get(title, {})) for i, title in enumerate(SECTION_TITLES)]
    else:
        rows = []
    output: List[Dict[str, Any]] = []
    for index, title in enumerate(SECTION_TITLES):
        raw = rows[index] if index < len(rows) else {}
        if isinstance(raw, str):
            raw = {"text": raw}
        if not isinstance(raw, dict):
            raw = {}
        text = strip_control_tags(str(raw.get("txt") or raw.get("text") or raw.get("content") or ""))
        evidence = raw.get("source_evidence") or raw.get("sources") or []
        output.append({
            "num": index + 1,
            "title": title,
            "txt": text,
            "retrieval_status": retrieval_status if text else "PENDING",
            "source_evidence": evidence if isinstance(evidence, list) else [],
            "model_evidence_tier": raw.get("model_evidence_tier"),
            "model_retrieval_status": raw.get("model_retrieval_status"),
        })
    return output


def _filter_synthesis_citations(text: str, evidence_json: str) -> Tuple[str, int]:
    removed = 0

    def replace(match: re.Match[str]) -> str:
        nonlocal removed
        url = str(match.group(1) or "").strip()
        if url and url in evidence_json:
            return match.group(0)
        removed += 1
        return ""

    cleaned = _INLINE_SOURCE_RE.sub(replace, str(text or ""))
    return re.sub(r"[ \t]{2,}", " ", cleaned).strip(), removed


def _source_names_from_meta(section_meta: Sequence[Dict[str, Any]], sources: Sequence[Dict[str, Any]]) -> str:
    names = {str(s.get("name") or "").strip() for s in sources if str(s.get("name") or "").strip()}
    names.update(
        str(name).strip()
        for meta in section_meta
        for name in (meta.get("source_names") or [])
        if str(name).strip()
    )
    return ", ".join(sorted(names))


def _event_key(title: str) -> str:
    return re.sub(r"\W+", " ", str(title or "").lower()).strip()


class MarketEventScout:
    def __init__(self) -> None:
        self.fast_discovery_prompt = _load_prompt(FAST_DISCOVERY_PROMPT_PATH)
        self.evidence_enrichment_prompt = _load_prompt(EVIDENCE_ENRICHMENT_PROMPT_PATH)
        self.batch_opus_prompt = _load_prompt(BATCH_OPUS_PROMPT_PATH)
        self.targeted_retrieval_prompt = _load_prompt(TARGETED_RETRIEVAL_PROMPT_PATH)
        self.targeted_opus_prompt = _load_prompt(TARGETED_OPUS_PROMPT_PATH)

    def preflight(self) -> Dict[str, Any]:
        try:
            from rpr_search_agent import runtime_info as search_runtime_info
            search_runtime = search_runtime_info()
        except Exception as exc:
            search_runtime = {"error": f"{type(exc).__name__}: {exc}"}
        return {
            "ok": _adk_run_web_search is not None and "error" not in search_runtime,
            "adk_available": _adk_run_web_search is not None,
            "adk_import_error": _ADK_IMPORT_ERROR or None,
            "search_runtime": search_runtime,
            "scanner_mode": "v11_progressive_per_event",
            "prompt_paths": [
                str(FAST_DISCOVERY_PROMPT_PATH),
                str(EVIDENCE_ENRICHMENT_PROMPT_PATH),
                str(BATCH_OPUS_PROMPT_PATH),
                str(TARGETED_RETRIEVAL_PROMPT_PATH),
                str(TARGETED_OPUS_PROMPT_PATH),
            ],
            "models": {
                "discovery": os.environ.get("RPR_GEMINI_DISCOVERY_MODEL", "gemini-3.5-flash"),
                "enrichment": os.environ.get("RPR_GEMINI_EVIDENCE_MODEL", "gemini-3.5-flash"),
                "refinement": _OPUS_MODEL,
            },
            "limits": {
                "theme_workers": THEME_WORKERS,
                "opus_workers": _OPUS_WORKERS,
                "max_events_per_theme": MAX_EVENTS_PER_THEME,
                "discovery_timeout_seconds": _DISCOVERY_TIMEOUT,
                "enrichment_timeout_seconds": _ENRICHMENT_TIMEOUT,
                "refinement_timeout_seconds": _OPUS_TIMEOUT,
            },
        }

    @staticmethod
    def _theme_specs(themes: Sequence[Any]) -> List[Dict[str, Any]]:
        specs: List[Dict[str, Any]] = []
        for original_index, item in enumerate(themes):
            if isinstance(item, dict):
                theme = str(item.get("theme") or item.get("name") or "").strip()
                description = str(item.get("description") or item.get("narr") or "").strip()
                client_theme_id = str(item.get("client_theme_id") or "").strip()
            else:
                theme = str(item or "").strip()
                description = ""
                client_theme_id = ""
            if theme:
                # theme_index is the OUTPUT position (len(specs) at append time), not the
                # input enumerate position - this stays a clean, gap-free 0..N-1 sequence
                # even if a blank entry was skipped, so it remains safe to use as an
                # internal dict key. client_theme_id (echoed from the caller, falling back
                # to a synthetic id derived from this same clean index if the caller did
                # not supply one) is the identifier callers should actually match on -
                # it survives client-side filtering/reordering that theme_index cannot.
                specs.append({
                    "theme": theme,
                    "description": description,
                    "theme_index": len(specs),
                    "client_theme_id": client_theme_id or f"idx{len(specs)}",
                })
        if not specs:
            raise ValueError("At least one theme is required")
        return specs

    # -------------------------------------------------------------------
    # Stage 1 - fast discovery (up to MAX_EVENTS_PER_THEME events, short
    # overview only per event - no full report at this stage)
    # -------------------------------------------------------------------

    def discover_events_gemini(self, spec: Dict[str, Any], max_events: int = MAX_EVENTS_PER_THEME) -> List[Dict[str, Any]]:
        """Identify up to max_events strongest, distinct events for the theme in one call.

        Raises on a genuine call failure/timeout/empty-response. A response that
        parses but names zero events (or only malformed ones) also raises, with the
        model's own stated reason where available - this is the Bible-rule discovery
        stage, so "no events found" must be an explicit, honest outcome, never silently
        substituted with a fabricated one.
        """
        max_events = max(1, min(MAX_EVENTS_PER_THEME, int(max_events or MAX_EVENTS_PER_THEME)))
        runtime = {
            "mode": "FAST_DISCOVERY",
            "report_as_of": datetime.now(timezone.utc).isoformat(),
            "theme": spec["theme"],
            "description": spec["description"] or None,
            "requested_event_count": max_events,
        }
        prompt = self.fast_discovery_prompt.replace("REQUESTED_EVENT_COUNT", str(max_events))
        raw = _adk_search_sync(
            prompt + "\n\n# RUNTIME\n" + json.dumps(runtime, ensure_ascii=False, indent=2),
            timeout=_DISCOVERY_TIMEOUT,
            role="discovery",
            trace_label=f"theme:{spec['theme'][:60]}:discovery",
        )[:_GEMINI_MAX_CHARS]
        parsed = _parse_json_object(raw, required_key="events")
        raw_items = parsed.get("events")
        if not isinstance(raw_items, list):
            raise ValueError("Discovery response did not contain an events array")

        results: List[Dict[str, Any]] = []
        seen_keys: set[str] = set()
        for raw_item in raw_items[:max_events + 2]:  # small headroom in case the model over-returns
            if not isinstance(raw_item, dict):
                continue
            title = str(raw_item.get("title") or "").strip()
            overview = str(raw_item.get("event_overview") or "").strip()
            if not title or not overview:
                continue  # skip a malformed single item rather than failing the whole theme
            key = _event_key(title)
            if key and key in seen_keys:
                continue  # the model returned a near-duplicate of an already-accepted event
            if key:
                seen_keys.add(key)
            results.append({
                "title": title,
                "event_date": str(raw_item.get("event_date") or "").strip(),
                "event_overview": overview,
                "why_material": str(raw_item.get("why_material") or "").strip(),
                "confidence": str(raw_item.get("confidence") or "MEDIUM").upper(),
                "sources": _normalise_sources(raw_item.get("sources")),
                "search_queries": [str(q).strip() for q in (raw_item.get("search_queries") or []) if str(q).strip()],
            })
            if len(results) >= max_events:
                break

        if not results:
            reason = str(parsed.get("why_material") or "No usable event was returned.").strip()
            raise ValueError(f"No usable event found for '{spec['theme']}': {reason}")
        return results

    def build_discovered_event(self, *, event_id: int, spec: Dict[str, Any], item: Dict[str, Any]) -> Dict[str, Any]:
        """Build the initial event object shown to the UI immediately after discovery."""
        overview_text = strip_control_tags(item["event_overview"])
        sources = copy.deepcopy(item.get("sources") or [])
        queries = list(item.get("search_queries") or [])
        sections: List[Dict[str, Any]] = []
        for index, title in enumerate(SECTION_TITLES):
            if index == 0:
                sections.append({
                    "num": 1,
                    "title": title,
                    "txt": overview_text,
                    "retrieval_status": "SUCCESS" if overview_text else "PENDING",
                    "source_evidence": sources[:3],
                    "model_evidence_tier": None,
                    "model_retrieval_status": None,
                })
            else:
                sections.append({
                    "num": index + 1,
                    "title": title,
                    "txt": "",
                    "retrieval_status": "PENDING",
                    "source_evidence": [],
                    "model_evidence_tier": None,
                    "model_retrieval_status": None,
                })
        discovery_model = os.environ.get("RPR_GEMINI_DISCOVERY_MODEL", "gemini-3.5-flash")
        evidence_model = os.environ.get("RPR_GEMINI_EVIDENCE_MODEL", "gemini-3.5-flash")
        source_names = ", ".join(sorted({s["name"] for s in sources if s.get("name")}))
        machine_payload = build_machine_payload(
            trigger="trigger1",
            sections=sections,
            event={
                "title": item["title"],
                "event_date": item.get("event_date") or "",
                "theme": spec["theme"],
                "why_material": item.get("why_material") or "",
            },
            query_log=queries,
            query_log_source="gemini_fast_discovery_reported_search_formulations",
            model_metadata={"stage": "discovered", "enrichment_status": "pending", "refinement_status": "pending"},
        )
        enhancement_meta = {
            "retrieval_failure": False,
            "retrieval_status": "PENDING",
            "stage": "discovered",
            "enrichment_status": "pending",
            "refinement_status": "pending",
            "enrichment_error": "",
            "refinement_error": "",
            "executed_query": " | ".join(queries),
            "query_log": queries,
            "query_log_source": "gemini_fast_discovery_reported_search_formulations",
            "machine_payload": machine_payload,
            "model_path": (
                f"Gemini {discovery_model} fast discovery -> "
                f"pending Gemini {evidence_model} enrichment -> pending R2D2 {_OPUS_MODEL} refinement"
            ),
            "models_triggered": [{"provider": "gemini", "model": discovery_model, "role": "trigger1_fast_discovery"}],
            "evidence_sources": sources,
        }
        return {
            "id": event_id,
            "event_id": event_id,
            # Generic on purpose - does NOT bake in the globally-unique event_id, which
            # would leak a confusing cross-theme number (e.g. "Event 4" for a second
            # theme's first event) into the UI. The frontend always computes the
            # correct per-theme LOCAL display number (Event 1/2/3 within each theme)
            # itself; this field is only a last-resort fallback if subtitle is empty.
            "label": "Discovered Event",
            "subtitle": item["title"],
            "theme": spec["theme"],
            "theme_name": spec["theme"],
            "theme_index": int(spec["theme_index"]),
            "client_theme_id": str(spec.get("client_theme_id") or ""),
            "event_date": item.get("event_date") or "",
            "why_material": item.get("why_material") or "",
            "confidence": item.get("confidence") or "MEDIUM",
            "sections": sections,
            "source": source_names,
            "source_names": source_names,
            "horizon": "12 months",
            "search_failed": False,
            "fail_reason": "",
            "executed_query": " | ".join(queries),
            "query_log": queries,
            "stage": "discovered",
            "enhancement_meta": enhancement_meta,
            "machine_payload": machine_payload,
        }

    # -------------------------------------------------------------------
    # Stage 2 - background Gemini evidence enrichment (full eight sections)
    # -------------------------------------------------------------------

    def enrich_event_gemini(self, spec: Dict[str, Any], event: Dict[str, Any]) -> Dict[str, Any]:
        """Draft all eight sections for the already-discovered event. Raises on failure/timeout."""
        event_id = int(event.get("event_id") or event.get("id") or 0)
        discovery_overview = ""
        if event.get("sections"):
            discovery_overview = str(event["sections"][0].get("txt") or "")
        runtime = {
            "mode": "EVIDENCE_ENRICHMENT",
            "report_as_of": datetime.now(timezone.utc).isoformat(),
            "theme": spec["theme"],
            "event_id": event_id,
            "title": event.get("subtitle") or "",
            "event_date": event.get("event_date") or "",
            "discovery_overview": discovery_overview,
            "why_material": event.get("why_material") or "",
            "initial_sources": (event.get("enhancement_meta") or {}).get("evidence_sources") or [],
            "section_titles": list(SECTION_TITLES),
        }
        raw = _adk_search_sync(
            self.evidence_enrichment_prompt + "\n\n# RUNTIME\n" + json.dumps(runtime, ensure_ascii=False, indent=2),
            timeout=_ENRICHMENT_TIMEOUT,
            role="evidence",
            trace_label=f"event:E{event_id}:enrich",
        )[:_GEMINI_MAX_CHARS]
        parsed = _parse_json_object(raw, required_key="sections")
        sections = _normalise_sections(parsed.get("sections"), retrieval_status="SUCCESS")
        if not any(str(section.get("txt") or "").strip() for section in sections):
            raise ValueError("Evidence enrichment returned no usable section content")
        sources = _normalise_sources(parsed.get("sources"))
        queries = [str(q).strip() for q in (parsed.get("search_queries") or []) if str(q).strip()]
        return {
            "sections": sections,
            "sources": sources,
            "confidence": str(parsed.get("confidence") or event.get("confidence") or "MEDIUM").upper(),
            "search_queries": queries,
        }

    # -------------------------------------------------------------------
    # Stage 3 - background Opus refinement (single event)
    # -------------------------------------------------------------------

    def refine_event_opus(self, theme: str, event: Dict[str, Any]) -> Dict[str, Any]:
        """Refine one already-enriched event through Opus. Raises on failure/timeout."""
        updated = self._refine_theme_group(theme, [event])
        if not updated:
            raise RuntimeError("Opus refinement returned no events")
        return updated[0]

    @staticmethod
    def _compact_event_for_opus(event: Dict[str, Any]) -> Dict[str, Any]:
        return {
            "event_id": int(event.get("event_id") or event.get("id") or 0),
            "title": str(event.get("subtitle") or event.get("title") or ""),
            "event_date": str(event.get("event_date") or ""),
            "why_material": str(event.get("why_material") or ""),
            "sources": list((event.get("enhancement_meta") or {}).get("evidence_sources") or []),
            "sections": [
                {"num": section.get("num"), "title": section.get("title"), "text": section.get("txt")}
                for section in (event.get("sections") or [])
            ],
        }

    def _refine_theme_group(self, theme: str, events: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        evidence_input = {
            "report_as_of": datetime.now(timezone.utc).isoformat(),
            "theme": theme,
            "section_titles": list(SECTION_TITLES),
            "word_limit_per_section": "120-180 words",
            "events": [self._compact_event_for_opus(event) for event in events],
        }
        evidence_json = json.dumps(evidence_input, ensure_ascii=False)
        # _call_opus_refinement already acquires _OPUS_SEMAPHORE internally (via
        # _run_with_semaphore_owned_timeout) for the true duration of the call - do not
        # also acquire it here, or a single call would hold two of the two available
        # permits (or deadlock outright if RPR_T1_OPUS_WORKERS=1).
        raw = _call_opus_refinement(
            system_prompt=self.batch_opus_prompt,
            user_prompt=evidence_json,
            trace_label=f"theme:{theme[:60]}",
        )
        parsed = _parse_json_object(raw, required_key="events")
        refined_rows = parsed.get("events")
        if not isinstance(refined_rows, list):
            raise ValueError("Opus batch response did not contain an events array")
        by_id = {
            int(row.get("event_id") or row.get("id") or 0): row
            for row in refined_rows
            if isinstance(row, dict)
        }
        if not by_id:
            raise ValueError("Opus batch response contained no identifiable events")

        updated: List[Dict[str, Any]] = []
        for original in events:
            event = copy.deepcopy(original)
            event_id = int(event.get("event_id") or event.get("id") or 0)
            row = by_id.get(event_id)
            meta = event.setdefault("enhancement_meta", {})
            if row is None:
                raise ValueError(f"Event {event_id} missing from Opus batch response")
            sections = _normalise_sections(row.get("sections"), retrieval_status="SUCCESS")
            removed_total = 0
            for section in sections:
                section["txt"], removed = _filter_synthesis_citations(section.get("txt") or "", evidence_json)
                section["unverified_citation_count"] = removed
                removed_total += removed
            if not any(str(section.get("txt") or "").strip() for section in sections):
                raise ValueError(f"Opus returned empty sections for event {event_id}")
            section_meta = assess_sections(sections)
            sources = list(meta.get("evidence_sources") or [])
            event["sections"] = sections
            event["source"] = _source_names_from_meta(section_meta, sources)
            event["source_names"] = event["source"]
            event["stage"] = "refined"
            machine_payload = build_machine_payload(
                trigger="trigger1",
                sections=sections,
                event={
                    "title": event.get("subtitle"),
                    "event_date": event.get("event_date"),
                    "theme": theme,
                    "why_material": event.get("why_material"),
                },
                query_log=event.get("query_log") or [],
                query_log_source=str(meta.get("query_log_source") or "gemini_enrichment_reported_search_formulations"),
                model_metadata={"stage": "refined", "enrichment_status": "complete", "refinement_status": "complete"},
            )
            event["machine_payload"] = machine_payload
            meta.update({
                "retrieval_failure": False,
                "retrieval_status": overall_retrieval_status(section_meta),
                "stage": "refined",
                "refinement_status": "complete",
                "refinement_error": "",
                "section_meta": section_meta,
                "quality": summarize_quality(section_meta),
                "machine_payload": machine_payload,
                "unsupported_synthesis_citations_removed": removed_total,
                "models_triggered": (meta.get("models_triggered") or []) + [
                    {"provider": "r2d2", "model": _OPUS_MODEL, "role": "trigger1_opus_batch_refinement"},
                ],
            })
            updated.append(event)
        return updated

    # -------------------------------------------------------------------
    # Targeted analyst-approved rescan (unchanged from v9)
    # -------------------------------------------------------------------

    def refine_event(
        self,
        event: Dict[str, Any],
        feedback: str,
        affected_sections: Optional[Sequence[str]] = None,
        analyst_modified_sections: Optional[Sequence[str]] = None,
    ) -> Dict[str, Any]:
        """Targeted analyst-approved rescan; original sections survive non-improvements."""
        guidance = str(feedback or "").strip()
        if not guidance:
            raise ValueError("Feedback/refinement guidance is required")
        affected = [name for name in (affected_sections or []) if name in SECTION_TITLES]
        if not affected:
            affected = list(SECTION_TITLES)
        original_sections = list(event.get("sections") or [])
        theme = str(event.get("theme_name") or event.get("theme") or "").strip()
        title = str(event.get("subtitle") or event.get("label") or "Market event").strip()
        event_id = int(event.get("event_id") or event.get("id") or 0)
        trace_label = f"event:E{event_id}:targeted"
        retrieval_input = {
            "mode": "TARGETED_RETRIEVAL",
            "report_as_of": datetime.now(timezone.utc).isoformat(),
            "theme": theme,
            "event": title,
            "affected_sections": affected,
            "analyst_guidance": guidance,
        }
        evidence = _adk_search_sync(
            self.targeted_retrieval_prompt + "\n\n# RUNTIME\n" + json.dumps(retrieval_input, ensure_ascii=False, indent=2),
            timeout=_TARGETED_TIMEOUT,
            role="evidence",
            trace_label=trace_label,
        )[:_GEMINI_MAX_CHARS]
        parsed_evidence = parse_sectioned_report(evidence)
        queries = [str(q).strip() for q in (parsed_evidence.get("search_queries") or []) if str(q).strip()]
        opus_input = {
            **retrieval_input,
            "prior_sections": original_sections,
            "enterprise_web_evidence": evidence,
        }
        raw = _call_opus_refinement(
            system_prompt=self.targeted_opus_prompt,
            user_prompt=json.dumps(opus_input, ensure_ascii=False),
            trace_label=trace_label,
        )
        try:
            parsed = _parse_json_object(raw, required_key="sections")
            candidate_sections = _normalise_sections(parsed.get("sections"), retrieval_status="SUCCESS")
        except Exception:
            parsed_report = parse_sectioned_report(raw)
            candidate_sections = _normalise_sections(parsed_report.get("sections"), retrieval_status="SUCCESS")
        for section in candidate_sections:
            section["txt"], removed = _filter_synthesis_citations(section.get("txt") or "", evidence)
            section["unverified_citation_count"] = removed
        final_sections, comparison = select_improved_sections(original_sections, candidate_sections, affected)
        modified_before = {name for name in (analyst_modified_sections or []) if name in SECTION_TITLES}
        accepted = set(comparison.get("accepted_sections") or [])
        final_modified = sorted(modified_before - accepted, key=lambda name: SECTION_TITLES.index(name))
        section_meta = assess_sections(final_sections)
        retrieval_status = overall_retrieval_status(section_meta)
        machine_payload = build_machine_payload(
            trigger="trigger1",
            sections=final_sections,
            event={"title": title, "theme": theme},
            query_log=queries or [guidance],
            query_log_source="model_reported_search_formulations" if queries else "analyst_approved_search_instruction",
            model_metadata={"stage": "targeted_refinement"} if not final_modified else {},
        )
        machine_payload["analyst_state"] = {
            "confirmed": False,
            "modified_sections": final_modified,
            "structured_model_metadata_reused": not bool(final_modified),
        }
        updated = copy.deepcopy(event)
        updated.update({
            "id": event_id,
            "event_id": event_id,
            "sections": final_sections,
            "source_names": _source_names_from_meta(section_meta, []),
            "executed_query": " | ".join(queries or [guidance]),
            "query_log": queries or [guidance],
            "machine_payload": machine_payload,
            "rescan_result": {**comparison, "guidance": guidance},
        })
        updated.setdefault("enhancement_meta", {}).update({
            "retrieval_failure": retrieval_status == "TECHNICAL_FAILURE",
            "retrieval_status": retrieval_status,
            "refinement_status": "complete",
            "section_meta": section_meta,
            "quality": summarize_quality(section_meta),
            "machine_payload": machine_payload,
            "models_triggered": [
                {
                    "provider": "gemini",
                    "model": os.environ.get("RPR_GEMINI_EVIDENCE_MODEL", "gemini-3.5-flash"),
                    "role": "trigger1_targeted_retrieval",
                },
                {"provider": "r2d2", "model": _OPUS_MODEL, "role": "trigger1_targeted_refinement"},
            ],
        })
        return updated
