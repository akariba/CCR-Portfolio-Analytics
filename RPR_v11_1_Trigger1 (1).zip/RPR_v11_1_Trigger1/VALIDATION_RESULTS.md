# VALIDATION_RESULTS.md — RPR Trigger 1 v11.1

Candidate for review. Not approved for deployment.

## Blocker-by-blocker verification

| # | Blocker | Verified how | Result |
|---|---|---|---|
| 1 | Live-safe timeouts | `assert mes.DISCOVERY_TIMEOUT==50 and ENRICHMENT_TIMEOUT==150 and OPUS_TIMEOUT==180` against the actual loaded module | **PASS** |
| 2 | Duplicate-scan protection | Code review + regression suite confirms `isScanning`/button-disable now spans the full poll lifetime, not just the initial fetch | **PASS** (see note below — no headless-browser click-simulation was run in this pass; verified by direct inspection of the control-flow path, not a live UI click test) |
| 3 | Opus/Gemini timeout concurrency | Dedicated isolated test: `caller1` times out at t=0.106s while `slow_work` keeps running; `caller2` (same single-permit semaphore) could not start its own work until t=0.606s — exactly when the real work finished, not when the timeout fired. Separate hard-cap test confirms a truly-stuck call still has its capacity reclaimed at the bounded safety cap (not held forever). | **PASS**, both sub-cases measured directly |
| 4 | Preserve late refined versions | Frontend logic re-verified: confirmed event now stores the complete candidate object as `pendingGeneratedVersion`, not a boolean | **PASS** (see updated frontend assertion below) |
| 5 | Stage-aware retry | `POST .../retry-refinement` wired via `retryFailedItems()`; backend retry-identity preserved through cache (see blocker 6 test) | **PASS** — endpoint-level behavior re-verified; frontend wiring verified by code path, not a live click |
| 6 | Cache semantics | Direct test: an all-failed job is NOT cached (repeat scan tries fresh); a successful job's cache-hit response returns the ORIGINAL `job_id`, not `null` | **PASS**, both sub-cases measured directly |
| 7 | Stable theme mapping | Direct test: 3 themes with a blank row in the middle — `client_theme_id` correctly echoed for the two real themes, blank row excluded, both themes correctly produce 3 events each | **PASS**, measured directly |
| 8 | Per-theme event numbering | Frontend: tree numbering now always computed as `idx+1` (local array position), `ev.label` no longer used for the number; backend: `label` field is now generic, never bakes in the global `event_id` | **PASS**, confirmed by code path — see frontend test note below |
| 9 | Tests | See below | Backend: 8/8 scenario groups pass (unchanged from v11, re-run against v11.1 with zero regressions). Frontend: 32/32 assertions pass (31 pre-existing + 1 updated for the new `pendingGeneratedVersion` field, replacing the retired `refinedAvailable` boolean check). New dedicated blocker #3 semaphore-ownership tests (2) and blocker #1/#6/#7 quick-verify tests (5) all pass, shown below. |
| 10 | Delivery | This ZIP | See file count below |

## Backend regression suite (re-run against the final v11.1 files, zero changes needed)

```
TEST BIBLE-1 (event count): PASS — theme correctly produced 3 events
TEST BIBLE-1 (independent progress): PASS — a fast event completed fully without waiting for its slower siblings
TEST B: PASS (theme with 3 events fully retained; timed-out theme isolated)
TEST C: PASS (one event's enrichment failure did not affect its siblings within the same theme)
TEST E: PASS
TEST RETRY-EVENT: PASS (only the failed event retried, siblings untouched, no rediscovery)
TEST HTTP: PASS (fast return, 200 throughout, 3 events for the surviving theme, timed-out theme isolated)
TEST HTTP CACHE: PASS
```
No traceback, no AssertionError, in the full run.

## Blocker #3 — dedicated semaphore-ownership tests (new)

```
=== TEST: semaphore-owned timeout — permit is NOT released until the underlying call actually finishes ===
  t= 0.005s  slow_work: started real work
  t= 0.106s  caller1: got TimeoutError as expected at ~0.1s
  t= 0.107s  caller2: attempting to acquire capacity
  t= 0.605s  slow_work: real work finished
  t= 0.606s  fast_work: started real work
  t= 0.656s  fast_work: real work finished
  t= 0.656s  caller2: got capacity and result='fast-result'
PASS: caller2 could NOT start its real work until slow_work's real work genuinely finished.
      The reported timeout (0.1s) and the actual capacity release (~0.6s) are correctly decoupled.
      A timed-out call cannot exceed the advertised concurrency limit.

=== TEST: reaper hard cap eventually reclaims capacity even if work never finishes ===
caller1 timed out at t=0.051s (expected ~0.05s)
caller2 acquired capacity at t=0.353s (expected ~0.3s = the hard cap, NOT 10s)
PASS: capacity was reclaimed at the hard cap, not held forever waiting for a call that never returns.
```

## Blockers #1, #6, #7 — quick-verify tests (new)

```
Timeouts: 50 150 180
PASS: live-safe timeouts + Bible rule constant
theme_status client_theme_ids: {'0': 'row-1', '1': 'row-3'}
PASS: blank-middle-theme — client_theme_id correctly echoed, blank row excluded
ThemeA events: 3 ThemeB events: 3
PASS: two themes each show 3 events (Bible rule holds with blank middle theme)
Repeat scan after all-fail: cache_hit= False job_status= discovering
PASS: failed job was not cached — repeat scan tries fresh, never masquerades as 'no market event exists'
Cache hit job_id: 20b76881c78340679baccd207ecbd589 (should equal 20b76881c78340679baccd207ecbd589 )
PASS: cache hit preserves the original job_id for retry, not None
```

## Frontend test results

```
32/32 assertions passed
```
Same 24 pre-existing checks from the v11 package plus the 7 multi-event/Bible-rule checks
added for v11, plus 1 assertion updated to check `pendingGeneratedVersion` (the new,
richer storage) instead of the retired `refinedAvailable` boolean, per blocker #4. All
32 pass against the actual `<script>` block of the file in this ZIP, in a real DOM (jsdom).

## v31 visual baseline

```
Outside-<script> byte-identical to v31 baseline: True
```

## What this validation does NOT cover — read before treating it as complete sign-off

Given the turnaround requested for this revision, the following from the original ask
were verified by **direct code-path inspection**, not by an automated click-simulation
test harness (no headless-browser DOM click/interaction test was built for these):

- Blocker #2 (duplicate-scan button state) — the control-flow change (button disabled
  across the full poll lifetime, re-enabled only at the two terminal-state exit points)
  was traced by hand against the exact final file in this ZIP, but no automated test
  clicks Scan twice and asserts the button state. **Recommend a manual click-test during
  live validation**: click Scan, confirm the button is disabled and stays disabled while
  the System Log shows in-progress stage lines, and only re-enables once a theme reaches
  a terminal state.
- Blocker #5 (frontend retry wiring) — `retryFailedItems()`'s HTTP call shape and the
  backend retry-identity/cache behavior it depends on were verified directly; the actual
  button click → network call → UI update round-trip was not driven end-to-end by an
  automated frontend test in this pass.
- Blocker #4's "Review & Compare" UI flow (`reviewPendingVersion`) — verified by reading
  the exact code path (un-confirms, loads the candidate via `Object.assign`, clears the
  pending flag), not by an automated interaction test.

None of the above changed anything about the P0 non-negotiable protections, which ARE
covered by the automated 32-assertion suite: confirmed content is never silently
overwritten, and failed/timed-out stages retain their last successful content — both
re-verified directly against the new `pendingGeneratedVersion` code path.

As with every prior package, mocked timing proves orchestration correctness, not live
Gemini/R2D2 performance — see the live-test sequence in INSTALL.txt for the real-network
verification this cannot substitute for.
