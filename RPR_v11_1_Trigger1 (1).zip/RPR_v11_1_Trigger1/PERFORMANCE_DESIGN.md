# PERFORMANCE_DESIGN.md — RPR Trigger 1 v11.1

Candidate for review. Not approved for deployment. Supersedes the v11 version — call
counts and concurrency model are unchanged from v11; timeouts and the concurrency-safety
guarantee are corrected here.

## 1–2. Exact model-call counts

Unchanged from v11: **7 model calls** for one theme yielding 3 events (1 discovery + 3
enrichment + 3 refinement), plus 0 or 1 shared theme-gate call for the whole scan.

## 3. Which calls run concurrently

Unchanged from v11: discovery and enrichment share one Gemini concurrency limit
(`THEME_WORKERS`, default 3); refinement has its own Opus limit (`OPUS_WORKERS`, default
2). See v11's PERFORMANCE_DESIGN.md section 3 for the full walkthrough — not repeated
here since the concurrency *topology* did not change in this revision, only how
correctly the timeout mechanism honors it (section 6 below).

## 4. All worker, semaphore, and timeout values (corrected)

| Name | Env var | Default | Note |
|---|---|---:|---|
| Max events per theme | `RPR_T1_MAX_EVENTS_PER_THEME` | 3 | Bible rule, unchanged |
| Theme workers | `RPR_T1_THEME_WORKERS` | 3 | unchanged |
| Opus workers | `RPR_T1_OPUS_WORKERS` | 2 | unchanged |
| **Discovery timeout** | `RPR_T1_DISCOVERY_TIMEOUT` | **50s** (was 32s) | Measured live successful calls: ~36–41s |
| **Enrichment timeout** | `RPR_T1_ENRICHMENT_TIMEOUT` | **150s** (was 90s) | Measured live successful calls: ~109–138s/event |
| **Refinement timeout** | `RPR_T1_REFINEMENT_TIMEOUT` | **180s** (was 120s) | Measured live successful calls: ~122–150+s/event |
| Reaper hard cap | `RPR_T1_REAPER_HARD_CAP_SECONDS` | 600s | New in this revision — see section 6 |

These remain safety ceilings, not performance targets. Raising them does not slow model
execution down, and lowering them would not have sped it up — the previous defaults were
simply cutting off calls that were still succeeding, based on live-execution evidence.

## 5. What happens when one event times out

Unchanged from v11: isolated to that one event, falls back to its last successful stage
with content retained, sibling events and other themes unaffected, never a 502.

## 6. Whether a timed-out underlying call continues consuming worker capacity — CORRECTED

**v11's answer to this question is now fixed, not just documented.** v11 correctly
*described* that a timed-out call's semaphore permit was released at the caller's
timeout regardless of whether the real work had actually stopped — but did not fix it.
v11.1 fixes it directly.

**New mechanism (`_run_with_semaphore_owned_timeout`):** the semaphore permit is
acquired before the real work starts and is only released once that work genuinely
finishes — never at the moment the *caller* gives up waiting. If the work is still
running past the configured timeout, the caller is told `TimeoutError` immediately (so
the pipeline can move on), but a background "reaper" keeps the permit reserved until the
real work completes, bounded by an absolute `_REAPER_HARD_CAP_SECONDS` (default 600s) so
one truly stuck call can never starve the scanner forever.

**Verified directly, not just by code reading:** a dedicated test acquired a
single-permit semaphore, started a call that reports `TimeoutError` at 0.1s but whose
real work doesn't finish until 0.6s, then had a second caller attempt to use the same
permit. The second caller could not start its own work until t=0.606s — matching the
*real* completion time of the first call, not its reported timeout. A second test
confirmed the hard cap: a call that never finishes still has its capacity reclaimed at
the bounded cap (measured ~0.353s against a 0.3s test override), not held forever.

**What is still not, and cannot be, guaranteed:** Python cannot forcibly kill a running
thread, and this package has no visibility into whether the underlying `google-genai`/
Anthropic SDK calls actually stop their network activity when the Python-level timeout
fires — only that this package's own *accounting* of available capacity now correctly
reflects real work, not caller patience. If the SDK's own call keeps running in the
background past the timeout (which we cannot prevent from here), it does so without
occupying a semaphore permit that a legitimate new call needs — which is the actual
guarantee requested: a timed-out call cannot cause the scanner to exceed its advertised
concurrency limit.

## 7–8. First-event visibility and the mocked-timing disclaimer

Unchanged from v11 in substance; the only difference is that the underlying safety
ceilings (32/90/120s) generating those estimates in v11 are now 50/150/180s, so the
theoretical worst-case single-event pipeline is now 50+150+180 = 380s (was 242s) — again,
a ceiling, not an expectation, and now grounded in measured live data rather than an
earlier, smaller sample. The core disclaimer is unchanged and remains the controlling
statement: mocked timing in this package's test suite proves the orchestration and
concurrency-accounting logic are correct; it does not and cannot prove real Gemini/R2D2
latency on Citi's live network. That still requires the live-test sequence in
INSTALL.txt.
